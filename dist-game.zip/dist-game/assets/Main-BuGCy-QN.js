var Yv=Object.defineProperty;var $v=(i,e,t)=>e in i?Yv(i,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):i[e]=t;var pn=(i,e,t)=>$v(i,typeof e!="symbol"?e+"":e,t);import{A as Zv,O as Ds,n as jv,F as Wc,g as mt,c as yt,o as Jv,q as Qv,e as it,v as fa,r as eM,s as ki,u as We,w as xn,x as tM,d as an,y as nM,z as iM,B as ts,C as w,K as rM,D as ve,E as q0,f as ch,G as Ci,H as uh,I as gt,J as Ke,L as V,M as Ye,N as On,P as mr,R as os,m as ln,V as re,Q as Y0,S as Dt,T as Ge,U as bn,W as qt,X as Es,Y as Kc,Z as sM,_ as gn,$ as kt,a0 as Lt,a1 as _t,a2 as _r,a3 as en,a4 as Xt,a5 as ae,a6 as Ae,a7 as ke,a8 as kn,a9 as tn,k as fe,l as $e,aa as ot,ab as Fo,ac as ls,ad as dh,ae as fn,af as we,ag as aM,ah as zn,ai as Cr,aj as oM,ak as ac,al as lM,am as Ie,an as Ni,ao as Ws,ap as $0,aq as fh,ar as cM,as as Z0,at as j0,au as J0,av as Bo,aw as uM,ax as Q0,ay as mu,az as jt,aA as ya,aB as oi,aC as dM,aD as oc,aE as yn,aF as Ud,aG as lc,aH as _e,aI as An,aJ as fM,aK as Yr,aL as Xc,aM as hM,aN as wo,aO as xr,aP as ja,aQ as eg,aR as tg,aS as pM,aT as ha,aU as Pt,aV as cc,aW as Yi,aX as ns,aY as Fd,aZ as It,a_ as hh,a$ as qc,b0 as mM,b1 as gM,b2 as ng,b3 as Oo,b4 as Ns,b5 as _M,b6 as vM,b7 as MM,b8 as SM,b9 as xM,ba as yM,bb as Bd,bc as Od,bd as TM,be as bM,bf as Us,bg as ig,bh as EM,bi as Re,bj as uc,bk as AM,bl as ph,bm as wM,bn as CM,bo as Pa,bp as ga,bq as rg,br as sg,bs as gu,bt as RM,bu as dc,bv as ag,bw as LM,bx as PM,by as IM,bz as DM,bA as fc,bB as ko,bC as NM,bD as Ls,bE as UM,bF as Yc,bG as FM,bH as BM,bI as kd,bJ as Ks,bK as mh,bL as OM,bM as Si,bN as Hd,bO as Vd,bP as lp,bQ as kM,bR as og,bS as lg,bT as cp,bU as cg,bV as HM,bW as Ho,bX as En,bY as VM,bZ as Zi,b_ as GM,b$ as zM,c0 as Ia,c1 as WM,c2 as KM,c3 as ug,c4 as hc,c5 as gh,c6 as XM,c7 as Gd,c8 as qM,c9 as up,ca as Da,cb as dg,cc as fg,cd as zd,ce as po,cf as hg,cg as pg,ch as YM,ci as $M,cj as _h,ck as ZM,cl as Ta,cm as jM,cn as Co,co as JM,cp as QM,cq as pc,cr as eS,cs as tS,ct as nS,cu as Vo,cv as mg,cw as gg,cx as iS,cy as _g,cz as vg,cA as vh,cB as rS,cC as sS,cD as aS,cE as oS,cF as Na,cG as Wl,cH as Xs,cI as lS,cJ as _u,cK as dp,cL as cS,cM as uS,cN as mo,cO as Mg,cP as Sg,cQ as xg,cR as Ro,cS as Ua,cT as mc,cU as fp,cV as hp,cW as Mh,cX as fr,cY as yg,cZ as dS,c_ as fS,c$ as hS,d0 as go,d1 as Kl,d2 as pS,d3 as _o,d4 as gc,d5 as Tt,d6 as is,d7 as Tg,d8 as vu,d9 as mS,da as jn,db as Sn,dc as ai,dd as gS,de as _S,df as Hn,dg as _c,dh as vS,di as MS,dj as SS,dk as xS,dl as yS,t as ie,dm as TS,dn as bS,dp as ES,p as te,dq as AS,dr as Ui,a as Ps,ds as vc,dt as Mc,du as wS,dv as CS,b as k,dw as bg,dx as Fs,dy as Eg,dz as Sc,dA as Ag,dB as $c,dC as RS,dD as LS,dE as PS,dF as IS,dG as Sh,dH as Wd,dI as DS,dJ as NS,dK as er,dL as wg,dM as Kd,dN as US,dO as FS,dP as BS,dQ as Nn,dR as Fa,dS as Cg,dT as Go,dU as Wr,dV as li,dW as Ja,dX as Bs,dY as OS,dZ as kS,j as cn,d_ as HS,d$ as VS,e0 as GS,e1 as zS,e2 as Zc,e3 as Rg,e4 as pp,e5 as Lg,e6 as Pg,e7 as xh,e8 as mp,e9 as WS,ea as KS,eb as XS,ec as xc,ed as Os,ee as qS,ef as YS,eg as Mu,eh as $S,ei as ZS,ej as jS,ek as JS,el as Xd,em as Ig,en as Dg,eo as Ss,ep as yh,eq as QS,er as ex,es as tx,et as jc,eu as nx,ev as ix,ew as rx,ex as sx,ey as ax,ez as vo,eA as zo,eB as so,eC as gp,eD as ox,eE as lx,eF as cx,eG as Th,eH as _p,eI as ux,eJ as dx,eK as fx,eL as hx,eM as yc,eN as Kr,eO as bh,eP as px,eQ as ba,eR as Ng,eS as mx,eT as dl,eU as gx,eV as vp,eW as Mp,eX as Sp,eY as _x,eZ as vx,e_ as Mx,e$ as Sx,f0 as xx,f1 as yx,f2 as Tx,f3 as bx,f4 as Ex,f5 as Ax,f6 as wx,f7 as Ug,f8 as Cx,f9 as Rx,fa as Lx,fb as Px,fc as Ix,fd as xp,fe as Dx,ff as Lo,fg as Nx,fh as Ux,i as Fx,h as Bx,fi as Ox,fj as Fg,fk as yp,fl as kx,fm as Hx,fn as Vx,fo as Gx,fp as zx,fq as Bg}from"./Input-kNa6f62w.js";function Wx(){return Math.random()}function Su(i,e){if(e<i)throw Zv("minValue must be less than maxValue");return Math.floor(Math.random()*(e-i))+i}function Kx(i){if(Ds(i))throw jv("buffer");for(let e=0;e<i.length;e+=6){let t=Math.floor(Math.random()*281474976710656);const n=Math.floor(t/16777216);for(let r=0;r<6&&e+r<i.length;r++)r===3&&(t=n),i[e+r]=t&255,t>>>=8}}class Xx{constructor(){}Next0(){return Su(0,2147483647)|0}Next1(e){return Su(0,e)|0}Next2(e,t){return Su(e,t)|0}NextDouble(){return Wx()}NextBytes(e){Kx(e)}}function qx(){return new Xx}function Jc(){return qx()}class Yx{constructor(e,t){const n=new Wc(an());this.comparer=t,n.contents=this,this.hashMap=new Map([]),this["init@9"]=1;const r=mt(e);try{for(;r["System.Collections.IEnumerator.MoveNext"]();){const s=r["System.Collections.Generic.IEnumerator`1.get_Current"]();xu(n.contents,s[0],s[1])}}finally{yt(r)}}get[Symbol.toStringTag](){return"Dictionary"}toJSON(){return Array.from(this)}"System.Collections.IEnumerable.GetEnumerator"(){return mt(this)}GetEnumerator(){return mt(Jv(this.hashMap.values()))}[Symbol.iterator](){return Qv(mt(this))}"System.Collections.Generic.ICollection`1.Add2B595"(e){xu(this,e[0],e[1])}"System.Collections.Generic.ICollection`1.Clear"(){Tp(this)}"System.Collections.Generic.ICollection`1.Contains2B595"(e){const n=Xl(this,e[0]);let r;switch(n!=null&&it(fa(n)[1],e[1])?(r=0,fa(n)):r=1,r){case 0:return!0;default:return!1}}"System.Collections.Generic.ICollection`1.CopyToZ3B4C077E"(e,t){eM((r,s)=>{ve(e,t+r,s)},this)}"System.Collections.Generic.ICollection`1.get_Count"(){return bp(this)|0}"System.Collections.Generic.ICollection`1.get_IsReadOnly"(){return!1}"System.Collections.Generic.ICollection`1.Remove2B595"(e){const t=this,n=Xl(t,e[0]);let r;switch(n!=null&&it(fa(n)[1],e[1])?(r=0,fa(n)):r=1,r){case 0:return yu(t,e[0]);default:return!1}}"System.Collections.Generic.IDictionary`2.Add5BDDA1"(e,t){xu(this,e,t)}"System.Collections.Generic.IDictionary`2.ContainsKey2B595"(e){return wp(this,e)}"System.Collections.Generic.IDictionary`2.get_Item2B595"(e){return Ep(this,e)}"System.Collections.Generic.IDictionary`2.set_Item5BDDA1"(e,t){Ap(this,e,t)}"System.Collections.Generic.IDictionary`2.get_Keys"(){const e=this;return ki(We(()=>xn(t=>t[0],e)))}"System.Collections.Generic.IDictionary`2.Remove2B595"(e){return yu(this,e)}"System.Collections.Generic.IDictionary`2.TryGetValue6DC89625"(e,t){const r=Xl(this,e);if(r!=null){const s=fa(r);return t.contents=s[1],!0}else return!1}"System.Collections.Generic.IDictionary`2.get_Values"(){const e=this;return ki(We(()=>xn(t=>t[1],e)))}get size(){return bp(this)|0}clear(){Tp(this)}delete(e){return yu(this,e)}entries(){return xn(t=>[t[0],t[1]],this)}get(e){return Ep(this,e)}has(e){return wp(this,e)}keys(){return xn(t=>t[0],this)}set(e,t){const n=this;return Ap(n,e,t),n}values(){return xn(t=>t[1],this)}forEach(e,t){const n=this;tM(r=>{e(r[1],r[0],n)},n)}}function Qo(i,e){const t=i.comparer.GetHashCode(e)|0;let n,r=an();return n=[q0(i.hashMap,t,new Wc(()=>r,s=>{r=s})),r],n[0]?[!0,t,n[1].findIndex(s=>i.comparer.Equals(e,s[0]))]:[!1,t,-1]}function Xl(i,e){const t=Qo(i,e);let n;switch(t[0]&&t[2]>-1?n=0:n=1,n){case 0:return w(t[2],ts(i.hashMap,t[1]));default:return}}function Tp(i){i.hashMap.clear()}function bp(i){let e=0,t=mt(i.hashMap.values());try{for(;t["System.Collections.IEnumerator.MoveNext"]();){const n=t["System.Collections.Generic.IEnumerator`1.get_Current"]();e=e+n.length|0}}finally{yt(t)}return e|0}function Ep(i,e){const t=Xl(i,e);if(t!=null)return fa(t)[1];throw rM("The item was not found in collection")}function Ap(i,e,t){const n=Qo(i,e);n[0]?n[2]>-1?ve(ts(i.hashMap,n[1]),n[2],[e,t]):ts(i.hashMap,n[1]).push([e,t]):i.hashMap.set(n[1],[[e,t]])}function xu(i,e,t){const n=Qo(i,e);if(n[0]){if(n[2]>-1)throw nM(iM("An item with the same key has already been added. Key: {0}",e));ts(i.hashMap,n[1]).push([e,t])}else i.hashMap.set(n[1],[[e,t]])}function wp(i,e){const t=Qo(i,e);let n;switch(t[0]&&t[2]>-1?n=0:n=1,n){case 0:return!0;default:return!1}}function yu(i,e){const t=Qo(i,e);let n;switch(t[0]&&t[2]>-1?n=0:n=1,n){case 0:return ts(i.hashMap,t[1]).splice(t[2],1),!0;default:return!1}}const $x=new Map([["debug","color:#8a8f98"],["info","color:#00f6ff"],["warn","color:#ffb347;font-weight:bold"],["error","color:#ff2bd6;font-weight:bold"]]),Cp=new Map([]);function Ba(i,e){const t=performance.now();let n,r=0;n=[q0(Cp,i,new Wc(()=>r,o=>{r=o})),r];let s;switch(n[0]&&t-n[1]<e?s=0:s=1,s){case 0:return!1;default:return Cp.set(i,t),!0}}function Og(i,e,t){console.log("%c"+i.toUpperCase()+"%c "+e,ts($x,i),"color:inherit",t),ch("nda:log",{level:i,message:e,fields:t})}function Qc(i,e){Og("warn",i,e)}function Rp(i,e){Og("error",i,e)}function Zx(){window.addEventListener("error",i=>{Ba("uncaught",2e3)&&Rp(Ci(i.message),{at:Ci(i.filename)+":"+Ci(i.lineno)+":"+Ci(i.colno),stack:i.error.stack==null?"":Ci(i.error.stack)})}),window.addEventListener("unhandledrejection",i=>{Ba("rejection",2e3)&&Rp("a promise failed and nothing caught it",{reason:Ci(i.reason)})})}class gr extends os{constructor(e,t,n,r,s,o){super(),this.Rocks=e,this.Pads=t,this.Crates=n,this.Track=r,this.Hole=s,this.Size=o}}function Ki(i,e){const t=e*3.141592653589793/180;return V(Math.cos(t)*i,Math.sin(t)*i)}function Kn(i,e){const t=e*3.141592653589793/180;return V(i.X*Math.cos(t)-i.Y*Math.sin(t),i.X*Math.sin(t)+i.Y*Math.cos(t))}function Dr(i){return Dt(We(()=>gn(e=>gn(t=>i(e,t),[1,-1]),[1,-1])))}function ds(i){return sM(Dt(We(()=>xn(e=>i(e*90),kt(0,1,3)))))}function Lp(i){const e=Math.sin(i*12.9898)*43758.5453;return e-Math.floor(e)}const Mo=[V(0,0),Kc(),2];function jx(i){return Ke([Mo,[V(i,0),qt(),0],[V(-i,0),qt(),0],[V(0,i),qt(),0],[V(0,-i),qt(),0],[V(i/2,0),qt(),0],[V(-i/2,0),qt(),0],[V(0,i/2),qt(),0],[V(0,-i/2),qt(),0]])}function Tu(i){return Ke([[V(i,0),On(),1],[V(-i,0),On(),1],[V(0,i),On(),1],[V(0,-i),On(),1]])}const Jx=[new gr(Dt(We(()=>Lt(gn(i=>i%3!==0?_t([Ki(430,i*30),44+Lp(i)*10]):_r(),kt(0,1,11)),We(()=>Lt(Dr((i,e)=>{const t=Ge()*.52;return Ke([[V(i*t,e*t),58],[V(i*(t+230),e*(t-180)),40],[V(i*(t-180),e*(t+230)),40]])}),We(()=>Dr((i,e)=>{const t=Ge()*.86;return Ke([[V(i*t,e*250),42],[V(i*250,e*t),42]])}))))))),Ye(jx(Ge()*.55),Tu(Ge()*.874)),Dr((i,e)=>Ke([V(i*Ge()*.35,e*Ge()*.35),V(i*Ge()*.75,e*Ge()*.75)])),void 0,void 0,mr),new gr(Dt(We(()=>Lt(ds(i=>Ke([[Kn(V(620,0),i),58],[Kn(Ki(640,15),i),42],[Kn(Ki(640,-15),i),42],[Kn(V(790,0),i),36]])),We(()=>Dr((i,e)=>{const t=Ge()*.62;return Ke([[V(i*t,e*t),48],[V(i*(t+210),e*(t-260)),38]])}))))),Ye(bn(Mo,Dr((i,e)=>{const t=Ge()*.78/Math.sqrt(2);return Ke([[V(i*t,e*t),qt(),0],[V(i*t*.45,e*t*.45),qt(),0]])})),Tu(Ge()*.86)),ds(i=>Ke([Kn(V(Ge()*.32,0),i),Kn(V(Ge()*.85,0),i)])),void 0,void 0,mr),new gr(ds(i=>Dt(We(()=>xn(e=>[Kn(Ki(320+e*160,26+e*13),i),50-e*3],kt(0,1,4))))),Ye(bn(Mo,ds(i=>Ke([[Kn(Ki(560,-24),i),qt(),0],[Kn(Ki(900,-30),i),qt(),0]]))),ds(i=>en([Kn(Ki(Ge()*.86,-8),i),On(),1]))),ds(i=>Ke([Kn(Ki(700,68),i),Kn(Ki(1080,50),i)])),void 0,void 0,mr),new gr(Dt(We(()=>Lt(gn(i=>gn(e=>{const t=-900+e*300;return Math.abs(t)>200?_t([V(t,i*340),46]):_r()},kt(0,1,6)),[1,-1]),We(()=>Lt(Dr((i,e)=>Ke([[V(i*Ge()*.82,e*Ge()*.62),50],[V(i*Ge()*.5,e*Ge()*.86),40]])),We(()=>xn(i=>[V(0,i*760),54],[1,-1]))))))),Ke([Mo,[V(420,0),qt(),0],[V(-420,0),qt(),0],[V(760,0),qt(),0],[V(-760,0),qt(),0],[V(0,560),qt(),0],[V(0,-560),qt(),0],[V(420,560),qt(),0],[V(-420,-560),qt(),0],[V(Ge()*.9,0),On(),1],[V(-(Ge()*.9),0),On(),1],[V(0,Ge()*.88),On(),1],[V(0,-(Ge()*.88)),On(),1]]),Dr((i,e)=>Ke([V(i*640,e*640),V(i*1060,e*260)])),void 0,void 0,mr),new gr(Dt(We(()=>gn(i=>i%5!==0?_t([Ki(780,i*18),52+Lp(i)*16]):_r(),kt(0,1,19)))),Ye(bn(Mo,Dr((i,e)=>Ke([[V(i*300,e*300),qt(),0],[V(i*520,e*520),qt(),0]]))),Tu(Ge()*.9)),ds(i=>Ke([Kn(V(1080,0),i),Kn(V(560,0),i)])),void 0,void 0,mr)],Pp=Ke([V(-900,-1e3),V(-400,-1e3),V(100,-1e3),V(600,-1e3),V(900,-920),V(1050,-700),V(1050,-400),V(950,-200),V(700,-100),V(600,150),V(750,400),V(1e3,500),V(1100,750),V(950,950),V(650,1e3),V(300,900),V(100,650),V(-200,550),V(-550,650),V(-750,900),V(-1050,850),V(-1150,550),V(-1050,250),V(-750,150),V(-500,-50),V(-550,-350),V(-850,-450),V(-1100,-650),V(-1050,-900)]),Ip=(()=>{const i=(e,t)=>Dt(We(()=>xn(n=>V(e+Math.cos(n*3.141592653589793/180)*250,t+Math.sin(n*3.141592653589793/180)*250),[-90,-45,0,45,90])));return Ye(Ke([V(-500,-850),V(100,-850),V(600,-850)]),Ye(i(950,-600),Ye(Ke([V(500,-350),V(150,-350),V(-150,-260),V(-380,-140),V(-380,140),V(-150,260),V(250,250),V(600,250)]),Ye(i(950,500),Ke([V(400,750),V(-200,750),V(-700,750),V(-1e3,650),V(-1150,300),V(-1180,-50),V(-1150,-400),V(-1e3,-750)])))))})(),Dp=Ke([V(350,-350),V(-350,350),V(-750,480),V(-1050,300),V(-1150,0),V(-1050,-300),V(-750,-480),V(-350,-350),V(350,350),V(750,480),V(1050,300),V(1150,0),V(1050,-300),V(750,-480)]);function bu(i,e){const t=Es(i),n=t.length|0,r=e/2;return Dt(We(()=>gn(s=>{let o;const a=~~(s[0]*n)%n|0,l=w(a,t),u=Xt(ae(w((a+1)%n,t),w((a+n-1)%n,t))),c=V(-u.Y,u.X);return gn(d=>_t([Ae(Ae(l,re(c,d[0]*r)),re(u,d[1]*r)),qt(),0]),(o=s[1]|0,o===2?Ke([[-.55,-.35],[.55,.35]]):o===3?Ke([[0,-.55],[-.6,.3],[.6,.3]]):Ke([[-.6,-.45],[.6,-.45],[-.3,.5],[.3,.5]])))},[[.06,3],[.19,2],[.32,4],[.45,2],[.58,3],[.71,2],[.86,4]])))}const Qx=[new gr(Ke([[V(0,-500),50],[V(300,300),46],[V(-200,-700),40],[V(-700,450),44]]),Ye(bu(Pp,280),Ke([[V(1050,-400),On(),1],[V(-1150,550),On(),1]])),Ke([V(600,-1e3),V(750,400),V(-550,650),V(-550,-350)]),[Pp,280,3],void 0,mr),new gr(Ke([[V(400,-50),50],[V(400,500),46],[V(-700,-50),44]]),Ye(bu(Ip,260),Ke([[V(-1180,-50),On(),1],[V(650,-350),On(),1]])),Ke([V(-200,-850),V(1200,-600),V(-300,0),V(1200,500)]),[Ip,260,3],void 0,mr),new gr(Ke([[V(0,450),46],[V(0,-450),46]]),Ye(bu(Dp,300),Ke([[V(750,480),On(),1],[V(-750,-480),On(),1]])),Ke([V(750,-480),V(-750,480),V(1050,300),V(-1050,-300)]),[Dp,300,2],void 0,mr)];function e1(i,e){let t,n,r,s;return new gr(ln(o=>[re(o[0],i),o[1]],e.Rocks),ln(o=>[re(o[0],i),o[1],o[2]],e.Pads),ln(o=>re(o,i),e.Crates),(t=e.Track,t!=null?(n=t,[ln(o=>re(o,i),n[0]),n[1]*1.15,n[2]]):void 0),(r=e.Hole,r!=null?(s=r,[re(s[0],i),s[1],s[2]]):void 0),Y0)}const Np=[],Mi=Np.length>0?Np:uh(Jx,gt((()=>{const i=Y0/mr;return e=>e1(i,e)})(),Qx));function kg(i){return w(i,Mi).Track!=null}function As(i){return w((i+1)%kn().length,kn())}function Hg(i,e,t){const n=ae(e,i),r=tn(n,n);return r<1e-9?i:Ae(i,re(n,fe(0,$e(1,tn(ae(t,i),n)/r))))}function eu(i,e,t){return ke(ae(t,Hg(i,e,t)))}function t1(i){return ot()?Fo(ls((e,t)=>eu(t,As(e),i),kn(),Float64Array),{Compare:(e,t)=>fn(e,t)|0})<dh()/2:!0}const qd=8;function n1(i){const e=i.length|0;return ki(We(()=>gn(t=>{const n=w((t+e-1)%e,i),r=w(t,i),s=w((t+1)%e,i),o=w((t+2)%e,i);return gn(a=>{const l=a/qd,u=l*l*l,c=l*l;return _t(re(Ae(Ae(Ae(re(n,-u+2*c-l),re(r,3*u-5*c+2)),re(s,-3*u+4*c+l)),re(o,u-c)),.5))},kt(0,1,qd-1))},kt(0,1,e-1))))}function tu(i){if(ot()&&kn().length>1){const e=Xt(ae(As(0),w(0,kn()))),t=V(-e.Y,e.X);return Ae(Ae(w(0,kn()),re(e,80+90*~~(i/2))),re(t,i%2===0?-60:60))}else{const e=(Ws()-320)/2;switch(i){case 0:return V(-e,-e);case 1:return V(e,-e);case 2:return V(-e,e);default:return V(e,e)}}}function i1(i){if(ot()&&kn().length>1){const e=ae(As(0),w(0,kn()));return Math.atan2(e.Y,e.X)}else return Math.atan2(-i.Y,-i.X)}function Oa(i){const e=tu(i);return new we(i,0,aM.Standard,e,zn,i1(e),Cr,0,oM,ac,!0,!0,0,!1,0,lM,0,0,0,0,0,Ie.Blaster,0,0,!1,Ni.NoTether,0,-1,Ie.Blaster,0,Math.atan2(e.Y,e.X),!1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,-999,0)}function Vg(i){const e=Oa(i.Id);return new we(e.Id,i.Team,e.Archetype,e.Pos,e.Vel,e.Angle,e.Hp,e.Shield,e.Boost,e.Stocks,e.Alive,e.Active,e.Thrusting,e.Reversing,e.RespawnIn,e.Invuln,e.Cooldown,e.Stun,e.Spin,e.Heat,e.Locked,e.Weapon,e.Ammo,e.Charge,e.Held,e.Tow,e.TowLeft,e.LastHit,e.LastWeapon,e.LaunchCd,e.LaunchAngle,e.Ghosting,e.WarpCd,e.Next,e.Laps,e.Finish,e.Streak,i.Shots,i.Hits,i.Grabs,i.Rings,i.Kills,i.FirstBloodMedal,i.DoubleKillMedals,i.TripleKillMedals,i.RailKillMedals,i.RamKillMedals,i.OnFireMedals,i.VoidMedals,i.HoleMedals,i.AbductMedals,i.GraveMedals,e.LastKillTime,e.MultiKillCount)}function Jt(i){return i.Team>0?cM(i.Team)|0:i.Id|0}function Tc(i,e){return e>=0&&e<i.length?Jt(w(e,i))|0:e-i.length|0}function nu(i,e,t){return fh((n,r)=>{let s;switch(n!=null&&ke(ae(n.Pos,t))<=ke(ae(r.Pos,t))?s=0:s=1,s){case 0:return n;default:return r}},void 0,i.filter(n=>n.Alive?Jt(n)!==Jt(w(e,i)):!1))}function ks(i,e){if(e.Invuln>0)return e;if(ot())return i>=Z0()?new we(e.Id,e.Team,e.Archetype,e.Pos,e.Vel,e.Angle,e.Hp,e.Shield,e.Boost,e.Stocks,e.Alive,e.Active,0,e.Reversing,e.RespawnIn,e.Invuln,e.Cooldown,fe(e.Stun,j0()),J0(),e.Heat,e.Locked,e.Weapon,e.Ammo,e.Charge,e.Held,e.Tow,e.TowLeft,e.LastHit,e.LastWeapon,e.LaunchCd,e.LaunchAngle,e.Ghosting,e.WarpCd,e.Next,e.Laps,e.Finish,e.Streak,e.Shots,e.Hits,e.Grabs,e.Rings,e.Kills,e.FirstBloodMedal,e.DoubleKillMedals,e.TripleKillMedals,e.RailKillMedals,e.RamKillMedals,e.OnFireMedals,e.VoidMedals,e.HoleMedals,e.AbductMedals,e.GraveMedals,e.LastKillTime,e.MultiKillCount):e;{const t=$e(e.Shield,i);return new we(e.Id,e.Team,e.Archetype,e.Pos,e.Vel,e.Angle,e.Hp-(i-t),e.Shield-t,e.Boost,e.Stocks,e.Alive,e.Active,e.Thrusting,e.Reversing,e.RespawnIn,e.Invuln,e.Cooldown,e.Stun,e.Spin,e.Heat,e.Locked,e.Weapon,e.Ammo,e.Charge,e.Held,e.Tow,e.TowLeft,e.LastHit,e.LastWeapon,e.LaunchCd,e.LaunchAngle,e.Ghosting,e.WarpCd,e.Next,e.Laps,e.Finish,e.Streak,e.Shots,e.Hits,e.Grabs,e.Rings,e.Kills,e.FirstBloodMedal,e.DoubleKillMedals,e.TripleKillMedals,e.RailKillMedals,e.RamKillMedals,e.OnFireMedals,e.VoidMedals,e.HoleMedals,e.AbductMedals,e.GraveMedals,e.LastKillTime,e.MultiKillCount)}}function cs(i,e,t){return t.Invuln>0?t:new we(t.Id,t.Team,t.Archetype,t.Pos,t.Vel,t.Angle,t.Hp,t.Shield,t.Boost,t.Stocks,t.Alive,t.Active,t.Thrusting,t.Reversing,t.RespawnIn,t.Invuln,t.Cooldown,t.Stun,t.Spin,t.Heat,t.Locked,t.Weapon,t.Ammo,t.Charge,t.Held,t.Tow,t.TowLeft,i,e,t.LaunchCd,t.LaunchAngle,t.Ghosting,t.WarpCd,t.Next,t.Laps,t.Finish,t.Streak,t.Shots,t.Hits,t.Grabs,t.Rings,t.Kills,t.FirstBloodMedal,t.DoubleKillMedals,t.TripleKillMedals,t.RailKillMedals,t.RamKillMedals,t.OnFireMedals,t.VoidMedals,t.HoleMedals,t.AbductMedals,t.GraveMedals,t.LastKillTime,t.MultiKillCount)}function Gg(i){return i.Alive?i.Hp<$0():!1}function iu(i){return i.Active&&!i.Alive?i.Stocks<=0:!1}function zg(i){return ot()||i<=Bo()?1:fe(Q0,1-(i-Bo())/uM())}function Wg(i){return ot()?!1:i.Time>Bo()}function Wo(i,e){return Math.abs(e.X)>Ge()*i+mu||Math.abs(e.Y)>Ge()*i+mu?!0:Math.abs(e.X)+Math.abs(e.Y)>Ws()*i+mu}function r1(i,e,t){return Math.abs(t.X)<Ge()*i-e&&Math.abs(t.Y)<Ge()*i-e?Math.abs(t.X)+Math.abs(t.Y)<Ws()*i-e:!1}function Yd(i,e,t,n){let r,s=n,o=zn,a=0;for(;a<40&&(a===0||(r=o,!(r1(i,120,r)&&oi().every(l=>ke(ae(l.Pos,r))>l.Radius+90)&&e.every(l=>l.Alive?ke(ae(l.Pos,r))>250:!0)&&dM(l=>ke(ae(l,r))>500,t))));){s=oc(s)|0;const l=ya(360,s)*3.141592653589793/180;s=oc(s)|0;const u=250+ya(900,s);o=re(jt(l),u),a=a+1|0}return[o,s]}function s1(i,e){const t=Math.abs(Math.cos(e)),n=Math.abs(Math.sin(e)),r=t,s=$e($e(Ge()/fe(r,1e-9),Ge()/fe(n,1e-9)),Ws()/(r+n));return re(jt(e),s*i)}function a1(i){const e=yn().length|0;return i.Laps*e+(i.Next+e-1)%e-ke(ae(i.Pos,w(i.Next,yn())))/(4*Ge())}function Kg(i){return gt(e=>e.Id|0,eg(e=>[e.Finish>0?e.Finish:Number.POSITIVE_INFINITY,-a1(e)],i.filter(e=>e.Active),{Compare:(e,t)=>tg(e,t)|0}),Int32Array)}function o1(i,e){return 1+xr(ja(t=>e===t,Kg(i)),0)|0}function l1(i,e){let t;t=e.filter(s=>s.Finish>0).length;const r=[];return[gt(s=>{if(!(ot()&&s.Alive)||ke(ae(s.Pos,w(s.Next,yn())))>Ud())return s;{const o=(s.Next+1)%yn().length|0,a=(o===1?s.Laps+1:s.Laps)|0;return a>=lc()?(t=t+1|0,r.push(new _e(25,[s.Id,t])),new we(s.Id,s.Team,s.Archetype,s.Pos,zn,s.Angle,s.Hp,s.Shield,s.Boost,s.Stocks,!1,s.Active,0,s.Reversing,s.RespawnIn,s.Invuln,s.Cooldown,s.Stun,s.Spin,s.Heat,s.Locked,s.Weapon,s.Ammo,s.Charge,s.Held,s.Tow,s.TowLeft,s.LastHit,s.LastWeapon,s.LaunchCd,s.LaunchAngle,s.Ghosting,s.WarpCd,o,a,i,s.Streak,s.Shots,s.Hits,s.Grabs,s.Rings,s.Kills,s.FirstBloodMedal,s.DoubleKillMedals,s.TripleKillMedals,s.RailKillMedals,s.RamKillMedals,s.OnFireMedals,s.VoidMedals,s.HoleMedals,s.AbductMedals,s.GraveMedals,s.LastKillTime,s.MultiKillCount)):new we(s.Id,s.Team,s.Archetype,s.Pos,s.Vel,s.Angle,s.Hp,s.Shield,s.Boost,s.Stocks,s.Alive,s.Active,s.Thrusting,s.Reversing,s.RespawnIn,s.Invuln,s.Cooldown,s.Stun,s.Spin,s.Heat,s.Locked,s.Weapon,s.Ammo,s.Charge,s.Held,s.Tow,s.TowLeft,s.LastHit,s.LastWeapon,s.LaunchCd,s.LaunchAngle,s.Ghosting,s.WarpCd,o,a,s.Finish,s.Streak,s.Shots,s.Hits,s.Grabs,s.Rings,s.Kills,s.FirstBloodMedal,s.DoubleKillMedals,s.TripleKillMedals,s.RailKillMedals,s.RamKillMedals,s.OnFireMedals,s.VoidMedals,s.HoleMedals,s.AbductMedals,s.GraveMedals,s.LastKillTime,s.MultiKillCount)}},e),An(r)]}function c1(i,e){let t;const n=i.filter(s=>s.Active),r=n.filter(s=>s.Stocks>0);if(ot()){const s=n.filter(o=>o.Finish>0);return n.length>=2&&s.length>0&&(s.length===n.length||e>=fM())?new Yr(1,[Xc(o=>o.Finish,s,{Compare:(o,a)=>fn(o,a)|0}).Id]):Yr.Playing}else return n.length>=2&&hM(s=>Jt(s)|0,r,{Equals:(s,o)=>s===o,GetHashCode:s=>pM(s)|0}).length<=1?new Yr(1,[(t=wo(r),t!=null?t.Id:void 0)]):Yr.Playing}function u1(i,e){const t=ae(e,i.Pos);return Math.abs(Math.atan2(Math.sin(Math.atan2(t.Y,t.X)-i.Angle),Math.cos(Math.atan2(t.Y,t.X)-i.Angle)))<TM()?bM():1}function Eh(i,e,t){if(t.length!==0)return yM(Xc(n=>ke(ae(e(n),i.Pos))*u1(i,e(n)),t,{Compare:(n,r)=>fn(n,r)|0}))}function Up(i,e,t){return Eh(t,n=>n.Pos,i.Ships.filter(n=>n.Alive?Jt(n)!==Jt(t):!1))}function d1(i,e){let t,n,r,s;if(it(i.Weapon,Ie.Rail))return e.Pos;{const o=it(i.Weapon,Ie.Swarm)?hh():qc(),a=ae(e.Pos,i.Pos),l=ae(e.Vel,re(i.Vel,.5)),u=tn(l,l)-o*o,c=2*tn(a,l),d=tn(a,a);return Ae(e.Pos,re(l,$e(Math.abs(u)<1e-6?Math.abs(c)<1e-6?0:fe(0,-d/c):(t=c*c-4*u*d,t<0?0:(n=Math.sqrt(t),r=$e((-c+n)/(2*u),(-c-n)/(2*u)),s=fe((-c+n)/(2*u),(-c-n)/(2*u)),r>0?r:s>0?s:0)),mM())))}}function f1(i,e){const t=ae(e,i),n=ke(t),r=Xt(t);return oi().some(s=>{const o=ae(s.Pos,i);return ke(ae(o,re(r,fe(0,$e(n,tn(o,r))))))<s.Radius})}function Eu(i){let e;const t=ke(i.Vel)>40?Xt(i.Vel):jt(i.Angle),n=180+ke(i.Vel)*.9,r=wo(eg(s=>s[0],Fd(s=>{const o=ae(s.Pos,i.Pos),a=tn(o,t),l=t.X*o.Y-t.Y*o.X;if(a>0&&a<n+s.Radius&&Math.abs(l)<s.Radius+2.5*It)return[a,l,s.Pos]},oi()),{Compare:(s,o)=>fn(s,o)|0}));if(r!=null)return e=r,Math.atan2(t.Y,t.X)-(e[1]>=0?1:-1)*.9}function Fp(i,e){const t=Xt(ae(e.Pos,i.Pos)),n=fe(0,tn(jt(e.Angle),re(t,-1)));return fe(0,tn(i.Vel,t))*Bd()*(1-Od()*n)}function h1(i,e){const t=Xt(ae(e.Pos,i.Pos)),n=tn(ae(i.Vel,e.Vel),t),r=(ke(ae(e.Pos,i.Pos))-2*It)/fe(1,n),s=Fp(e,i)/fe(1,i.Hp+i.Shield),o=Fp(i,e)/fe(1,e.Hp+e.Shield);if(n>0&&r<1&&s>=gM()&&s>=o){const a=t.X*e.Vel.Y-t.Y*e.Vel.X;return Math.atan2(t.Y,t.X)-(a>=0?1:-1)*3.141592653589793/2}else return}function Bp(i,e){let t,n;const r=e.Hole;if(n=r!=null&&ke(ae(r.Pos,i.Pos))<1.5*Math.sqrt(ng()/Oo())?r:void 0,n!=null)return t=ae(i.Pos,n.Pos),Math.atan2(t.Y,t.X)}function Op(i,e,t){let n,r;const s=e.Hp<(i?Cr:$0())&&!Wg(t)?1:e.Boost<(i?Ns:20)?0:void 0;if(s!=null){const o=s|0;r=Eh(e,a=>a.Pos,t.Pads.filter(a=>a.Kind===o?a.RespawnIn<=0:!1))}else r=void 0;if(r!=null)return n=ae(r.Pos,e.Pos),Math.atan2(n.Y,n.X)}function p1(i,e){let t;const n=Eh(i,r=>r.Pos,e.Crates.filter(r=>r.RespawnIn<=0));if(n!=null)return t=ae(n.Pos,i.Pos),Math.atan2(t.Y,t.X)}function m1(i){const e=ke(i.Pos)<1?jt(i.Angle):Xt(i.Pos);return Math.atan2(e.Y,e.X)+3.141592653589793*.6}function g1(i,e,t,n){return n<320&&t.Stun<=0?(~~(i.Time*1.7)+e)%2===0?1:-1:0}function _1(i,e){const t=ae(e.Pos,i.Pos),n=Xt(t);if(i.Hp+i.Shield<=(e.Hp+e.Shield)*_M()&&ke(t)<vM()&&tn(ae(i.Vel,e.Vel),n)>MM()&&tn(jt(e.Angle),re(n,-1))>SM())return Math.atan2(n.Y,n.X)+xM()}function kp(i,e){const t=zg(i.Time);if(Math.abs(e.Pos.X)>Ge()*t-220||Math.abs(e.Pos.Y)>Ge()*t-220)return Math.atan2(-e.Pos.Y,-e.Pos.X)}function v1(i,e){let t;const n=w(e,i.Ships),r=new ha(Pt.Turn,Pt.Aim,Pt.Absolute,Pt.Steer,Pt.Strafe,Pt.Thrust,Pt.Reverse,Pt.Boost,Pt.Fire,Pt.Special,Pt.Start,Pt.Back,Pt.Swap,!0);if(iu(n)){const s=nu(i.Ships,e,n.Pos);if(s==null)return r;{const o=s;return new ha(r.Turn,Math.atan2(o.Pos.Y,o.Pos.X),r.Absolute,r.Steer,r.Strafe,r.Thrust,r.Reverse,r.Boost,n.LaunchCd<=0,r.Special,r.Start,r.Back,r.Swap,r.Present)}}else if(n.Alive)if(ot()){const s=(n.Next+yn().length-1)%yn().length*cc()|0,o=Xc(p=>eu(w(p%kn().length,kn()),As(p),n.Pos),ki(kt(s,1,s+cc()-1)),{Compare:(p,f)=>fn(p,f)|0})|0,a=ae(ke(ae(n.Pos,As(o)))<160?As(o+1):As(o),n.Pos),l=xr(Eu(n),Math.atan2(a.Y,a.X)),u=Math.abs(Math.atan2(Math.sin(l-n.Angle),Math.cos(l-n.Angle)));let c;const d=Up(i,e,n);return c=d!=null?(t=ae(d.Pos,n.Pos),ke(t)<520&&Math.abs(Math.atan2(Math.sin(Math.atan2(t.Y,t.X)-n.Angle),Math.cos(Math.atan2(t.Y,t.X)-n.Angle)))<.25?d:void 0):void 0,new ha(r.Turn,l,r.Absolute,!0,r.Strafe,u<1.2,r.Reverse,u<.15&&n.Boost>30,r.Fire,c!=null&&!it(n.Weapon,Ie.Blaster)&&~~(i.Time*2)%2===0,r.Start,r.Back,r.Swap,r.Present)}else{const s=Up(i,e,n);if(s!=null){const o=s,a=ke(ae(o.Pos,n.Pos)),l=d1(n,o),u=ae(l,n.Pos),c=Eu(n),d=Yi(Yi(Bp(n,i),kp(i,n)),h1(n,o)),p=Op(!1,n,i),f=xr(Yi(Yi(Yi(d,c),p),_1(n,o)),Math.atan2(u.Y,u.X)),_=Math.abs(Math.atan2(Math.sin(f-n.Angle),Math.cos(f-n.Angle))),m=Math.atan2(u.Y,u.X),g=Math.abs(Math.atan2(Math.sin(m-n.Angle),Math.cos(m-n.Angle)))<.25&&c==null&&!f1(n.Pos,l),h=it(n.Weapon,Ie.Rail)?!0:it(n.Weapon,Ie.Tractor),v=it(n.Weapon,Ie.Rail)&&n.Charge>=ns();return new ha(r.Turn,f,r.Absolute,!0,g1(i,e,n,a),d!=null||p!=null||c!=null||a>320?!0:_>.6,r.Reverse,d!=null&&n.Boost>0?!0:a>900&&n.Boost>40,g&&a<650,!v&&g&&a<520&&!it(n.Weapon,Ie.Blaster)&&(h?!0:~~(i.Time*2)%2===0),r.Start,r.Back,r.Swap,r.Present)}else{const o=xr(Yi(Yi(Yi(Yi(Bp(n,i),kp(i,n)),Eu(n)),Op(!0,n,i)),p1(n,i)),m1(n));return new ha(r.Turn,o,r.Absolute,!0,r.Strafe,Math.abs(Math.atan2(Math.sin(o-n.Angle),Math.cos(o-n.Angle)))<1.2,r.Reverse,r.Boost,r.Fire,r.Special,r.Start,r.Back,r.Swap,r.Present)}}else return r}const Sa=class Sa extends Ks{constructor(e,t){super(),this.tag=e,this.fields=t}cases(){return["ContinuousPrimary","InstantSpecialPress","ChargeAndRelease","ChargeAndFireOnFull"]}};pn(Sa,"ContinuousPrimary",new Sa(0,[])),pn(Sa,"InstantSpecialPress",new Sa(1,[]));let di=Sa;const Gc=class Gc extends Ks{constructor(e,t){super(),this.tag=e,this.fields=t}cases(){return["Free","ConsumesAmmo","GeneratesHeat"]}};pn(Gc,"Free",new Gc(0,[]));let fi=Gc;const xa=class xa extends Ks{constructor(e,t){super(),this.tag=e,this.fields=t}cases(){return["BulletPayload","MinePayload","BeamPayload","WavePayload","ZapPayload","LatchPayload","DeployPayload"]}};pn(xa,"ZapPayload",new xa(4,[])),pn(xa,"LatchPayload",new xa(5,[]));let hi=xa;class Xi extends os{constructor(e,t,n,r,s,o){super(),this.Name=e,this.Trigger=t,this.Payload=n,this.Recoil=r,this.Cost=s,this.Cooldown=o}}function Xg(i,e){const t=i.Ammo-e|0;return t<=0?new we(i.Id,i.Team,i.Archetype,i.Pos,i.Vel,i.Angle,i.Hp,i.Shield,i.Boost,i.Stocks,i.Alive,i.Active,i.Thrusting,i.Reversing,i.RespawnIn,i.Invuln,i.Cooldown,i.Stun,i.Spin,i.Heat,i.Locked,Ie.Blaster,0,0,i.Held,i.Tow,i.TowLeft,i.LastHit,i.LastWeapon,i.LaunchCd,i.LaunchAngle,i.Ghosting,i.WarpCd,i.Next,i.Laps,i.Finish,i.Streak,i.Shots,i.Hits,i.Grabs,i.Rings,i.Kills,i.FirstBloodMedal,i.DoubleKillMedals,i.TripleKillMedals,i.RailKillMedals,i.RamKillMedals,i.OnFireMedals,i.VoidMedals,i.HoleMedals,i.AbductMedals,i.GraveMedals,i.LastKillTime,i.MultiKillCount):new we(i.Id,i.Team,i.Archetype,i.Pos,i.Vel,i.Angle,i.Hp,i.Shield,i.Boost,i.Stocks,i.Alive,i.Active,i.Thrusting,i.Reversing,i.RespawnIn,i.Invuln,i.Cooldown,i.Stun,i.Spin,i.Heat,i.Locked,i.Weapon,t,i.Charge,i.Held,i.Tow,i.TowLeft,i.LastHit,i.LastWeapon,i.LaunchCd,i.LaunchAngle,i.Ghosting,i.WarpCd,i.Next,i.Laps,i.Finish,i.Streak,i.Shots,i.Hits,i.Grabs,i.Rings,i.Kills,i.FirstBloodMedal,i.DoubleKillMedals,i.TripleKillMedals,i.RailKillMedals,i.RamKillMedals,i.OnFireMedals,i.VoidMedals,i.HoleMedals,i.AbductMedals,i.GraveMedals,i.LastKillTime,i.MultiKillCount)}function M1(i){return Xg(i,1)}const Hp=new Yx([[Ie.Blaster,new Xi("Blaster",di.ContinuousPrimary,new hi(0,[qc,()=>sg,Z0,0]),gu,new fi(2,[RM,()=>dc,()=>dc/ag()]),LM)],[Ie.Rail,new Xi("Rail",new di(2,[ns]),new hi(2,[()=>4]),PM,new fi(1,[1]),()=>0)],[Ie.Mines,new Xi("Mines",di.InstantSpecialPress,new hi(1,[()=>-28,()=>.4,()=>-1]),()=>0,new fi(1,[1]),()=>0)],[Ie.Swarm,new Xi("Swarm",di.InstantSpecialPress,new hi(0,[hh,()=>IM,DM,2]),()=>gu()*.6,new fi(1,[1]),()=>0)],[Ie.Pulse,new Xi("Pulse",di.InstantSpecialPress,new hi(3,[fc]),()=>fc()*.08,new fi(1,[1]),()=>0)],[Ie.Scatter,new Xi("Scatter",di.InstantSpecialPress,hi.ZapPayload,gu,new fi(1,[1]),()=>0)],[Ie.Barrier,new Xi("Barrier",di.InstantSpecialPress,new hi(6,[ko,()=>It+45,NM]),()=>0,new fi(1,[1]),()=>0)],[Ie.Sentry,new Xi("Sentry",di.InstantSpecialPress,new hi(6,[Ls,()=>-32,UM]),()=>0,new fi(1,[1]),()=>0)],[Ie.Bubble,new Xi("Bubble",di.InstantSpecialPress,new hi(6,[Yc,()=>0,()=>ot()?FM():BM()]),()=>0,new fi(1,[1]),()=>0)],[Ie.Tractor,new Xi("Tractor",new di(3,[ns]),hi.LatchPayload,()=>0,fi.Free,()=>0)]],{Equals:it,GetHashCode:i=>kd(i)|0});function Vp(i,e,t,n,r){let s;const o=r.Trigger.tag===0,a=!o&&t.Special&&!n.Held,l=o?n:new we(n.Id,n.Team,n.Archetype,n.Pos,n.Vel,n.Angle,n.Hp,n.Shield,n.Boost,n.Stocks,n.Alive,n.Active,n.Thrusting,n.Reversing,n.RespawnIn,n.Invuln,n.Cooldown,n.Stun,n.Spin,n.Heat,n.Locked,n.Weapon,n.Ammo,n.Charge,t.Special,n.Tow,n.TowLeft,n.LastHit,n.LastWeapon,n.LaunchCd,n.LaunchAngle,n.Ghosting,n.WarpCd,n.Next,n.Laps,n.Finish,n.Streak,n.Shots,n.Hits,n.Grabs,n.Rings,n.Kills,n.FirstBloodMedal,n.DoubleKillMedals,n.TripleKillMedals,n.RailKillMedals,n.RamKillMedals,n.OnFireMedals,n.VoidMedals,n.HoleMedals,n.AbductMedals,n.GraveMedals,n.LastKillTime,n.MultiKillCount);if(l.Alive){const u=jt(l.Angle),c=Ae(l.Pos,re(u,It+6));let d;const p=r.Trigger;switch(p.tag){case 1:{d=[a,l.Charge,Re()];break}case 2:{const m=p.fields[0]();d=t.Special?[!1,$e(m,l.Charge+e),a?en(new _e(11,[l.Pos])):Re()]:i&&l.Charge>=m?[!0,0,Re()]:[!1,0,Re()];break}case 3:{const m=p.fields[0]();if(t.Special&&it(l.Tow,Ni.NoTether)){const g=l.Charge+e;d=g>=m?[!0,0,en(new _e(19,[l.Pos,l.Id]))]:[!1,g,a?en(new _e(11,[l.Pos])):Re()]}else d=[!1,0,Re()];break}default:d=[t.Fire&&!ot()&&l.Cooldown<=0&&l.Locked<=0,l.Charge,Re()]}const f=d[2],_=new we(l.Id,l.Team,l.Archetype,l.Pos,l.Vel,l.Angle,l.Hp,l.Shield,l.Boost,l.Stocks,l.Alive,l.Active,l.Thrusting,l.Reversing,l.RespawnIn,l.Invuln,l.Cooldown,l.Stun,l.Spin,l.Heat,l.Locked,l.Weapon,l.Ammo,d[1],l.Held,l.Tow,l.TowLeft,l.LastHit,l.LastWeapon,l.LaunchCd,l.LaunchAngle,l.Ghosting,l.WarpCd,l.Next,l.Laps,l.Finish,l.Streak,l.Shots,l.Hits,l.Grabs,l.Rings,l.Kills,l.FirstBloodMedal,l.DoubleKillMedals,l.TripleKillMedals,l.RailKillMedals,l.RamKillMedals,l.OnFireMedals,l.VoidMedals,l.HoleMedals,l.AbductMedals,l.GraveMedals,l.LastKillTime,l.MultiKillCount);if(d[0]){const m=new we(_.Id,_.Team,_.Archetype,_.Pos,ae(_.Vel,re(u,r.Recoil())),_.Angle,_.Hp,_.Shield,_.Boost,_.Stocks,_.Alive,_.Active,_.Thrusting,_.Reversing,_.RespawnIn,_.Invuln,_.Cooldown,_.Stun,_.Spin,_.Heat,_.Locked,_.Weapon,_.Ammo,_.Charge,_.Held,_.Tow,_.TowLeft,_.LastHit,_.LastWeapon,_.LaunchCd,_.LaunchAngle,_.Ghosting,_.WarpCd,_.Next,_.Laps,_.Finish,_.Streak,_.Shots+1,_.Hits,_.Grabs,_.Rings,_.Kills,_.FirstBloodMedal,_.DoubleKillMedals,_.TripleKillMedals,_.RailKillMedals,_.RamKillMedals,_.OnFireMedals,_.VoidMedals,_.HoleMedals,_.AbductMedals,_.GraveMedals,_.LastKillTime,_.MultiKillCount);let g;const h=r.Cost;switch(h.tag){case 1:{g=Xg(m,h.fields[0]);break}case 2:{const P=h.fields[1](),E=m.Heat+h.fields[0](),A=E>=P;g=new we(m.Id,m.Team,m.Archetype,m.Pos,m.Vel,m.Angle,m.Hp,m.Shield,m.Boost,m.Stocks,m.Alive,m.Active,m.Thrusting,m.Reversing,m.RespawnIn,m.Invuln,r.Cooldown(),m.Stun,m.Spin,A?P:E,A?h.fields[2]():0,m.Weapon,m.Ammo,m.Charge,m.Held,m.Tow,m.TowLeft,m.LastHit,m.LastWeapon,m.LaunchCd,m.LaunchAngle,m.Ghosting,m.WarpCd,m.Next,m.Laps,m.Finish,m.Streak,m.Shots,m.Hits,m.Grabs,m.Rings,m.Kills,m.FirstBloodMedal,m.DoubleKillMedals,m.TripleKillMedals,m.RailKillMedals,m.RamKillMedals,m.OnFireMedals,m.VoidMedals,m.HoleMedals,m.AbductMedals,m.GraveMedals,m.LastKillTime,m.MultiKillCount);break}default:g=m}let v;const M=r.Payload;switch(M.tag){case 1:{const P=new Us(l.Id,Ae(g.Pos,re(u,M.fields[0]())),ot()?zn:re(g.Vel,M.fields[1]()),M.fields[2]());v=[Re(),en(P),en(new _e(13,[P.Pos]))];break}case 2:{v=[Re(),Re(),en(new _e(12,[c,Ae(g.Pos,re(u,M.fields[0]()*Ge())),l.Id]))];break}case 3:{v=[Re(),Re(),en(new _e(16,[g.Pos,g.Angle,l.Id]))];break}case 4:{v=[Re(),Re(),en(new _e(18,[g.Pos,g.Angle,l.Id]))];break}case 5:{v=[Re(),Re(),Re()];break}case 6:{v=[Re(),Re(),en(new _e(24,[new ga(l.Id,M.fields[0],Ae(g.Pos,re(u,M.fields[1]())),g.Angle,rg(),M.fields[2](),0)]))];break}default:v=[en(new Pa(l.Id,c,Ae(re(u,M.fields[0]()),re(g.Vel,.5)),M.fields[1](),M.fields[3],M.fields[2]())),Re(),en(new _e(4,[c]))]}const S=v[2];return[g,v[0],v[1],(s=r.Cost,s.tag===2?g.Heat>=s.fields[1]()?Ye(f,Ye(S,en(new _e(17,[l.Pos])))):Ye(f,S):Ye(f,S))]}else return[_,Re(),Re(),f]}else return[new we(l.Id,l.Team,l.Archetype,l.Pos,l.Vel,l.Angle,l.Hp,l.Shield,l.Boost,l.Stocks,l.Alive,l.Active,l.Thrusting,l.Reversing,l.RespawnIn,l.Invuln,l.Cooldown,l.Stun,l.Spin,l.Heat,l.Locked,l.Weapon,l.Ammo,0,l.Held,l.Tow,l.TowLeft,l.LastHit,l.LastWeapon,l.LaunchCd,l.LaunchAngle,l.Ghosting,l.WarpCd,l.Next,l.Laps,l.Finish,l.Streak,l.Shots,l.Hits,l.Grabs,l.Rings,l.Kills,l.FirstBloodMedal,l.DoubleKillMedals,l.TripleKillMedals,l.RailKillMedals,l.RamKillMedals,l.OnFireMedals,l.VoidMedals,l.HoleMedals,l.AbductMedals,l.GraveMedals,l.LastKillTime,l.MultiKillCount),Re(),Re(),Re()]}function S1(i,e,t,n){if(iu(n))if(t.Fire&&n.LaunchCd<=0&&n.Ghosting){const r=new Us(n.Id,n.Pos,zn,ig()*1.5);return[new we(n.Id,n.Team,n.Archetype,n.Pos,n.Vel,n.Angle,n.Hp,n.Shield,n.Boost,n.Stocks,n.Alive,n.Active,n.Thrusting,n.Reversing,n.RespawnIn,n.Invuln,n.Cooldown,n.Stun,n.Spin,n.Heat,n.Locked,n.Weapon,n.Ammo,n.Charge,n.Held,n.Tow,n.TowLeft,n.LastHit,n.LastWeapon,EM(),n.LaunchAngle,n.Ghosting,n.WarpCd,n.Next,n.Laps,n.Finish,n.Streak,n.Shots,n.Hits,n.Grabs,n.Rings,n.Kills,n.FirstBloodMedal,n.DoubleKillMedals,n.TripleKillMedals,n.RailKillMedals,n.RamKillMedals,n.OnFireMedals,n.VoidMedals,n.HoleMedals,n.AbductMedals,n.GraveMedals,n.LastKillTime,n.MultiKillCount),Re(),en(r),Re(),en(new _e(14,[n.Pos]))]}else if(t.Fire&&n.LaunchCd<=0){const r=new uc(n.Id,n.Pos,re(Xt(ae(zn,n.Pos)),AM()),ph(),wM());return[new we(n.Id,n.Team,n.Archetype,n.Pos,n.Vel,n.Angle,n.Hp,n.Shield,n.Boost,n.Stocks,n.Alive,n.Active,n.Thrusting,n.Reversing,n.RespawnIn,n.Invuln,n.Cooldown,n.Stun,n.Spin,n.Heat,n.Locked,n.Weapon,n.Ammo,n.Charge,n.Held,n.Tow,n.TowLeft,n.LastHit,n.LastWeapon,CM(),n.LaunchAngle,n.Ghosting,n.WarpCd,n.Next,n.Laps,n.Finish,n.Streak,n.Shots,n.Hits,n.Grabs,n.Rings,n.Kills,n.FirstBloodMedal,n.DoubleKillMedals,n.TripleKillMedals,n.RailKillMedals,n.RamKillMedals,n.OnFireMedals,n.VoidMedals,n.HoleMedals,n.AbductMedals,n.GraveMedals,n.LastKillTime,n.MultiKillCount),Re(),Re(),en(r),en(new _e(20,[n.Pos]))]}else return[n,Re(),Re(),Re(),Re()];else{const r=Vp(i,e,t,n,ts(Hp,Ie.Blaster)),s=r[0];let o;const a=s.Weapon;switch(a.tag){case 0:case 7:case 8:case 9:{o=[new we(s.Id,s.Team,s.Archetype,s.Pos,s.Vel,s.Angle,s.Hp,s.Shield,s.Boost,s.Stocks,s.Alive,s.Active,s.Thrusting,s.Reversing,s.RespawnIn,s.Invuln,s.Cooldown,s.Stun,s.Spin,s.Heat,s.Locked,s.Weapon,s.Ammo,0,t.Special,s.Tow,s.TowLeft,s.LastHit,s.LastWeapon,s.LaunchCd,s.LaunchAngle,s.Ghosting,s.WarpCd,s.Next,s.Laps,s.Finish,s.Streak,s.Shots,s.Hits,s.Grabs,s.Rings,s.Kills,s.FirstBloodMedal,s.DoubleKillMedals,s.TripleKillMedals,s.RailKillMedals,s.RamKillMedals,s.OnFireMedals,s.VoidMedals,s.HoleMedals,s.AbductMedals,s.GraveMedals,s.LastKillTime,s.MultiKillCount),Re(),Re(),Re()];break}default:o=Vp(i,e,t,s,ts(Hp,a))}return[o[0],Ye(r[1],o[1]),Ye(r[2],o[2]),Re(),Ye(r[3],o[3])]}}function qg(i,e){return oi().some(t=>ke(ae(t.Pos,e))<t.Radius)?!0:mh(t=>ke(ae(t.Pos,e))<t.Radius,i)}function x1(i,e,t){if(t.Kind!==2)return t;{const n=nu(e,t.Owner,t.Pos);if(n==null)return t;if(ot())return t;{const r=n,s=Math.atan2(t.Vel.Y,t.Vel.X),o=Math.atan2(r.Pos.Y-t.Pos.Y,r.Pos.X-t.Pos.X),a=Math.atan2(Math.sin(o-s),Math.cos(o-s)),l=WM()*i;return new Pa(t.Owner,t.Pos,re(jt(s+fe(-l,$e(l,a))),hh()),t.Life,t.Kind,t.Damage)}}}function y1(i,e,t,n){const r=new Pa(n.Owner,Ae(n.Pos,re(n.Vel,t)),n.Vel,n.Life-t,n.Kind,n.Damage);if(!(r.Life<=0||Wo(i,r.Pos)||qg(e,r.Pos)))return r}function T1(i,e,t,n,r,s){const o=En(a=>{if(!(a.Life<=e))return new up(a.A,a.B,a.Life-e)},s.Portals);if(s.PortalIn>e||t||!Da(o))return[o,fe(0,s.PortalIn-e),r,Re()];{const a=Yd(i,n,Re(),r),l=a[0],u=Yd(i,n,en(l),a[1]),c=u[0];return[bn(new up(l,c,dg()),o),fg(),u[1],en(new _e(21,[l,c]))]}}function b1(i,e,t,n,r,s){let o,a,l;const u=s.Hole;if(l=u!=null&&u.Life>e?u:void 0,a=l!=null?(o=l,new zd(o.Pos,o.Life-e)):void 0,s.HoleIn>e||t||a!=null)return[a,fe(0,s.HoleIn-e),r,Re()];{const c=Yd(i,n,po(p=>Ke([p.A,p.B]),s.Portals),r),d=c[0];return[new zd(d,hg()),pg(),c[1],en(new _e(23,[d]))]}}function ql(i,e,t,n){if(i==null)return n;{const r=ae(i.Pos,t),s=fe(Ia(),ke(r));return Ae(n,re(Xt(r),ng()/(s*s)*e))}}function E1(i,e,t){return gt(n=>{let r,s;switch(i!=null?(r=i,n.Alive&&ke(ae(r.Pos,n.Pos))<Ia()?s=0:n.Alive?s=1:s=2):s=2,s){case 0:return new we(n.Id,n.Team,n.Archetype,n.Pos,n.Vel,n.Angle,0,n.Shield,n.Boost,n.Stocks,n.Alive,n.Active,n.Thrusting,n.Reversing,n.RespawnIn,n.Invuln,n.Cooldown,n.Stun,n.Spin,n.Heat,n.Locked,n.Weapon,n.Ammo,n.Charge,n.Held,n.Tow,n.TowLeft,n.LastHit,Ie.Singularity,n.LaunchCd,n.LaunchAngle,n.Ghosting,n.WarpCd,n.Next,n.Laps,n.Finish,n.Streak,n.Shots,n.Hits,n.Grabs,n.Rings,n.Kills,n.FirstBloodMedal,n.DoubleKillMedals,n.TripleKillMedals,n.RailKillMedals,n.RamKillMedals,n.OnFireMedals,n.VoidMedals,n.HoleMedals,n.AbductMedals,n.GraveMedals,n.LastKillTime,n.MultiKillCount);case 1:return new we(n.Id,n.Team,n.Archetype,n.Pos,ql(i,e,n.Pos,n.Vel),n.Angle,n.Hp,n.Shield,n.Boost,n.Stocks,n.Alive,n.Active,n.Thrusting,n.Reversing,n.RespawnIn,n.Invuln,n.Cooldown,n.Stun,n.Spin,n.Heat,n.Locked,n.Weapon,n.Ammo,n.Charge,n.Held,n.Tow,n.TowLeft,n.LastHit,n.LastWeapon,n.LaunchCd,n.LaunchAngle,n.Ghosting,n.WarpCd,n.Next,n.Laps,n.Finish,n.Streak,n.Shots,n.Hits,n.Grabs,n.Rings,n.Kills,n.FirstBloodMedal,n.DoubleKillMedals,n.TripleKillMedals,n.RailKillMedals,n.RamKillMedals,n.OnFireMedals,n.VoidMedals,n.HoleMedals,n.AbductMedals,n.GraveMedals,n.LastKillTime,n.MultiKillCount);default:return n}},t)}function Yl(i,e,t){return KM(n=>{const r=(s,o)=>Ae(o,re(ke(t)>1e-6?Xt(t):Xt(ae(o,s)),Ta()+4));return ke(ae(e,n.A))<Ta()?r(n.A,n.B):ke(ae(e,n.B))<Ta()?r(n.B,n.A):void 0},i)}function A1(i,e,t){const n=[];return[gt(r=>{const s=new we(r.Id,r.Team,r.Archetype,r.Pos,r.Vel,r.Angle,r.Hp,r.Shield,r.Boost,r.Stocks,r.Alive,r.Active,r.Thrusting,r.Reversing,r.RespawnIn,r.Invuln,r.Cooldown,r.Stun,r.Spin,r.Heat,r.Locked,r.Weapon,r.Ammo,r.Charge,r.Held,r.Tow,r.TowLeft,r.LastHit,r.LastWeapon,r.LaunchCd,r.LaunchAngle,r.Ghosting,fe(0,r.WarpCd-i),r.Next,r.Laps,r.Finish,r.Streak,r.Shots,r.Hits,r.Grabs,r.Rings,r.Kills,r.FirstBloodMedal,r.DoubleKillMedals,r.TripleKillMedals,r.RailKillMedals,r.RamKillMedals,r.OnFireMedals,r.VoidMedals,r.HoleMedals,r.AbductMedals,r.GraveMedals,r.LastKillTime,r.MultiKillCount);if(s.Alive&&s.WarpCd<=0){const o=Yl(e,s.Pos,s.Vel);if(o==null)return s;{const a=o;return n.push(new _e(22,[s.Pos])),n.push(new _e(22,[a])),new we(s.Id,s.Team,s.Archetype,a,s.Vel,s.Angle,s.Hp,s.Shield,s.Boost,s.Stocks,s.Alive,s.Active,s.Thrusting,s.Reversing,s.RespawnIn,s.Invuln,s.Cooldown,s.Stun,s.Spin,s.Heat,s.Locked,s.Weapon,s.Ammo,s.Charge,s.Held,s.Tow,s.TowLeft,s.LastHit,s.LastWeapon,s.LaunchCd,s.LaunchAngle,s.Ghosting,.5,s.Next,s.Laps,s.Finish,s.Streak,s.Shots,s.Hits,s.Grabs,s.Rings,s.Kills,s.FirstBloodMedal,s.DoubleKillMedals,s.TripleKillMedals,s.RailKillMedals,s.RamKillMedals,s.OnFireMedals,s.VoidMedals,s.HoleMedals,s.AbductMedals,s.GraveMedals,s.LastKillTime,s.MultiKillCount)}}else return s},t),An(n)]}function Gp(i){const e=re(jt(i.Angle+1.5707963267948966),_h()/2);return[ae(i.Pos,e),Ae(i.Pos,e)]}function zp(i,e,t,n,r){return mh(s=>s.Kind===Yc&&Tc(i,s.Owner)!==t?ke(ae(s.Pos,n))<Co():!1,e)?r*OM():r}function w1(i,e,t){const n=[],r=[];return[En(s=>{if(s.Life<=i||s.Kind===Ls&&s.Hp<=0){s.Kind===Ls&&r.push(new _e(15,[s.Pos]));return}else{if(s.Kind!==Ls)return new ga(s.Owner,s.Kind,s.Pos,s.Angle,s.Hp,s.Life-i,s.Cooldown);{const o=fe(0,s.Cooldown-i),a=new ga(s.Owner,s.Kind,s.Pos,s.Angle,s.Hp,s.Life-i,o),l=nu(e,a.Owner,a.Pos);let u,c;switch(l!=null&&ke(ae(l.Pos,a.Pos))<VM()?(u=0,c=l):u=1,u){case 0:{const d=Math.atan2(c.Pos.Y-a.Pos.Y,c.Pos.X-a.Pos.X);if(o>0||ot())return new ga(a.Owner,a.Kind,a.Pos,d,a.Hp,a.Life,a.Cooldown);{const p=jt(d),f=Ae(a.Pos,re(p,Zi+4));return n.push(new Pa(a.Owner,f,re(p,qc()),sg,0,GM())),r.push(new _e(4,[f])),new ga(a.Owner,a.Kind,a.Pos,d,a.Hp,a.Life,zM())}}default:return a}}}},t),An(n),An(r)]}function C1(i,e,t){const n=[];return[En(r=>{const s=e(r),o=new uc(r.Owner,Ae(r.Pos,re(r.Vel,s)),r.Vel,r.Radius,r.Life-s),a=oi().some(l=>ke(ae(l.Pos,o.Pos))<l.Radius+o.Radius);if(a&&n.push(new _e(6,[o.Pos])),!(o.Life<=0||a||Wo(i,o.Pos)))return o},t),An(n)]}function R1(i,e){const t=Si(i),n=[],r=mt(e);try{for(;r["System.Collections.IEnumerator.MoveNext"]();){const s=r["System.Collections.Generic.IEnumerator`1.get_Current"](),o=s[2]|0,a=s[1],l=s[0],u=Xt(ae(a,l));for(let c=0;c<=t.length-1;c++){let d,p,f;w(c,t).Alive&&Jt(w(c,t))!==Jt(w(o,t))&&eu(l,a,w(c,t).Pos)<It+6&&(n.push(new _e(0,[w(c,t).Pos,"Rail",cp(),c])),w(c,t).Invuln<=0&&ve(t,o,(d=w(o,t),new we(d.Id,d.Team,d.Archetype,d.Pos,d.Vel,d.Angle,d.Hp,d.Shield,d.Boost,d.Stocks,d.Alive,d.Active,d.Thrusting,d.Reversing,d.RespawnIn,d.Invuln,d.Cooldown,d.Stun,d.Spin,d.Heat,d.Locked,d.Weapon,d.Ammo,d.Charge,d.Held,d.Tow,d.TowLeft,d.LastHit,d.LastWeapon,d.LaunchCd,d.LaunchAngle,d.Ghosting,d.WarpCd,d.Next,d.Laps,d.Finish,d.Streak,d.Shots,w(o,t).Hits+1,d.Grabs,d.Rings,d.Kills,d.FirstBloodMedal,d.DoubleKillMedals,d.TripleKillMedals,d.RailKillMedals,d.RamKillMedals,d.OnFireMedals,d.VoidMedals,d.HoleMedals,d.AbductMedals,d.GraveMedals,d.LastKillTime,d.MultiKillCount))),ve(t,c,(p=cs(o,Ie.Rail,(f=w(c,t),new we(f.Id,f.Team,f.Archetype,f.Pos,Ae(w(c,t).Vel,re(u,cg())),f.Angle,f.Hp,f.Shield,f.Boost,f.Stocks,f.Alive,f.Active,f.Thrusting,f.Reversing,f.RespawnIn,f.Invuln,f.Cooldown,f.Stun,f.Spin,f.Heat,f.Locked,f.Weapon,f.Ammo,f.Charge,f.Held,f.Tow,f.TowLeft,f.LastHit,f.LastWeapon,f.LaunchCd,f.LaunchAngle,f.Ghosting,f.WarpCd,f.Next,f.Laps,f.Finish,f.Streak,f.Shots,f.Hits,f.Grabs,f.Rings,f.Kills,f.FirstBloodMedal,f.DoubleKillMedals,f.TripleKillMedals,f.RailKillMedals,f.RamKillMedals,f.OnFireMedals,f.VoidMedals,f.HoleMedals,f.AbductMedals,f.GraveMedals,f.LastKillTime,f.MultiKillCount))),ks(cp(),p))))}}}finally{yt(r)}return[t,An(n)]}function Yg(i,e,t,n,r,s,o){const a=ae(w(o,i).Pos,e),l=ke(a);if(w(o,i).Alive&&Jt(w(o,i))!==Jt(w(s,i))&&l<n&&l>1e-6){const u=Math.atan2(a.Y,a.X)-t,c=Math.atan2(Math.sin(u),Math.cos(u));return Math.abs(c)<r?[Xt(a),1-l/n]:void 0}else return}function L1(i,e){const t=Si(i),n=mt(e);try{for(;n["System.Collections.IEnumerator.MoveNext"]();){const r=n["System.Collections.Generic.IEnumerator`1.get_Current"](),s=r[2]|0;for(let o=0;o<=t.length-1;o++){let a;const l=Yg(t,r[0],r[1],ot()?kM():og(),lg(),s,o);if(l!=null){const u=l[0],c=l[1];ve(t,o,cs(s,Ie.Pulse,(a=w(o,t),new we(a.Id,a.Team,a.Archetype,a.Pos,Ae(w(o,t).Vel,re(u,fc()*c)),a.Angle,a.Hp,a.Shield,a.Boost,a.Stocks,a.Alive,a.Active,a.Thrusting,a.Reversing,a.RespawnIn,a.Invuln,a.Cooldown,a.Stun,a.Spin,a.Heat,a.Locked,a.Weapon,a.Ammo,a.Charge,a.Held,a.Tow,a.TowLeft,a.LastHit,a.LastWeapon,a.LaunchCd,a.LaunchAngle,a.Ghosting,a.WarpCd,a.Next,a.Laps,a.Finish,a.Streak,a.Shots,a.Hits,a.Grabs,a.Rings,a.Kills,a.FirstBloodMedal,a.DoubleKillMedals,a.TripleKillMedals,a.RailKillMedals,a.RamKillMedals,a.OnFireMedals,a.VoidMedals,a.HoleMedals,a.AbductMedals,a.GraveMedals,a.LastKillTime,a.MultiKillCount))))}}}}finally{yt(n)}return t}function P1(i,e){const t=Si(i),n=[],r=mt(e);try{for(;r["System.Collections.IEnumerator.MoveNext"]();){const s=r["System.Collections.Generic.IEnumerator`1.get_Current"](),o=s[2]|0;for(let a=0;a<=t.length-1;a++){let l,u,c;Yg(t,s[0],s[1],Hd(),Vd(),o,a)==null||(n.push(new _e(0,[w(a,t).Pos,"Scatter",lp(),a])),w(a,t).Invuln<=0&&ve(t,o,(l=w(o,t),new we(l.Id,l.Team,l.Archetype,l.Pos,l.Vel,l.Angle,l.Hp,l.Shield,l.Boost,l.Stocks,l.Alive,l.Active,l.Thrusting,l.Reversing,l.RespawnIn,l.Invuln,l.Cooldown,l.Stun,l.Spin,l.Heat,l.Locked,l.Weapon,l.Ammo,l.Charge,l.Held,l.Tow,l.TowLeft,l.LastHit,l.LastWeapon,l.LaunchCd,l.LaunchAngle,l.Ghosting,l.WarpCd,l.Next,l.Laps,l.Finish,l.Streak,l.Shots,w(o,t).Hits+1,l.Grabs,l.Rings,l.Kills,l.FirstBloodMedal,l.DoubleKillMedals,l.TripleKillMedals,l.RailKillMedals,l.RamKillMedals,l.OnFireMedals,l.VoidMedals,l.HoleMedals,l.AbductMedals,l.GraveMedals,l.LastKillTime,l.MultiKillCount))),ve(t,a,(u=cs(o,Ie.Scatter,(c=w(a,t),new we(c.Id,c.Team,c.Archetype,c.Pos,c.Vel,c.Angle,c.Hp,c.Shield,c.Boost,c.Stocks,c.Alive,c.Active,0,c.Reversing,c.RespawnIn,c.Invuln,c.Cooldown,fe(w(a,t).Stun,j0()),c.Spin,c.Heat,c.Locked,c.Weapon,c.Ammo,c.Charge,c.Held,c.Tow,c.TowLeft,c.LastHit,c.LastWeapon,c.LaunchCd,c.LaunchAngle,c.Ghosting,c.WarpCd,c.Next,c.Laps,c.Finish,c.Streak,c.Shots,c.Hits,c.Grabs,c.Rings,c.Kills,c.FirstBloodMedal,c.DoubleKillMedals,c.TripleKillMedals,c.RailKillMedals,c.RamKillMedals,c.OnFireMedals,c.VoidMedals,c.HoleMedals,c.AbductMedals,c.GraveMedals,c.LastKillTime,c.MultiKillCount))),ks(lp(),u))))}}}finally{yt(r)}return[t,An(n)]}function I1(i,e){const t=w(e,i),n=(a,l,u)=>{const c=ae(a,t.Pos),d=Math.atan2(c.Y,c.X)-t.Angle,p=Math.abs(Math.atan2(Math.sin(d),Math.cos(d))),f=ke(c)-l;if(f<Ho()&&p<ZM())return[ot()?f:p,u]},r=Fd(a=>{if(a.Alive&&Jt(a)!==Jt(t))return n(a.Pos,0,new Ni(1,[a.Id]))},i),s=Fd(a=>a,ls((a,l)=>n(l.Pos,l.Radius,new Ni(2,[a])),oi())),o=r.length>0?r:s;return!YM(jM,o,an())&&o.length===0?Ni.NoTether:Xc(a=>a[0],o,{Compare:(a,l)=>fn(a,l)|0})[1]}function D1(i,e,t){const n=Si(e),r=mt(t);try{for(;r["System.Collections.IEnumerator.MoveNext"]();){let s;const o=r["System.Collections.Generic.IEnumerator`1.get_Current"]()|0;if(it(w(o,n).Tow,Ni.NoTether)){const a=I1(n,o);a.tag===0||ve(n,o,(s=M1(w(o,n)),new we(s.Id,s.Team,s.Archetype,s.Pos,s.Vel,s.Angle,s.Hp,s.Shield,s.Boost,s.Stocks,s.Alive,s.Active,s.Thrusting,s.Reversing,s.RespawnIn,s.Invuln,s.Cooldown,s.Stun,s.Spin,s.Heat,s.Locked,s.Weapon,s.Ammo,s.Charge,s.Held,a,HM(),s.LastHit,s.LastWeapon,s.LaunchCd,s.LaunchAngle,s.Ghosting,s.WarpCd,s.Next,s.Laps,s.Finish,s.Streak,s.Shots,s.Hits,s.Grabs,s.Rings,s.Kills,s.FirstBloodMedal,s.DoubleKillMedals,s.TripleKillMedals,s.RailKillMedals,s.RamKillMedals,s.OnFireMedals,s.VoidMedals,s.HoleMedals,s.AbductMedals,s.GraveMedals,s.LastKillTime,s.MultiKillCount)))}}}finally{yt(r)}for(let s=0;s<=n.length-1;s++){let o,a,l,u;const c=w(s,n),d=()=>{let f;ve(n,s,(f=w(s,n),new we(f.Id,f.Team,f.Archetype,f.Pos,f.Vel,f.Angle,f.Hp,f.Shield,f.Boost,f.Stocks,f.Alive,f.Active,f.Thrusting,f.Reversing,f.RespawnIn,f.Invuln,f.Cooldown,f.Stun,f.Spin,f.Heat,f.Locked,f.Weapon,f.Ammo,f.Charge,f.Held,Ni.NoTether,0,f.LastHit,f.LastWeapon,f.LaunchCd,f.LaunchAngle,f.Ghosting,f.WarpCd,f.Next,f.Laps,f.Finish,f.Streak,f.Shots,f.Hits,f.Grabs,f.Rings,f.Kills,f.FirstBloodMedal,f.DoubleKillMedals,f.TripleKillMedals,f.RailKillMedals,f.RamKillMedals,f.OnFireMedals,f.VoidMedals,f.HoleMedals,f.AbductMedals,f.GraveMedals,f.LastKillTime,f.MultiKillCount)))},p=(f,_)=>re(Xt(ae(_,f)),$M()*i);if(!it(c.Tow,Ni.NoTether))if(!c.Alive||c.TowLeft<=i)d();else{const f=c.Tow;let _,m,g;switch(f.tag){case 1:{l=f.fields[0]|0,w(l,n).Alive&&ke(ae(w(l,n).Pos,c.Pos))<Ho()*1.3?(_=0,m=f.fields[0]):_=2;break}case 2:{u=f.fields[0]|0,ke(ae(w(u,oi()).Pos,c.Pos))>w(u,oi()).Radius+2*It?(_=1,g=f.fields[0]):_=2;break}default:_=2}switch(_){case 0:{ve(n,m,cs(s,Ie.Tractor,(o=w(m,n),new we(o.Id,o.Team,o.Archetype,o.Pos,Ae(w(m,n).Vel,p(w(m,n).Pos,c.Pos)),o.Angle,o.Hp,o.Shield,o.Boost,o.Stocks,o.Alive,o.Active,o.Thrusting,o.Reversing,o.RespawnIn,o.Invuln,o.Cooldown,o.Stun,o.Spin,o.Heat,o.Locked,o.Weapon,o.Ammo,o.Charge,o.Held,o.Tow,o.TowLeft,o.LastHit,o.LastWeapon,o.LaunchCd,o.LaunchAngle,o.Ghosting,o.WarpCd,o.Next,o.Laps,o.Finish,o.Streak,o.Shots,o.Hits,o.Grabs,o.Rings,o.Kills,o.FirstBloodMedal,o.DoubleKillMedals,o.TripleKillMedals,o.RailKillMedals,o.RamKillMedals,o.OnFireMedals,o.VoidMedals,o.HoleMedals,o.AbductMedals,o.GraveMedals,o.LastKillTime,o.MultiKillCount)))),ve(n,s,(a=w(s,n),new we(a.Id,a.Team,a.Archetype,a.Pos,a.Vel,a.Angle,a.Hp,a.Shield,a.Boost,a.Stocks,a.Alive,a.Active,a.Thrusting,a.Reversing,a.RespawnIn,a.Invuln,a.Cooldown,a.Stun,a.Spin,a.Heat,a.Locked,a.Weapon,a.Ammo,a.Charge,a.Held,a.Tow,c.TowLeft-i,a.LastHit,a.LastWeapon,a.LaunchCd,a.LaunchAngle,a.Ghosting,a.WarpCd,a.Next,a.Laps,a.Finish,a.Streak,a.Shots,a.Hits,a.Grabs,a.Rings,a.Kills,a.FirstBloodMedal,a.DoubleKillMedals,a.TripleKillMedals,a.RailKillMedals,a.RamKillMedals,a.OnFireMedals,a.VoidMedals,a.HoleMedals,a.AbductMedals,a.GraveMedals,a.LastKillTime,a.MultiKillCount)));break}case 1:{ve(n,s,new we(c.Id,c.Team,c.Archetype,c.Pos,Ae(c.Vel,p(c.Pos,w(g,oi()).Pos)),c.Angle,c.Hp,c.Shield,c.Boost,c.Stocks,c.Alive,c.Active,c.Thrusting,c.Reversing,c.RespawnIn,c.Invuln,c.Cooldown,c.Stun,c.Spin,c.Heat,c.Locked,c.Weapon,c.Ammo,c.Charge,c.Held,c.Tow,c.TowLeft-i,c.LastHit,c.LastWeapon,c.LaunchCd,c.LaunchAngle,c.Ghosting,c.WarpCd,c.Next,c.Laps,c.Finish,c.Streak,c.Shots,c.Hits,c.Grabs,c.Rings,c.Kills,c.FirstBloodMedal,c.DoubleKillMedals,c.TripleKillMedals,c.RailKillMedals,c.RamKillMedals,c.OnFireMedals,c.VoidMedals,c.HoleMedals,c.AbductMedals,c.GraveMedals,c.LastKillTime,c.MultiKillCount));break}case 2:{d();break}}}}return n}function N1(i,e,t,n){const r=[],s=[];return[En(o=>{let a;const l=e(o),u=nu(t,o.Owner,o.Pos);if(ot()){let c;switch(u!=null&&ke(ae(u.Pos,o.Pos))<ug+It?c=0:c=1,c){case 0:{s.push([o.Pos,o.Owner]),r.push(new _e(15,[o.Pos]));return}default:return o}}else if(o.Fuse<0){let c;switch(u!=null&&ke(ae(u.Pos,o.Pos))<hc()?c=0:c=1,c){case 0:return r.push(new _e(14,[o.Pos])),new Us(o.Owner,o.Pos,o.Vel,ig());default:return o}}else if(o.Fuse<=l||qg(Re(),o.Pos)||Wo(i,o.Pos)){s.push([o.Pos,o.Owner]),r.push(new _e(15,[o.Pos]));return}else{const c=gh(260,re(Ae(o.Vel,u==null?zn:re(Xt(ae(u.Pos,o.Pos)),XM()*l)),1-.9*l));return a=o.Fuse-l,new Us(o.Owner,Ae(o.Pos,re(c,l)),c,a)}},n),An(s),An(r)]}function U1(i,e){const t=Si(i),n=[],r=mt(e);try{for(;r["System.Collections.IEnumerator.MoveNext"]();){const s=r["System.Collections.Generic.IEnumerator`1.get_Current"]();for(let o=0;o<=t.length-1;o++){let a;const l=ae(w(o,t).Pos,s[0]),u=ke(l);if(w(o,t).Alive&&u<Gd()){const c=1-u/Gd(),d=qM()*c;d>0&&n.push(new _e(0,[w(o,t).Pos,"Mines",d,o])),ve(t,o,ks(d,cs(s[1],Ie.Mines,(a=w(o,t),new we(a.Id,a.Team,a.Archetype,a.Pos,Ae(w(o,t).Vel,re(Xt(l),fc()*c)),a.Angle,a.Hp,a.Shield,a.Boost,a.Stocks,a.Alive,a.Active,a.Thrusting,a.Reversing,a.RespawnIn,a.Invuln,a.Cooldown,a.Stun,a.Spin,a.Heat,a.Locked,a.Weapon,a.Ammo,a.Charge,a.Held,a.Tow,a.TowLeft,a.LastHit,a.LastWeapon,a.LaunchCd,a.LaunchAngle,a.Ghosting,a.WarpCd,a.Next,a.Laps,a.Finish,a.Streak,a.Shots,a.Hits,a.Grabs,a.Rings,a.Kills,a.FirstBloodMedal,a.DoubleKillMedals,a.TripleKillMedals,a.RailKillMedals,a.RamKillMedals,a.OnFireMedals,a.VoidMedals,a.HoleMedals,a.AbductMedals,a.GraveMedals,a.LastKillTime,a.MultiKillCount)))))}}}}finally{yt(r)}return[t,An(n)]}function hr(i,e){return i.X*e.Y-i.Y*e.X}function $d(i,e){return V(-i*e.Y,i*e.X)}function $g(){return .5*It*It*eS()}function Zg(i,e,t){const n=ae(i,re(e,t)),r=ke(n);return r<1e-6?[zn,0]:[re(n,1/r),r]}function jg(i,e,t,n,r){const s=ae(i,r.Pos),o=ae(Ae(r.Vel,$d(r.Spin,s)),t),a=tn(o,e);if(a>=0)return[r,0];{const l=$g(),u=hr(s,e),c=-1.85*a/(1+n+u*u/l),d=Zg(o,e,a),p=d[1],f=d[0];let _;if(p===0)_=0;else{const g=hr(s,f),h=-p/(1+n+g*g/l);_=fe(-pc()*c,$e(pc()*c,h))}const m=Ae(re(e,c),re(f,_));return[new we(r.Id,r.Team,r.Archetype,r.Pos,Ae(r.Vel,m),r.Angle,r.Hp,r.Shield,r.Boost,r.Stocks,r.Alive,r.Active,r.Thrusting,r.Reversing,r.RespawnIn,r.Invuln,r.Cooldown,r.Stun,r.Spin+hr(s,m)/l,r.Heat,r.Locked,r.Weapon,r.Ammo,r.Charge,r.Held,r.Tow,r.TowLeft,r.LastHit,r.LastWeapon,r.LaunchCd,r.LaunchAngle,r.Ghosting,r.WarpCd,r.Next,r.Laps,r.Finish,r.Streak,r.Shots,r.Hits,r.Grabs,r.Rings,r.Kills,r.FirstBloodMedal,r.DoubleKillMedals,r.TripleKillMedals,r.RailKillMedals,r.RamKillMedals,r.OnFireMedals,r.VoidMedals,r.HoleMedals,r.AbductMedals,r.GraveMedals,r.LastKillTime,r.MultiKillCount),c]}}function F1(i,e,t,n){const r=ae(i,t.Pos),s=ae(i,n.Pos),o=r,a=ae(Ae(n.Vel,$d(n.Spin,s)),Ae(t.Vel,$d(t.Spin,o))),l=tn(a,e);if(l>=0)return[t,n,0];{const u=$g(),c=hr(o,e),d=hr(s,e),p=c,f=-1.85*l/(2+(p*p+d*d)/u),_=Zg(a,e,l),m=_[1],g=_[0];let h;if(m===0)h=0;else{const M=hr(o,g),S=hr(s,g),P=M,E=-m/(2+(P*P+S*S)/u);h=fe(-pc()*f,$e(pc()*f,E))}const v=Ae(re(e,f),re(g,h));return[new we(t.Id,t.Team,t.Archetype,t.Pos,ae(t.Vel,v),t.Angle,t.Hp,t.Shield,t.Boost,t.Stocks,t.Alive,t.Active,t.Thrusting,t.Reversing,t.RespawnIn,t.Invuln,t.Cooldown,t.Stun,t.Spin-hr(o,v)/u,t.Heat,t.Locked,t.Weapon,t.Ammo,t.Charge,t.Held,t.Tow,t.TowLeft,t.LastHit,t.LastWeapon,t.LaunchCd,t.LaunchAngle,t.Ghosting,t.WarpCd,t.Next,t.Laps,t.Finish,t.Streak,t.Shots,t.Hits,t.Grabs,t.Rings,t.Kills,t.FirstBloodMedal,t.DoubleKillMedals,t.TripleKillMedals,t.RailKillMedals,t.RamKillMedals,t.OnFireMedals,t.VoidMedals,t.HoleMedals,t.AbductMedals,t.GraveMedals,t.LastKillTime,t.MultiKillCount),new we(n.Id,n.Team,n.Archetype,n.Pos,Ae(n.Vel,v),n.Angle,n.Hp,n.Shield,n.Boost,n.Stocks,n.Alive,n.Active,n.Thrusting,n.Reversing,n.RespawnIn,n.Invuln,n.Cooldown,n.Stun,n.Spin+hr(s,v)/u,n.Heat,n.Locked,n.Weapon,n.Ammo,n.Charge,n.Held,n.Tow,n.TowLeft,n.LastHit,n.LastWeapon,n.LaunchCd,n.LaunchAngle,n.Ghosting,n.WarpCd,n.Next,n.Laps,n.Finish,n.Streak,n.Shots,n.Hits,n.Grabs,n.Rings,n.Kills,n.FirstBloodMedal,n.DoubleKillMedals,n.TripleKillMedals,n.RailKillMedals,n.RamKillMedals,n.OnFireMedals,n.VoidMedals,n.HoleMedals,n.AbductMedals,n.GraveMedals,n.LastKillTime,n.MultiKillCount),f]}}function Jg(i,e,t,n){return new we(n.Id,n.Team,n.Archetype,Ae(i,re(e,t)),n.Vel,n.Angle,n.Hp,n.Shield,n.Boost,n.Stocks,n.Alive,n.Active,n.Thrusting,n.Reversing,n.RespawnIn,n.Invuln,n.Cooldown,n.Stun,n.Spin,n.Heat,n.Locked,n.Weapon,n.Ammo,n.Charge,n.Held,n.Tow,n.TowLeft,n.LastHit,n.LastWeapon,n.LaunchCd,n.LaunchAngle,n.Ghosting,n.WarpCd,n.Next,n.Laps,n.Finish,n.Streak,n.Shots,n.Hits,n.Grabs,n.Rings,n.Kills,n.FirstBloodMedal,n.DoubleKillMedals,n.TripleKillMedals,n.RailKillMedals,n.RamKillMedals,n.OnFireMedals,n.VoidMedals,n.HoleMedals,n.AbductMedals,n.GraveMedals,n.LastKillTime,n.MultiKillCount)}function B1(i,e){const t=$e(1,i/tS());return t<.05?e:new we(e.Id,e.Team,e.Archetype,e.Pos,e.Vel,e.Angle,e.Hp,e.Shield,e.Boost,e.Stocks,e.Alive,e.Active,0,e.Reversing,e.RespawnIn,e.Invuln,e.Cooldown,fe(e.Stun,nS()*t),e.Spin,e.Heat,e.Locked,e.Weapon,e.Ammo,e.Charge,e.Held,e.Tow,e.TowLeft,e.LastHit,e.LastWeapon,e.LaunchCd,e.LaunchAngle,e.Ghosting,e.WarpCd,e.Next,e.Laps,e.Finish,e.Streak,e.Shots,e.Hits,e.Grabs,e.Rings,e.Kills,e.FirstBloodMedal,e.DoubleKillMedals,e.TripleKillMedals,e.RailKillMedals,e.RamKillMedals,e.OnFireMedals,e.VoidMedals,e.HoleMedals,e.AbductMedals,e.GraveMedals,e.LastKillTime,e.MultiKillCount)}function O1(i,e){const t=e*(1-$e(1,JM()*i));return Math.abs(t)<QM()?0:t}function Qg(){return Na()===2?1.5:1}function e_(){return Na()===3?.25:1}function k1(i,e,t){const n=Qg();let r;const s=e.Aim;if(s==null)r=t.Angle+e.Turn*Vo()*n*i;else if(!e.Steer)r=s;else{const f=s,_=Math.atan2(Math.sin(f-t.Angle),Math.cos(f-t.Angle)),m=Vo()*n*i;r=t.Angle+fe(-m,$e(m,_))}const o=e.Boost,a=o?2:e.Thrust||e.Boost?1:0,l=o?mg()*n:a>0?Oo()*n:e.Reverse?-Oo()*gg()*n:0;let u;const c=re(Ae(t.Vel,re(Ae(re(jt(r),l),re(jt(r+3.141592653589793/2),e.Strafe*vg()*n)),i)),1-_g()*e_()*i);u=gh(vh()*n,c);const d=Ae(t.Pos,re(u,i)),p=f=>fe(-Ge(),$e(Ge(),f));return new we(t.Id,t.Team,t.Archetype,V(p(d.X),p(d.Y)),u,r,t.Hp,t.Shield,Ns,t.Stocks,t.Alive,t.Active,a,l<0,t.RespawnIn,t.Invuln,t.Cooldown,t.Stun,t.Spin,t.Heat,t.Locked,t.Weapon,t.Ammo,t.Charge,t.Held,t.Tow,t.TowLeft,t.LastHit,t.LastWeapon,fe(0,t.LaunchCd-i),r,t.Ghosting,t.WarpCd,t.Next,t.Laps,t.Finish,t.Streak,t.Shots,t.Hits,t.Grabs,t.Rings,t.Kills,t.FirstBloodMedal,t.DoubleKillMedals,t.TripleKillMedals,t.RailKillMedals,t.RamKillMedals,t.OnFireMedals,t.VoidMedals,t.HoleMedals,t.AbductMedals,t.GraveMedals,t.LastKillTime,t.MultiKillCount)}function H1(i,e,t,n){let r;const s=t.Aim;r=s??n.LaunchAngle+t.Turn*Vo()*e;const o=r+3.141592653589793;return new we(n.Id,n.Team,n.Archetype,s1(i,r),zn,o,n.Hp,n.Shield,n.Boost,n.Stocks,n.Alive,n.Active,n.Thrusting,n.Reversing,n.RespawnIn,n.Invuln,n.Cooldown,n.Stun,n.Spin,n.Heat,n.Locked,n.Weapon,n.Ammo,n.Charge,n.Held,n.Tow,n.TowLeft,n.LastHit,n.LastWeapon,fe(0,n.LaunchCd-e),r,n.Ghosting,n.WarpCd,n.Next,n.Laps,n.Finish,n.Streak,n.Shots,n.Hits,n.Grabs,n.Rings,n.Kills,n.FirstBloodMedal,n.DoubleKillMedals,n.TripleKillMedals,n.RailKillMedals,n.RamKillMedals,n.OnFireMedals,n.VoidMedals,n.HoleMedals,n.AbductMedals,n.GraveMedals,n.LastKillTime,n.MultiKillCount)}function V1(i){return(Gg(i)?aS():1)*(t1(i.Pos)?1:oS())}function G1(i,e){return!e.Active&&i.Present?Vg(e):e}function z1(i,e,t,n){if(iu(n))return n.Ghosting?k1(e,t,n):H1(i,e,t,n);if(n.Alive){const r=n.Stun>0?Pt:t,s=V1(n)*Qg();let o;const a=r.Aim;if(a==null)o=n.Angle+(r.Turn*Vo()*s+n.Spin)*e;else if(!r.Steer)o=a;else{const P=a,E=Math.atan2(Math.sin(P-n.Angle),Math.cos(P-n.Angle)),A=Vo()*s*e;o=n.Angle+fe(-A,$e(A,E))+n.Spin*e}const l=r.Boost&&n.Boost>0,u=l?2:r.Thrust||r.Boost?1:0,c=l?mg()*s:u>0?Oo()*s:r.Reverse?-Oo()*gg()*s:0;let d;const p=re(Ae(n.Vel,re(Ae(re(jt(o),c),re(jt(o+3.141592653589793/2),r.Strafe*vg()*s)),e)),1-(ot()?iS():_g())*e_()*e);d=gh(vh()*s,p);let f;if(ot()){const P=jt(o),E=tn(d,P);f=Ae(re(P,E),re(ae(d,re(P,E)),fe(0,1-rS()*e)))}else f=d;const _=Ae(n.Pos,re(f,e)),m=l?fe(0,n.Boost-sS()*e):n.Boost,g=c<0,h=fe(0,n.Invuln-e),v=fe(0,n.Cooldown-e),M=fe(0,n.Heat-ag()*e),S=fe(0,n.Locked-e);return new we(n.Id,n.Team,n.Archetype,_,f,o,n.Hp,n.Shield,m,n.Stocks,n.Alive,n.Active,u,g,n.RespawnIn,h,v,fe(0,n.Stun-e),O1(e,n.Spin),M,S,n.Weapon,n.Ammo,n.Charge,n.Held,n.Tow,n.TowLeft,n.LastHit,n.LastWeapon,n.LaunchCd,n.LaunchAngle,n.Ghosting,n.WarpCd,n.Next,n.Laps,n.Finish,n.Streak,n.Shots,n.Hits,n.Grabs,n.Rings,n.Kills,n.FirstBloodMedal,n.DoubleKillMedals,n.TripleKillMedals,n.RailKillMedals,n.RamKillMedals,n.OnFireMedals,n.VoidMedals,n.HoleMedals,n.AbductMedals,n.GraveMedals,n.LastKillTime,n.MultiKillCount)}else return n}function t_(i,e,t,n,r){const s=ae(r.Pos,e),o=ke(s);if(o<t+It&&o>1e-6){const a=re(s,1/o),l=Ae(e,re(a,t));i.push(new _e(6,[l]));const u=jg(l,a,n,0,r),c=u[1];return[B1(c,Jg(l,a,It,u[0])),c]}else return[r,0]}function W1(i){const e=[];return[gt(t=>t.Alive?fh((n,r)=>t_(e,r.Pos,r.Radius,zn,n)[0],t,oi()):t,i),An(e)]}function K1(i,e){const t=[];return[gt(n=>n.Alive?cS((r,s)=>{const o=t_(t,s.Pos,s.Radius,s.Vel,r),a=o[1],l=o[0];if(a>0){let u;const c=l;return u=Jt(c)!==Jt(w(s.Owner,i))?cs(s.Owner,Ie.Rock,c):c,ks(a*uS(),u)}else return l},n,e):n,i),An(t)]}function X1(i,e,t){const n=[],r=Es(e),s=Si(i);for(let a=0;a<=r.length-1;a++)if(w(a,r).Kind===ko){const l=Gp(w(a,r));for(let u=0;u<=s.length-1;u++){const c=w(u,s);if(c.Alive){const d=Hg(l[0],l[1],c.Pos),p=ae(c.Pos,d),f=ke(p);if(f<Wl()+It&&f>1e-6){const _=re(p,1/f),m=Ae(d,re(_,Wl())),g=jg(m,_,zn,0,c);ve(s,u,Jg(m,_,It,g[0]))}}}}const o=Xs(a=>{let l,u;const c=a;if(u=ja(d=>{if(d.Kind===ko){const p=Gp(d);return eu(p[0],p[1],c.Pos)<Wl()+4}else return d.Kind===Ls&&Tc(i,d.Owner)!==Tc(i,c.Owner)?ke(ae(d.Pos,c.Pos))<Zi+4:!1},r),u==null)return!0;{const d=u|0;return w(d,r).Kind===Ls&&ve(r,d,(l=w(d,r),new ga(l.Owner,l.Kind,l.Pos,l.Angle,w(d,r).Hp-a.Damage,l.Life,l.Cooldown))),n.push(new _e(6,[a.Pos])),!1}},t);return[s,Ke(r),o,An(n)]}function q1(i,e){const t=Si(i),n=[];return[t,Xs(r=>{let s,o,a;const l=ja(u=>u.Alive&&Jt(u)!==Jt(w(r.Owner,t))?ke(ae(u.Pos,r.Pos))<It+5:!1,t);if(l==null)return!0;{const u=l|0;return w(u,t).Invuln<=0&&ve(t,r.Owner,(s=w(r.Owner,t),new we(s.Id,s.Team,s.Archetype,s.Pos,s.Vel,s.Angle,s.Hp,s.Shield,s.Boost,s.Stocks,s.Alive,s.Active,s.Thrusting,s.Reversing,s.RespawnIn,s.Invuln,s.Cooldown,s.Stun,s.Spin,s.Heat,s.Locked,s.Weapon,s.Ammo,s.Charge,s.Held,s.Tow,s.TowLeft,s.LastHit,s.LastWeapon,s.LaunchCd,s.LaunchAngle,s.Ghosting,s.WarpCd,s.Next,s.Laps,s.Finish,s.Streak,s.Shots,w(r.Owner,t).Hits+1,s.Grabs,s.Rings,s.Kills,s.FirstBloodMedal,s.DoubleKillMedals,s.TripleKillMedals,s.RailKillMedals,s.RamKillMedals,s.OnFireMedals,s.VoidMedals,s.HoleMedals,s.AbductMedals,s.GraveMedals,s.LastKillTime,s.MultiKillCount))),ve(t,u,ks(r.Damage,(o=(a=w(u,t),new we(a.Id,a.Team,a.Archetype,a.Pos,Ae(w(u,t).Vel,re(Xt(r.Vel),cg())),a.Angle,a.Hp,a.Shield,a.Boost,a.Stocks,a.Alive,a.Active,a.Thrusting,a.Reversing,a.RespawnIn,a.Invuln,a.Cooldown,a.Stun,a.Spin,a.Heat,a.Locked,a.Weapon,a.Ammo,a.Charge,a.Held,a.Tow,a.TowLeft,a.LastHit,a.LastWeapon,a.LaunchCd,a.LaunchAngle,a.Ghosting,a.WarpCd,a.Next,a.Laps,a.Finish,a.Streak,a.Shots,a.Hits,a.Grabs,a.Rings,a.Kills,a.FirstBloodMedal,a.DoubleKillMedals,a.TripleKillMedals,a.RailKillMedals,a.RamKillMedals,a.OnFireMedals,a.VoidMedals,a.HoleMedals,a.AbductMedals,a.GraveMedals,a.LastKillTime,a.MultiKillCount)),cs(r.Owner,r.Kind===2?Ie.Swarm:Ie.Blaster,o)))),n.push(new _e(0,[r.Pos,r.Kind===2?"Swarm":"Blaster",r.Damage,u])),!1}},e),An(n)]}function Y1(i){const e=Si(i),t=[];for(let n=0;n<=e.length-2;n++)for(let r=n+1;r<=e.length-1;r++){let s,o;const a=w(n,e),l=w(r,e),u=a,c=ae(l.Pos,u.Pos),d=ke(c);if(u.Alive&&l.Alive&&d<2*It&&d>1e-6){const p=re(c,1/d),f=tn(ae(l.Vel,u.Vel),p),_=2*It-d,m=re(p,_/2),g=F1(Ae(u.Pos,re(p,It)),p,u,l),h=g[1],v=g[0],M=re(p,_*lS()/2),S=Jt(u)!==Jt(l),P=fe(0,tn(u.Vel,p)),E=fe(0,-tn(l.Vel,p)),A=fe(0,tn(jt(u.Angle),p)),L=fe(0,tn(jt(l.Angle),re(p,-1))),y=E*Bd()*(1-Od()*A),x=P*Bd()*(1-Od()*L),C=S&&(E>_u()&&A>dp()?!0:P>_u()&&L>dp()),N=(I,J)=>S?cs(I,Ie.Collision,J):J,D=I=>C?new we(I.Id,I.Team,I.Archetype,I.Pos,I.Vel,I.Angle,I.Hp,I.Shield,I.Boost,I.Stocks,I.Alive,I.Active,I.Thrusting,I.Reversing,I.RespawnIn,I.Invuln,I.Cooldown,fe(I.Stun,hS()),J0(),I.Heat,I.Locked,I.Weapon,I.Ammo,I.Charge,I.Held,I.Tow,I.TowLeft,I.LastHit,I.LastWeapon,I.LaunchCd,I.LaunchAngle,I.Ghosting,I.WarpCd,I.Next,I.Laps,I.Finish,I.Streak,I.Shots,I.Hits,I.Grabs,I.Rings,I.Kills,I.FirstBloodMedal,I.DoubleKillMedals,I.TripleKillMedals,I.RailKillMedals,I.RamKillMedals,I.OnFireMedals,I.VoidMedals,I.HoleMedals,I.AbductMedals,I.GraveMedals,I.LastKillTime,I.MultiKillCount):I;ve(e,n,D((s=N(l.Id,new we(v.Id,v.Team,v.Archetype,ae(u.Pos,m),ae(v.Vel,M),v.Angle,v.Hp,v.Shield,v.Boost,v.Stocks,v.Alive,v.Active,v.Thrusting,v.Reversing,v.RespawnIn,v.Invuln,v.Cooldown,v.Stun,v.Spin,v.Heat,v.Locked,v.Weapon,v.Ammo,v.Charge,v.Held,v.Tow,v.TowLeft,v.LastHit,v.LastWeapon,v.LaunchCd,v.LaunchAngle,v.Ghosting,v.WarpCd,v.Next,v.Laps,v.Finish,v.Streak,v.Shots,v.Hits,v.Grabs,v.Rings,v.Kills,v.FirstBloodMedal,v.DoubleKillMedals,v.TripleKillMedals,v.RailKillMedals,v.RamKillMedals,v.OnFireMedals,v.VoidMedals,v.HoleMedals,v.AbductMedals,v.GraveMedals,v.LastKillTime,v.MultiKillCount)),ks(S?y:0,s)))),ve(e,r,D((o=N(u.Id,new we(h.Id,h.Team,h.Archetype,Ae(l.Pos,m),Ae(h.Vel,M),h.Angle,h.Hp,h.Shield,h.Boost,h.Stocks,h.Alive,h.Active,h.Thrusting,h.Reversing,h.RespawnIn,h.Invuln,h.Cooldown,h.Stun,h.Spin,h.Heat,h.Locked,h.Weapon,h.Ammo,h.Charge,h.Held,h.Tow,h.TowLeft,h.LastHit,h.LastWeapon,h.LaunchCd,h.LaunchAngle,h.Ghosting,h.WarpCd,h.Next,h.Laps,h.Finish,h.Streak,h.Shots,h.Hits,h.Grabs,h.Rings,h.Kills,h.FirstBloodMedal,h.DoubleKillMedals,h.TripleKillMedals,h.RailKillMedals,h.RamKillMedals,h.OnFireMedals,h.VoidMedals,h.HoleMedals,h.AbductMedals,h.GraveMedals,h.LastKillTime,h.MultiKillCount)),ks(S?x:0,o)))),C&&(t.push(new _e(6,[Ae(u.Pos,re(c,.5))])),t.push(new _e(7,[Ae(u.Pos,re(c,.5)),u.Id,l.Id]))),f<-_u()&&t.push(new _e(5,[Ae(u.Pos,re(c,.5))]))}}return[e,An(t)]}function $1(i,e,t,n){const r=Si(t),s=[];return[r,gt(o=>{let a,l,u;if(o.RespawnIn>0)return new mo(o.Pos,o.Amount,o.RespawnIn-e,o.Kind);{const c=ja(d=>{if(d.Alive&&ke(ae(d.Pos,o.Pos))<go+It)switch(o.Kind|0){case 1:return d.Hp<Cr?!i:!1;case 2:return d.Shield<=0;default:return!0}else return!1},r);if(c==null)return o;if(o.Kind===2){const d=c|0;return ve(r,d,(a=w(d,r),new we(a.Id,a.Team,a.Archetype,a.Pos,a.Vel,a.Angle,a.Hp,o.Amount,a.Boost,a.Stocks,a.Alive,a.Active,a.Thrusting,a.Reversing,a.RespawnIn,a.Invuln,a.Cooldown,a.Stun,a.Spin,a.Heat,a.Locked,a.Weapon,a.Ammo,a.Charge,a.Held,a.Tow,a.TowLeft,a.LastHit,a.LastWeapon,a.LaunchCd,a.LaunchAngle,a.Ghosting,a.WarpCd,a.Next,a.Laps,a.Finish,a.Streak,a.Shots,a.Hits,a.Grabs,a.Rings,a.Kills,a.FirstBloodMedal,a.DoubleKillMedals,a.TripleKillMedals,a.RailKillMedals,a.RamKillMedals,a.OnFireMedals,a.VoidMedals,a.HoleMedals,a.AbductMedals,a.GraveMedals,a.LastKillTime,a.MultiKillCount))),s.push(new _e(8,[o.Pos,!0])),new mo(o.Pos,o.Amount,Mg,o.Kind)}else if(o.Kind===1){const d=c|0;return ve(r,d,(l=w(d,r),new we(l.Id,l.Team,l.Archetype,l.Pos,l.Vel,l.Angle,$e(Cr,w(d,r).Hp+o.Amount),l.Shield,l.Boost,l.Stocks,l.Alive,l.Active,l.Thrusting,l.Reversing,l.RespawnIn,l.Invuln,l.Cooldown,l.Stun,l.Spin,l.Heat,l.Locked,l.Weapon,l.Ammo,l.Charge,l.Held,l.Tow,l.TowLeft,l.LastHit,l.LastWeapon,l.LaunchCd,l.LaunchAngle,l.Ghosting,l.WarpCd,l.Next,l.Laps,l.Finish,l.Streak,l.Shots,l.Hits,l.Grabs,l.Rings,l.Kills,l.FirstBloodMedal,l.DoubleKillMedals,l.TripleKillMedals,l.RailKillMedals,l.RamKillMedals,l.OnFireMedals,l.VoidMedals,l.HoleMedals,l.AbductMedals,l.GraveMedals,l.LastKillTime,l.MultiKillCount))),s.push(new _e(9,[o.Pos])),new mo(o.Pos,o.Amount,Sg,o.Kind)}else{const d=c|0;return ve(r,d,(u=w(d,r),new we(u.Id,u.Team,u.Archetype,u.Pos,u.Vel,u.Angle,u.Hp,u.Shield,$e(Ns,w(d,r).Boost+o.Amount),u.Stocks,u.Alive,u.Active,u.Thrusting,u.Reversing,u.RespawnIn,u.Invuln,u.Cooldown,u.Stun,u.Spin,u.Heat,u.Locked,u.Weapon,u.Ammo,u.Charge,u.Held,u.Tow,u.TowLeft,u.LastHit,u.LastWeapon,u.LaunchCd,u.LaunchAngle,u.Ghosting,u.WarpCd,u.Next,u.Laps,u.Finish,u.Streak,u.Shots,u.Hits,u.Grabs,u.Rings,u.Kills,u.FirstBloodMedal,u.DoubleKillMedals,u.TripleKillMedals,u.RailKillMedals,u.RamKillMedals,u.OnFireMedals,u.VoidMedals,u.HoleMedals,u.AbductMedals,u.GraveMedals,u.LastKillTime,u.MultiKillCount))),s.push(new _e(8,[o.Pos,o.Amount>=Ns])),new mo(o.Pos,o.Amount,xg,o.Kind)}}},n),An(s)]}function Z1(i,e,t,n){let r=e,s=t;const o=[],a=Array.from(gt(u=>u.Pos,n)),l=gt(u=>{let c;if(u.RespawnIn>0)return new Ro(u.Pos,u.RespawnIn-i);{const d=ja(p=>p.Alive?ke(ae(p.Pos,u.Pos))<Kl+It:!1,s);if(d==null)return u;{const p=d|0;r=oc(r)|0;const f=Ua()?w(w(p,s).Grabs%mc.length,mc):ot()?w(ya(fp.length,r),fp):Na()===1?Ie.Rail:w(ya(hp.length,r),hp),_=Si(s);if(ve(_,p,(c=w(p,_),new we(c.Id,c.Team,c.Archetype,c.Pos,c.Vel,c.Angle,c.Hp,c.Shield,c.Boost,c.Stocks,c.Alive,c.Active,c.Thrusting,c.Reversing,c.RespawnIn,c.Invuln,c.Cooldown,c.Stun,c.Spin,c.Heat,c.Locked,f,ot()&&(it(f,Ie.Swarm)||it(f,Ie.Scatter))?1:Mh(f),0,c.Held,c.Tow,c.TowLeft,c.LastHit,c.LastWeapon,c.LaunchCd,c.LaunchAngle,c.Ghosting,c.WarpCd,c.Next,c.Laps,c.Finish,c.Streak,c.Shots,c.Hits,w(p,_).Grabs+1,c.Rings,c.Kills,c.FirstBloodMedal,c.DoubleKillMedals,c.TripleKillMedals,c.RailKillMedals,c.RamKillMedals,c.OnFireMedals,c.VoidMedals,c.HoleMedals,c.AbductMedals,c.GraveMedals,c.LastKillTime,c.MultiKillCount))),s=_,o.push(new _e(10,[u.Pos])),r=oc(r)|0,Ua())return new Ro(u.Pos,1);{let m=ya(fr().length,r),g=0;for(;g<fr().length&&yg(w(m,fr()),a,{Equals:it,GetHashCode:h=>kd(h)|0});)m=(m+1)%fr().length|0,g=g+1|0;return dS(u.Pos,a,{Equals:it,GetHashCode:h=>kd(h)|0}),a.push(w(m,fr())),new Ro(w(m,fr()),fS)}}}},n);return[s,l,r,An(o)]}function j1(i,e,t){const n=i.filter(s=>s.Alive?Jt(s)!==Jt(t):!1),r=_o(s=>{const o=tu(s);return n.length===0?0:Fo(gt(a=>ke(ae(a.Pos,o)),n,Float64Array),{Compare:(a,l)=>fn(a,l)|0})},ki(kt(0,1,3)),{Compare:(s,o)=>fn(s,o)|0});return w(ya(2,e+t.Id*7919),r)|0}function J1(i,e){const t=i.filter(n=>n.Active&&n.Stocks>0?Jt(n)!==Jt(e):!1);return gc()&&t.length>0?e.Stocks<Fo(gt(n=>n.Stocks|0,t,Int32Array),{Compare:(n,r)=>fn(n,r)|0}):!1}function Q1(i,e,t){let n;if(ot()){const o=w((t.Next+yn().length-1)%yn().length,yn()),a=ae(w(t.Next,yn()),o);n=[o,Math.atan2(a.Y,a.X)]}else{const o=tu(j1(i,e,t));n=[o,Math.atan2(-o.Y,-o.X)]}let r;const s=Vg(t);return r=new we(s.Id,s.Team,s.Archetype,n[0],s.Vel,n[1],s.Hp,s.Shield,s.Boost,t.Stocks,s.Alive,s.Active,s.Thrusting,s.Reversing,s.RespawnIn,s.Invuln,s.Cooldown,s.Stun,s.Spin,s.Heat,s.Locked,s.Weapon,s.Ammo,s.Charge,s.Held,s.Tow,s.TowLeft,s.LastHit,s.LastWeapon,s.LaunchCd,s.LaunchAngle,s.Ghosting,s.WarpCd,t.Next,t.Laps,s.Finish,s.Streak,s.Shots,s.Hits,s.Grabs,s.Rings,s.Kills,s.FirstBloodMedal,s.DoubleKillMedals,s.TripleKillMedals,s.RailKillMedals,s.RamKillMedals,s.OnFireMedals,s.VoidMedals,s.HoleMedals,s.AbductMedals,s.GraveMedals,s.LastKillTime,s.MultiKillCount),J1(i,t)?new we(r.Id,r.Team,r.Archetype,r.Pos,r.Vel,r.Angle,r.Hp,Kc(),Ns,r.Stocks,r.Alive,r.Active,r.Thrusting,r.Reversing,r.RespawnIn,r.Invuln,r.Cooldown,r.Stun,r.Spin,r.Heat,r.Locked,r.Weapon,r.Ammo,r.Charge,r.Held,r.Tow,r.TowLeft,r.LastHit,r.LastWeapon,r.LaunchCd,r.LaunchAngle,r.Ghosting,r.WarpCd,r.Next,r.Laps,r.Finish,r.Streak,r.Shots,r.Hits,r.Grabs,r.Rings,r.Kills,r.FirstBloodMedal,r.DoubleKillMedals,r.TripleKillMedals,r.RailKillMedals,r.RamKillMedals,r.OnFireMedals,r.VoidMedals,r.HoleMedals,r.AbductMedals,r.GraveMedals,r.LastKillTime,r.MultiKillCount):r}function ey(i,e,t,n,r){if(r.Alive&&(r.Hp<=0||Wo(t,r.Pos))){const s=Wo(t,r.Pos);return[new we(r.Id,r.Team,r.Archetype,r.Pos,zn,r.Angle,r.Hp,r.Shield,r.Boost,Ua()||ot()?r.Stocks:r.Stocks-1,!1,r.Active,0,r.Reversing,pS,r.Invuln,r.Cooldown,r.Stun,r.Spin,r.Heat,r.Locked,r.Weapon,r.Ammo,r.Charge,r.Held,r.Tow,r.TowLeft,r.LastHit,r.LastWeapon,r.LaunchCd,r.LaunchAngle,r.Ghosting,r.WarpCd,r.Next,r.Laps,r.Finish,0,r.Shots,r.Hits,r.Grabs,r.Rings+(s?1:0),r.Kills,r.FirstBloodMedal,r.DoubleKillMedals,r.TripleKillMedals,r.RailKillMedals,r.RamKillMedals,r.OnFireMedals,r.VoidMedals,r.HoleMedals,r.AbductMedals,r.GraveMedals,r.LastKillTime,r.MultiKillCount),[r.Pos,r.Id,s,r.LastHit,r.LastWeapon]]}else return!r.Alive&&r.Active&&r.Stocks>0&&r.Finish===0?[r.RespawnIn<=n?Q1(i,e,r):new we(r.Id,r.Team,r.Archetype,r.Pos,r.Vel,r.Angle,r.Hp,r.Shield,r.Boost,r.Stocks,r.Alive,r.Active,r.Thrusting,r.Reversing,r.RespawnIn-n,r.Invuln,r.Cooldown,r.Stun,r.Spin,r.Heat,r.Locked,r.Weapon,r.Ammo,r.Charge,r.Held,r.Tow,r.TowLeft,r.LastHit,r.LastWeapon,r.LaunchCd,r.LaunchAngle,r.Ghosting,r.WarpCd,r.Next,r.Laps,r.Finish,r.Streak,r.Shots,r.Hits,r.Grabs,r.Rings,r.Kills,r.FirstBloodMedal,r.DoubleKillMedals,r.TripleKillMedals,r.RailKillMedals,r.RamKillMedals,r.OnFireMedals,r.VoidMedals,r.HoleMedals,r.AbductMedals,r.GraveMedals,r.LastKillTime,r.MultiKillCount),void 0]:[r,void 0]}function Au(i,e){return new jn(gt(t=>new we(t.Id,w(t.Id,i),t.Archetype,t.Pos,t.Vel,t.Angle,t.Hp,t.Shield,t.Boost,t.Stocks,t.Alive,t.Active,t.Thrusting,t.Reversing,t.RespawnIn,t.Invuln,t.Cooldown,t.Stun,t.Spin,t.Heat,t.Locked,t.Weapon,t.Ammo,t.Charge,t.Held,t.Tow,t.TowLeft,t.LastHit,t.LastWeapon,t.LaunchCd,t.LaunchAngle,t.Ghosting,t.WarpCd,t.Next,t.Laps,t.Finish,t.Streak,t.Shots,t.Hits,t.Grabs,t.Rings,t.Kills,t.FirstBloodMedal,t.DoubleKillMedals,t.TripleKillMedals,t.RailKillMedals,t.RamKillMedals,t.OnFireMedals,t.VoidMedals,t.HoleMedals,t.AbductMedals,t.GraveMedals,t.LastKillTime,t.MultiKillCount),e.Ships),e.Bullets,e.Mines,e.Rocks,e.Portals,e.PortalIn,e.Hole,e.HoleIn,e.Deploys,e.RaceEnd,e.Pads,e.Crates,e.Rng,e.Phase,e.Time,e.Events)}function n_(i){return tu(i)}function Zd(i){return Jt(i)|0}function i_(i){return Gg(i)}function Ko(i){return iu(i)}function r_(i){return zg(i)}function Zr(i){return Wg(i)}function ty(i){return Kg(i)}function ny(i,e){return o1(i,e)|0}function iy(i,e){return v1(i,e)}function s_(i){let e,t,n,r;const s=w(i,Mi);return oi(Es(ln(o=>new Tg(o[0],o[1]),s.Rocks))),fr(Es(s.Crates)),Ge(s.Size),vu(xr((e=s.Track,e!=null?Es(e[0]):void 0),[])),kn(vu().length>0?n1(vu()):[]),cc(xr((t=s.Track,t!=null?t[2]*qd:void 0),1)),yn(ki(We(()=>xn(o=>w(o,kn()),kt(0,cc(),kn().length-1))))),dh(xr((n=s.Track,n!=null?n[1]:void 0),0)),mS(s.Hole),new jn(Sn(4,o=>{const a=Oa(o);return new we(a.Id,a.Team,a.Archetype,a.Pos,a.Vel,a.Angle,a.Hp,a.Shield,a.Boost,0,!1,!1,a.Thrusting,a.Reversing,a.RespawnIn,a.Invuln,a.Cooldown,a.Stun,a.Spin,a.Heat,a.Locked,a.Weapon,a.Ammo,a.Charge,a.Held,a.Tow,a.TowLeft,a.LastHit,a.LastWeapon,a.LaunchCd,a.LaunchAngle,a.Ghosting,a.WarpCd,a.Next,a.Laps,a.Finish,a.Streak,a.Shots,a.Hits,a.Grabs,a.Rings,a.Kills,a.FirstBloodMedal,a.DoubleKillMedals,a.TripleKillMedals,a.RailKillMedals,a.RamKillMedals,a.OnFireMedals,a.VoidMedals,a.HoleMedals,a.AbductMedals,a.GraveMedals,a.LastKillTime,a.MultiKillCount)}),Re(),Re(),Re(),Re(),fg(),(r=s.Hole,r!=null?new zd(r[0],Number.POSITIVE_INFINITY):void 0),pg(),Re(),0,Es(ln(o=>new mo(o[0],o[1],0,o[2]),s.Pads)),gt(o=>new Ro(w(o%fr().length,fr()),0),new Int32Array([0,2,4,6])),7,Yr.Playing,0,Re())}let on=Tt(s_(0));function el(i){is((i+Mi.length)%Mi.length),on(s_(is()))}function a_(i){const e=gt(r=>r.Id|0,i.Ships.filter(r=>r.Active?r.Id!==ai():!1),Int32Array),t=gt(r=>{if(r.Id===ai()){const s=Oa(r.Id);return new we(s.Id,r.Team,s.Archetype,V(300,0),s.Vel,3.141592653589793,s.Hp,s.Shield,s.Boost,s.Stocks,s.Alive,s.Active,s.Thrusting,s.Reversing,s.RespawnIn,0,s.Cooldown,s.Stun,s.Spin,s.Heat,s.Locked,s.Weapon,s.Ammo,s.Charge,s.Held,s.Tow,s.TowLeft,s.LastHit,s.LastWeapon,s.LaunchCd,s.LaunchAngle,s.Ghosting,s.WarpCd,s.Next,s.Laps,s.Finish,s.Streak,s.Shots,s.Hits,s.Grabs,s.Rings,s.Kills,s.FirstBloodMedal,s.DoubleKillMedals,s.TripleKillMedals,s.RailKillMedals,s.RamKillMedals,s.OnFireMedals,s.VoidMedals,s.HoleMedals,s.AbductMedals,s.GraveMedals,s.LastKillTime,s.MultiKillCount)}else if(r.Active){const s=(gS(a=>r.Id===a,e)-(e.length-1)/2)*120,o=Oa(r.Id);return new we(o.Id,r.Team,o.Archetype,V(-300,s),o.Vel,0,o.Hp,o.Shield,o.Boost,o.Stocks,o.Alive,o.Active,o.Thrusting,o.Reversing,o.RespawnIn,0,o.Cooldown,o.Stun,o.Spin,o.Heat,o.Locked,o.Weapon,o.Ammo,o.Charge,o.Held,o.Tow,o.TowLeft,o.LastHit,o.LastWeapon,o.LaunchCd,o.LaunchAngle,o.Ghosting,o.WarpCd,o.Next,o.Laps,o.Finish,o.Streak,o.Shots,o.Hits,o.Grabs,o.Rings,o.Kills,o.FirstBloodMedal,o.DoubleKillMedals,o.TripleKillMedals,o.RailKillMedals,o.RamKillMedals,o.OnFireMedals,o.VoidMedals,o.HoleMedals,o.AbductMedals,o.GraveMedals,o.LastKillTime,o.MultiKillCount)}else return r},i.Ships),n=ls((r,s)=>r===0?new Ro(V(0,-220),0):s,i.Crates);return new jn(t,Re(),ai()>=0?en(new Us(ai(),V(0,220),zn,-1)):Re(),i.Rocks,i.Portals,i.PortalIn,i.Hole,i.HoleIn,i.Deploys,i.RaceEnd,i.Pads,n,i.Rng,i.Phase,i.Time,i.Events)}function Wp(i,e,t){return new jn(gt(n=>n.Id===i?new we(n.Id,n.Team,n.Archetype,n.Pos,n.Vel,n.Angle,n.Hp,n.Shield,n.Boost,n.Stocks,n.Alive,n.Active,n.Thrusting,n.Reversing,n.RespawnIn,n.Invuln,n.Cooldown,n.Stun,n.Spin,n.Heat,n.Locked,e,Mh(e),0,n.Held,n.Tow,n.TowLeft,n.LastHit,n.LastWeapon,n.LaunchCd,n.LaunchAngle,n.Ghosting,n.WarpCd,n.Next,n.Laps,n.Finish,n.Streak,n.Shots,n.Hits,n.Grabs,n.Rings,n.Kills,n.FirstBloodMedal,n.DoubleKillMedals,n.TripleKillMedals,n.RailKillMedals,n.RamKillMedals,n.OnFireMedals,n.VoidMedals,n.HoleMedals,n.AbductMedals,n.GraveMedals,n.LastKillTime,n.MultiKillCount):n,t.Ships),t.Bullets,t.Mines,t.Rocks,t.Portals,t.PortalIn,t.Hole,t.HoleIn,t.Deploys,t.RaceEnd,t.Pads,t.Crates,t.Rng,t.Phase,t.Time,t.Events)}function o_(i,e){return new jn(gt(t=>{if(i(t.Id)){const n=Oa(t.Id);return new we(n.Id,t.Team,n.Archetype,n.Pos,n.Vel,n.Angle,n.Hp,n.Shield,n.Boost,n.Stocks,n.Alive,n.Active,n.Thrusting,n.Reversing,n.RespawnIn,n.Invuln,n.Cooldown,n.Stun,n.Spin,n.Heat,n.Locked,n.Weapon,n.Ammo,n.Charge,n.Held,n.Tow,n.TowLeft,n.LastHit,n.LastWeapon,n.LaunchCd,n.LaunchAngle,n.Ghosting,n.WarpCd,n.Next,n.Laps,n.Finish,n.Streak,n.Shots,n.Hits,n.Grabs,n.Rings,n.Kills,n.FirstBloodMedal,n.DoubleKillMedals,n.TripleKillMedals,n.RailKillMedals,n.RamKillMedals,n.OnFireMedals,n.VoidMedals,n.HoleMedals,n.AbductMedals,n.GraveMedals,n.LastKillTime,n.MultiKillCount)}else{const n=Oa(t.Id);return new we(n.Id,t.Team,n.Archetype,n.Pos,n.Vel,n.Angle,n.Hp,n.Shield,n.Boost,0,!1,!1,n.Thrusting,n.Reversing,n.RespawnIn,n.Invuln,n.Cooldown,n.Stun,n.Spin,n.Heat,n.Locked,n.Weapon,n.Ammo,n.Charge,n.Held,n.Tow,n.TowLeft,n.LastHit,n.LastWeapon,n.LaunchCd,n.LaunchAngle,n.Ghosting,n.WarpCd,n.Next,n.Laps,n.Finish,n.Streak,n.Shots,n.Hits,n.Grabs,n.Rings,n.Kills,n.FirstBloodMedal,n.DoubleKillMedals,n.TripleKillMedals,n.RailKillMedals,n.RamKillMedals,n.OnFireMedals,n.VoidMedals,n.HoleMedals,n.AbductMedals,n.GraveMedals,n.LastKillTime,n.MultiKillCount)}},e.Ships),on().Bullets,on().Mines,on().Rocks,on().Portals,on().PortalIn,on().Hole,on().HoleIn,on().Deploys,on().RaceEnd,on().Pads,on().Crates,e.Rng,on().Phase,on().Time,on().Events)}function Ah(i,e,t){let n;switch(t.Phase.tag===1&&e.some(r=>r.Start)?n=0:n=1,n){case 0:return o_(r=>w(r,t.Ships).Active,t);default:{const r=r_(t.Time),s=t.Phase.tag!==1,o=gt(Y=>{let Ve;const Xe=Y;Ve=zp(t.Ships,t.Deploys,Zd(Xe),Xe.Pos,i);let ee;const Ct=G1(w(Y.Id,e),Y);return ee=z1(r,Ve,w(Y.Id,e),Ct),S1(s,Ve,w(Y.Id,e),ee)},t.Ships),a=gt(Y=>Y[0],o),l=po(Y=>Y[1],Ke(o)),u=po(Y=>Y[2],Ke(o)),c=po(Y=>Y[3],Ke(o)),d=po(Y=>Y[4],Ke(o)),p=En(Y=>{if(Y.tag===12)return[Y.fields[0],Y.fields[1],Y.fields[2]]},d),f=En(Y=>{if(Y.tag===16)return[Y.fields[0],Y.fields[1],Y.fields[2]]},d),_=En(Y=>{if(Y.tag===18)return[Y.fields[0],Y.fields[1],Y.fields[2]]},d),m=En(Y=>{if(Y.tag===19)return Y.fields[1]},d),g=En(Y=>{if(Y.tag===24)return Y.fields[0]},d),h=P1(L1(a,f),_),v=R1(D1(i,h[0],m),p),M=v[0],S=w1(i,M,Ye(g,t.Deploys)),P=S[0],E=(Y,Ve)=>zp(M,P,Tc(M,Y),Ve,i),A=X1(M,P,ln(Y=>{const Ve=Yl(t.Portals,Y.Pos,Y.Vel);return Ve==null?Y:new Pa(Y.Owner,Ve,Y.Vel,Y.Life,Y.Kind,Y.Damage)},En(Y=>y1(r,t.Rocks,E(Y.Owner,Y.Pos),Y),ln(Y=>new Pa(Y.Owner,Y.Pos,ql(t.Hole,i,Y.Pos,Y.Vel),Y.Life,Y.Kind,Y.Damage),ln(Y=>x1(i,M,Y),Ye(l,Ye(S[1],t.Bullets))))))),L=q1(A[0],A[2]),y=L[0],x=N1(r,Y=>E(Y.Owner,Y.Pos),y,Ye(u,t.Mines)),C=ln(Y=>{const Ve=Yl(t.Portals,Y.Pos,Y.Vel);return Ve==null?new Us(Y.Owner,Y.Pos,ql(t.Hole,i,Y.Pos,Y.Vel),Y.Fuse):new Us(Y.Owner,Ve,Y.Vel,Y.Fuse)},x[0]),N=U1(y,x[1]),D=Y1(N[0]),I=W1(D[0]),J=C1(r,Y=>E(Y.Owner,Y.Pos),Ye(c,t.Rocks)),q=ln(Y=>{const Ve=Yl(t.Portals,Y.Pos,Y.Vel);return Ve==null?new uc(Y.Owner,Y.Pos,ql(t.Hole,i,Y.Pos,Y.Vel),Y.Radius,Y.Life):new uc(Y.Owner,Ve,Y.Vel,Y.Radius,Y.Life)},J[0]),oe=K1(I[0],q),X=A1(i,t.Portals,oe[0]),he=E1(t.Hole,i,X[0]),pe=$1(Zr(t),i,he,t.Pads),Se=Z1(i,t.Rng,pe[0],t.Crates),Ne=Se[0],nt=T1(r,i,Zr(t)?!0:ot(),Ne,Se[2],t),Z=b1(r,i,Zr(t)?!0:ot(),Ne,nt[2],t),le=Z[2]|0,Ce=l1(t.Time+i,Ne),ue=Ce[0],Pe=ue.some(Y=>Y.Finish>0)?t.RaceEnd+i:0,ze=_S(gt(Y=>ey(ue,le,r,i,Y),ue)),Ze=Si(ze[0]),wt=En(Y=>Y,Ke(ze[1]));let Oe=Re(),Ht=Ze.some(Y=>Y.FirstBloodMedal>0);const F=mt(wt);try{for(;F["System.Collections.IEnumerator.MoveNext"]();){const Y=F["System.Collections.Generic.IEnumerator`1.get_Current"](),Ve=Y[4],Xe=Y[3]|0;if(Xe>=0&&Xe!==Y[1]){const ee=w(Xe,Ze),Ct=it(Ve,Ie.Rail),qe=it(Ve,Ie.Collision);let R;Ht?R=[0,Ht]:(Oe=bn(new _e(3,[Xe,"firstblood"]),Oe),R=[1,!0]),Ht=R[1];let T;if(t.Time-ee.LastKillTime<=4){const Ee=ee.MultiKillCount+1|0;T=[Ee,Ee===2?1:0,Ee>=3?1:0]}else T=[1,0,0];const G=T[2]|0,Q=T[1]|0;Q>0&&(Oe=bn(new _e(3,[Xe,"doublekill"]),Oe)),G>0&&(Oe=bn(new _e(3,[Xe,"triplekill"]),Oe));const se=(Ct?1:0)|0;se>0&&(Oe=bn(new _e(3,[Xe,"railkill"]),Oe));const j=(qe?1:0)|0;j>0&&(Oe=bn(new _e(3,[Xe,"ramkill"]),Oe));const De=(Y[2]?1:0)|0;De>0&&(Oe=bn(new _e(3,[Xe,"voidkill"]),Oe));const ge=(it(Ve,Ie.Singularity)?1:0)|0;ge>0&&(Oe=bn(new _e(3,[Xe,"holekill"]),Oe));const be=(it(Ve,Ie.Tractor)?1:0)|0;be>0&&(Oe=bn(new _e(3,[Xe,"abductkill"]),Oe));const dt=(it(Ve,Ie.Rock)?1:0)|0;dt>0&&(Oe=bn(new _e(3,[Xe,"gravekill"]),Oe));const ce=(ee.Streak+1===3?1:0)|0;ce>0&&(Oe=bn(new _e(3,[Xe,"onfire"]),Oe)),ve(Ze,Xe,new we(ee.Id,ee.Team,ee.Archetype,ee.Pos,ee.Vel,ee.Angle,ee.Hp,ee.Shield,ee.Boost,ee.Stocks,ee.Alive,ee.Active,ee.Thrusting,ee.Reversing,ee.RespawnIn,ee.Invuln,ee.Cooldown,ee.Stun,ee.Spin,ee.Heat,ee.Locked,ee.Weapon,ee.Ammo,ee.Charge,ee.Held,ee.Tow,ee.TowLeft,ee.LastHit,ee.LastWeapon,ee.LaunchCd,ee.LaunchAngle,ee.Ghosting,ee.WarpCd,ee.Next,ee.Laps,ee.Finish,ee.Streak+1,ee.Shots,ee.Hits,ee.Grabs,ee.Rings,ee.Kills+1,ee.FirstBloodMedal+R[0],ee.DoubleKillMedals+Q,ee.TripleKillMedals+G,ee.RailKillMedals+se,ee.RamKillMedals+j,ee.OnFireMedals+ce,ee.VoidMedals+De,ee.HoleMedals+ge,ee.AbductMedals+be,ee.GraveMedals+dt,t.Time,T[0]))}}}finally{yt(F)}return new jn(Ze,L[1],C,q,nt[0],nt[1],Z[0],Z[1],A[1],Pe,pe[1],Se[1],le,c1(Ze,Pe),t.Time+i,Ye(d,Ye(v[1],Ye(h[1],Ye(L[2],Ye(x[2],Ye(N[1],Ye(Oe,Ye(D[1],Ye(I[1],Ye(J[1],Ye(oe[1],Ye(X[1],Ye(nt[3],Ye(Z[3],Ye(S[2],Ye(A[3],Ye(Ce[1],Ye(pe[2],Ye(Se[3],Ye(ln(Y=>new _e(1,[Y[0],Y[1],Y[2]]),wt),ln(Y=>new _e(2,[Y[1],Y[3],Y[4],Y[2]]),wt))))))))))))))))))))))}}}/**
 * @license
 * Copyright 2010-2024 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const wh="170",ry=0,Kp=1,sy=2,l_=1,ay=2,dr=3,rs=0,Jn=1,Qi=2,yr=0,Ea=1,Hs=2,Xp=3,qp=4,oy=5,xs=100,ly=101,cy=102,uy=103,dy=104,fy=200,hy=201,py=202,my=203,jd=204,Jd=205,gy=206,_y=207,vy=208,My=209,Sy=210,xy=211,yy=212,Ty=213,by=214,Qd=0,ef=1,tf=2,ka=3,nf=4,rf=5,sf=6,af=7,c_=0,Ey=1,Ay=2,jr=0,wy=1,Cy=2,Ry=3,Ly=4,Py=5,Iy=6,Dy=7,u_=300,Ha=301,Va=302,of=303,lf=304,ru=306,cf=1e3,ws=1001,uf=1002,Fi=1003,Ny=1004,fl=1005,tr=1006,wu=1007,Cs=1008,Rr=1009,d_=1010,f_=1011,Xo=1012,Ch=1013,Vs=1014,vr=1015,Tr=1016,Rh=1017,Lh=1018,Ga=1020,h_=35902,p_=1021,m_=1022,Ii=1023,g_=1024,__=1025,Aa=1026,za=1027,v_=1028,Ph=1029,M_=1030,Ih=1031,Dh=1033,$l=33776,Zl=33777,jl=33778,Jl=33779,df=35840,ff=35841,hf=35842,pf=35843,mf=36196,gf=37492,_f=37496,vf=37808,Mf=37809,Sf=37810,xf=37811,yf=37812,Tf=37813,bf=37814,Ef=37815,Af=37816,wf=37817,Cf=37818,Rf=37819,Lf=37820,Pf=37821,Ql=36492,If=36494,Df=36495,S_=36283,Nf=36284,Uf=36285,Ff=36286,Uy=3200,Fy=3201,By=0,Oy=1,Xr="",ni="srgb",Qa="srgb-linear",su="linear",Ut="srgb",js=7680,Yp=519,ky=512,Hy=513,Vy=514,x_=515,Gy=516,zy=517,Wy=518,Ky=519,$p=35044,Zp="300 es",Mr=2e3,bc=2001;class eo{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;const n=this._listeners;return n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;const r=this._listeners[e];if(r!==void 0){const s=r.indexOf(t);s!==-1&&r.splice(s,1)}}dispatchEvent(e){if(this._listeners===void 0)return;const n=this._listeners[e.type];if(n!==void 0){e.target=this;const r=n.slice(0);for(let s=0,o=r.length;s<o;s++)r[s].call(this,e);e.target=null}}}const Rn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],ec=Math.PI/180,Bf=180/Math.PI;function tl(){const i=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(Rn[i&255]+Rn[i>>8&255]+Rn[i>>16&255]+Rn[i>>24&255]+"-"+Rn[e&255]+Rn[e>>8&255]+"-"+Rn[e>>16&15|64]+Rn[e>>24&255]+"-"+Rn[t&63|128]+Rn[t>>8&255]+"-"+Rn[t>>16&255]+Rn[t>>24&255]+Rn[n&255]+Rn[n>>8&255]+Rn[n>>16&255]+Rn[n>>24&255]).toLowerCase()}function Yn(i,e,t){return Math.max(e,Math.min(t,i))}function Xy(i,e){return(i%e+e)%e}function Cu(i,e,t){return(1-t)*i+t*e}function ao(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return i/4294967295;case Uint16Array:return i/65535;case Uint8Array:return i/255;case Int32Array:return Math.max(i/2147483647,-1);case Int16Array:return Math.max(i/32767,-1);case Int8Array:return Math.max(i/127,-1);default:throw new Error("Invalid component type.")}}function Xn(i,e){switch(e.constructor){case Float32Array:return i;case Uint32Array:return Math.round(i*4294967295);case Uint16Array:return Math.round(i*65535);case Uint8Array:return Math.round(i*255);case Int32Array:return Math.round(i*2147483647);case Int16Array:return Math.round(i*32767);case Int8Array:return Math.round(i*127);default:throw new Error("Invalid component type.")}}class tt{constructor(e=0,t=0){tt.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6],this.y=r[1]*t+r[4]*n+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Yn(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),r=Math.sin(t),s=this.x-e.x,o=this.y-e.y;return this.x=s*n-o*r+e.x,this.y=s*r+o*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class at{constructor(e,t,n,r,s,o,a,l,u){at.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,r,s,o,a,l,u)}set(e,t,n,r,s,o,a,l,u){const c=this.elements;return c[0]=e,c[1]=r,c[2]=a,c[3]=t,c[4]=s,c[5]=l,c[6]=n,c[7]=o,c[8]=u,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,r=t.elements,s=this.elements,o=n[0],a=n[3],l=n[6],u=n[1],c=n[4],d=n[7],p=n[2],f=n[5],_=n[8],m=r[0],g=r[3],h=r[6],v=r[1],M=r[4],S=r[7],P=r[2],E=r[5],A=r[8];return s[0]=o*m+a*v+l*P,s[3]=o*g+a*M+l*E,s[6]=o*h+a*S+l*A,s[1]=u*m+c*v+d*P,s[4]=u*g+c*M+d*E,s[7]=u*h+c*S+d*A,s[2]=p*m+f*v+_*P,s[5]=p*g+f*M+_*E,s[8]=p*h+f*S+_*A,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],o=e[4],a=e[5],l=e[6],u=e[7],c=e[8];return t*o*c-t*a*u-n*s*c+n*a*l+r*s*u-r*o*l}invert(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],o=e[4],a=e[5],l=e[6],u=e[7],c=e[8],d=c*o-a*u,p=a*l-c*s,f=u*s-o*l,_=t*d+n*p+r*f;if(_===0)return this.set(0,0,0,0,0,0,0,0,0);const m=1/_;return e[0]=d*m,e[1]=(r*u-c*n)*m,e[2]=(a*n-r*o)*m,e[3]=p*m,e[4]=(c*t-r*l)*m,e[5]=(r*s-a*t)*m,e[6]=f*m,e[7]=(n*l-u*t)*m,e[8]=(o*t-n*s)*m,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,r,s,o,a){const l=Math.cos(s),u=Math.sin(s);return this.set(n*l,n*u,-n*(l*o+u*a)+o+e,-r*u,r*l,-r*(-u*o+l*a)+a+t,0,0,1),this}scale(e,t){return this.premultiply(Ru.makeScale(e,t)),this}rotate(e){return this.premultiply(Ru.makeRotation(-e)),this}translate(e,t){return this.premultiply(Ru.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let r=0;r<9;r++)if(t[r]!==n[r])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const Ru=new at;function y_(i){for(let e=i.length-1;e>=0;--e)if(i[e]>=65535)return!0;return!1}function qo(i){return document.createElementNS("http://www.w3.org/1999/xhtml",i)}function qy(){const i=qo("canvas");return i.style.display="block",i}const jp={};function So(i){i in jp||(jp[i]=!0,console.warn(i))}function Yy(i,e,t){return new Promise(function(n,r){function s(){switch(i.clientWaitSync(e,i.SYNC_FLUSH_COMMANDS_BIT,0)){case i.WAIT_FAILED:r();break;case i.TIMEOUT_EXPIRED:setTimeout(s,t);break;default:n()}}setTimeout(s,t)})}function $y(i){const e=i.elements;e[2]=.5*e[2]+.5*e[3],e[6]=.5*e[6]+.5*e[7],e[10]=.5*e[10]+.5*e[11],e[14]=.5*e[14]+.5*e[15]}function Zy(i){const e=i.elements;e[11]===-1?(e[10]=-e[10]-1,e[14]=-e[14]):(e[10]=-e[10],e[14]=-e[14]+1)}const vt={enabled:!0,workingColorSpace:Qa,spaces:{},convert:function(i,e,t){return this.enabled===!1||e===t||!e||!t||(this.spaces[e].transfer===Ut&&(i.r=br(i.r),i.g=br(i.g),i.b=br(i.b)),this.spaces[e].primaries!==this.spaces[t].primaries&&(i.applyMatrix3(this.spaces[e].toXYZ),i.applyMatrix3(this.spaces[t].fromXYZ)),this.spaces[t].transfer===Ut&&(i.r=wa(i.r),i.g=wa(i.g),i.b=wa(i.b))),i},fromWorkingColorSpace:function(i,e){return this.convert(i,this.workingColorSpace,e)},toWorkingColorSpace:function(i,e){return this.convert(i,e,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===Xr?su:this.spaces[i].transfer},getLuminanceCoefficients:function(i,e=this.workingColorSpace){return i.fromArray(this.spaces[e].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,e,t){return i.copy(this.spaces[e].toXYZ).multiply(this.spaces[t].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace}};function br(i){return i<.04045?i*.0773993808:Math.pow(i*.9478672986+.0521327014,2.4)}function wa(i){return i<.0031308?i*12.92:1.055*Math.pow(i,.41666)-.055}const Jp=[.64,.33,.3,.6,.15,.06],Qp=[.2126,.7152,.0722],em=[.3127,.329],tm=new at().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),nm=new at().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);vt.define({[Qa]:{primaries:Jp,whitePoint:em,transfer:su,toXYZ:tm,fromXYZ:nm,luminanceCoefficients:Qp,workingColorSpaceConfig:{unpackColorSpace:ni},outputColorSpaceConfig:{drawingBufferColorSpace:ni}},[ni]:{primaries:Jp,whitePoint:em,transfer:Ut,toXYZ:tm,fromXYZ:nm,luminanceCoefficients:Qp,outputColorSpaceConfig:{drawingBufferColorSpace:ni}}});let Js;class jy{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{Js===void 0&&(Js=qo("canvas")),Js.width=e.width,Js.height=e.height;const n=Js.getContext("2d");e instanceof ImageData?n.putImageData(e,0,0):n.drawImage(e,0,0,e.width,e.height),t=Js}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=qo("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const r=n.getImageData(0,0,e.width,e.height),s=r.data;for(let o=0;o<s.length;o++)s[o]=br(s[o]/255)*255;return n.putImageData(r,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(br(t[n]/255)*255):t[n]=br(t[n]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let Jy=0;class T_{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Jy++}),this.uuid=tl(),this.data=e,this.dataReady=!0,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},r=this.data;if(r!==null){let s;if(Array.isArray(r)){s=[];for(let o=0,a=r.length;o<a;o++)r[o].isDataTexture?s.push(Lu(r[o].image)):s.push(Lu(r[o]))}else s=Lu(r);n.url=s}return t||(e.images[this.uuid]=n),n}}function Lu(i){return typeof HTMLImageElement<"u"&&i instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&i instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&i instanceof ImageBitmap?jy.getDataURL(i):i.data?{data:Array.from(i.data),width:i.width,height:i.height,type:i.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let Qy=0;class Vn extends eo{constructor(e=Vn.DEFAULT_IMAGE,t=Vn.DEFAULT_MAPPING,n=ws,r=ws,s=tr,o=Cs,a=Ii,l=Rr,u=Vn.DEFAULT_ANISOTROPY,c=Xr){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Qy++}),this.uuid=tl(),this.name="",this.source=new T_(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=r,this.magFilter=s,this.minFilter=o,this.anisotropy=u,this.format=a,this.internalFormat=null,this.type=l,this.offset=new tt(0,0),this.repeat=new tt(1,1),this.center=new tt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new at,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=c,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==u_)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case cf:e.x=e.x-Math.floor(e.x);break;case ws:e.x=e.x<0?0:1;break;case uf:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case cf:e.y=e.y-Math.floor(e.y);break;case ws:e.y=e.y<0?0:1;break;case uf:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Vn.DEFAULT_IMAGE=null;Vn.DEFAULT_MAPPING=u_;Vn.DEFAULT_ANISOTROPY=1;class un{constructor(e=0,t=0,n=0,r=1){un.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,r){return this.x=e,this.y=t,this.z=n,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,r=this.z,s=this.w,o=e.elements;return this.x=o[0]*t+o[4]*n+o[8]*r+o[12]*s,this.y=o[1]*t+o[5]*n+o[9]*r+o[13]*s,this.z=o[2]*t+o[6]*n+o[10]*r+o[14]*s,this.w=o[3]*t+o[7]*n+o[11]*r+o[15]*s,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,r,s;const l=e.elements,u=l[0],c=l[4],d=l[8],p=l[1],f=l[5],_=l[9],m=l[2],g=l[6],h=l[10];if(Math.abs(c-p)<.01&&Math.abs(d-m)<.01&&Math.abs(_-g)<.01){if(Math.abs(c+p)<.1&&Math.abs(d+m)<.1&&Math.abs(_+g)<.1&&Math.abs(u+f+h-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const M=(u+1)/2,S=(f+1)/2,P=(h+1)/2,E=(c+p)/4,A=(d+m)/4,L=(_+g)/4;return M>S&&M>P?M<.01?(n=0,r=.707106781,s=.707106781):(n=Math.sqrt(M),r=E/n,s=A/n):S>P?S<.01?(n=.707106781,r=0,s=.707106781):(r=Math.sqrt(S),n=E/r,s=L/r):P<.01?(n=.707106781,r=.707106781,s=0):(s=Math.sqrt(P),n=A/s,r=L/s),this.set(n,r,s,t),this}let v=Math.sqrt((g-_)*(g-_)+(d-m)*(d-m)+(p-c)*(p-c));return Math.abs(v)<.001&&(v=1),this.x=(g-_)/v,this.y=(d-m)/v,this.z=(p-c)/v,this.w=Math.acos((u+f+h-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class eT extends eo{constructor(e=1,t=1,n={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new un(0,0,e,t),this.scissorTest=!1,this.viewport=new un(0,0,e,t);const r={width:e,height:t,depth:1};n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:tr,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},n);const s=new Vn(r,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace);s.flipY=!1,s.generateMipmaps=n.generateMipmaps,s.internalFormat=n.internalFormat,this.textures=[];const o=n.count;for(let a=0;a<o;a++)this.textures[a]=s.clone(),this.textures[a].isRenderTargetTexture=!0;this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.depthTexture=n.depthTexture,this.samples=n.samples}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let r=0,s=this.textures.length;r<s;r++)this.textures[r].image.width=e,this.textures[r].image.height=t,this.textures[r].image.depth=n;this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let n=0,r=e.textures.length;n<r;n++)this.textures[n]=e.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0;const t=Object.assign({},e.texture.image);return this.texture.source=new T_(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Bi extends eT{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class b_ extends Vn{constructor(e=null,t=1,n=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=Fi,this.minFilter=Fi,this.wrapR=ws,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class tT extends Vn{constructor(e=null,t=1,n=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=Fi,this.minFilter=Fi,this.wrapR=ws,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class nl{constructor(e=0,t=0,n=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=r}static slerpFlat(e,t,n,r,s,o,a){let l=n[r+0],u=n[r+1],c=n[r+2],d=n[r+3];const p=s[o+0],f=s[o+1],_=s[o+2],m=s[o+3];if(a===0){e[t+0]=l,e[t+1]=u,e[t+2]=c,e[t+3]=d;return}if(a===1){e[t+0]=p,e[t+1]=f,e[t+2]=_,e[t+3]=m;return}if(d!==m||l!==p||u!==f||c!==_){let g=1-a;const h=l*p+u*f+c*_+d*m,v=h>=0?1:-1,M=1-h*h;if(M>Number.EPSILON){const P=Math.sqrt(M),E=Math.atan2(P,h*v);g=Math.sin(g*E)/P,a=Math.sin(a*E)/P}const S=a*v;if(l=l*g+p*S,u=u*g+f*S,c=c*g+_*S,d=d*g+m*S,g===1-a){const P=1/Math.sqrt(l*l+u*u+c*c+d*d);l*=P,u*=P,c*=P,d*=P}}e[t]=l,e[t+1]=u,e[t+2]=c,e[t+3]=d}static multiplyQuaternionsFlat(e,t,n,r,s,o){const a=n[r],l=n[r+1],u=n[r+2],c=n[r+3],d=s[o],p=s[o+1],f=s[o+2],_=s[o+3];return e[t]=a*_+c*d+l*f-u*p,e[t+1]=l*_+c*p+u*d-a*f,e[t+2]=u*_+c*f+a*p-l*d,e[t+3]=c*_-a*d-l*p-u*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,r){return this._x=e,this._y=t,this._z=n,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,r=e._y,s=e._z,o=e._order,a=Math.cos,l=Math.sin,u=a(n/2),c=a(r/2),d=a(s/2),p=l(n/2),f=l(r/2),_=l(s/2);switch(o){case"XYZ":this._x=p*c*d+u*f*_,this._y=u*f*d-p*c*_,this._z=u*c*_+p*f*d,this._w=u*c*d-p*f*_;break;case"YXZ":this._x=p*c*d+u*f*_,this._y=u*f*d-p*c*_,this._z=u*c*_-p*f*d,this._w=u*c*d+p*f*_;break;case"ZXY":this._x=p*c*d-u*f*_,this._y=u*f*d+p*c*_,this._z=u*c*_+p*f*d,this._w=u*c*d-p*f*_;break;case"ZYX":this._x=p*c*d-u*f*_,this._y=u*f*d+p*c*_,this._z=u*c*_-p*f*d,this._w=u*c*d+p*f*_;break;case"YZX":this._x=p*c*d+u*f*_,this._y=u*f*d+p*c*_,this._z=u*c*_-p*f*d,this._w=u*c*d-p*f*_;break;case"XZY":this._x=p*c*d-u*f*_,this._y=u*f*d-p*c*_,this._z=u*c*_+p*f*d,this._w=u*c*d+p*f*_;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,r=Math.sin(n);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],r=t[4],s=t[8],o=t[1],a=t[5],l=t[9],u=t[2],c=t[6],d=t[10],p=n+a+d;if(p>0){const f=.5/Math.sqrt(p+1);this._w=.25/f,this._x=(c-l)*f,this._y=(s-u)*f,this._z=(o-r)*f}else if(n>a&&n>d){const f=2*Math.sqrt(1+n-a-d);this._w=(c-l)/f,this._x=.25*f,this._y=(r+o)/f,this._z=(s+u)/f}else if(a>d){const f=2*Math.sqrt(1+a-n-d);this._w=(s-u)/f,this._x=(r+o)/f,this._y=.25*f,this._z=(l+c)/f}else{const f=2*Math.sqrt(1+d-n-a);this._w=(o-r)/f,this._x=(s+u)/f,this._y=(l+c)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<Number.EPSILON?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Yn(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const r=Math.min(1,t/n);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,r=e._y,s=e._z,o=e._w,a=t._x,l=t._y,u=t._z,c=t._w;return this._x=n*c+o*a+r*u-s*l,this._y=r*c+o*l+s*a-n*u,this._z=s*c+o*u+n*l-r*a,this._w=o*c-n*a-r*l-s*u,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);const n=this._x,r=this._y,s=this._z,o=this._w;let a=o*e._w+n*e._x+r*e._y+s*e._z;if(a<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,a=-a):this.copy(e),a>=1)return this._w=o,this._x=n,this._y=r,this._z=s,this;const l=1-a*a;if(l<=Number.EPSILON){const f=1-t;return this._w=f*o+t*this._w,this._x=f*n+t*this._x,this._y=f*r+t*this._y,this._z=f*s+t*this._z,this.normalize(),this}const u=Math.sqrt(l),c=Math.atan2(u,a),d=Math.sin((1-t)*c)/u,p=Math.sin(t*c)/u;return this._w=o*d+this._w*p,this._x=n*d+this._x*p,this._y=r*d+this._y*p,this._z=s*d+this._z*p,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),r=Math.sqrt(1-n),s=Math.sqrt(n);return this.set(r*Math.sin(e),r*Math.cos(e),s*Math.sin(t),s*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class H{constructor(e=0,t=0,n=0){H.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(im.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(im.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6]*r,this.y=s[1]*t+s[4]*n+s[7]*r,this.z=s[2]*t+s[5]*n+s[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,r=this.z,s=e.elements,o=1/(s[3]*t+s[7]*n+s[11]*r+s[15]);return this.x=(s[0]*t+s[4]*n+s[8]*r+s[12])*o,this.y=(s[1]*t+s[5]*n+s[9]*r+s[13])*o,this.z=(s[2]*t+s[6]*n+s[10]*r+s[14])*o,this}applyQuaternion(e){const t=this.x,n=this.y,r=this.z,s=e.x,o=e.y,a=e.z,l=e.w,u=2*(o*r-a*n),c=2*(a*t-s*r),d=2*(s*n-o*t);return this.x=t+l*u+o*d-a*c,this.y=n+l*c+a*u-s*d,this.z=r+l*d+s*c-o*u,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,r=this.z,s=e.elements;return this.x=s[0]*t+s[4]*n+s[8]*r,this.y=s[1]*t+s[5]*n+s[9]*r,this.z=s[2]*t+s[6]*n+s[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(Math.max(e,Math.min(t,n)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,r=e.y,s=e.z,o=t.x,a=t.y,l=t.z;return this.x=r*l-s*a,this.y=s*o-n*l,this.z=n*a-r*o,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return Pu.copy(this).projectOnVector(e),this.sub(Pu)}reflect(e){return this.sub(Pu.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(Yn(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,r=this.z-e.z;return t*t+n*n+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const r=Math.sin(t)*e;return this.x=r*Math.sin(n),this.y=Math.cos(t)*e,this.z=r*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const Pu=new H,im=new nl;class il{constructor(e=new H(1/0,1/0,1/0),t=new H(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(Ei.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(Ei.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=Ei.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const s=n.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let o=0,a=s.count;o<a;o++)e.isMesh===!0?e.getVertexPosition(o,Ei):Ei.fromBufferAttribute(s,o),Ei.applyMatrix4(e.matrixWorld),this.expandByPoint(Ei);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),hl.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),hl.copy(n.boundingBox)),hl.applyMatrix4(e.matrixWorld),this.union(hl)}const r=e.children;for(let s=0,o=r.length;s<o;s++)this.expandByObject(r[s],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Ei),Ei.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(oo),pl.subVectors(this.max,oo),Qs.subVectors(e.a,oo),ea.subVectors(e.b,oo),ta.subVectors(e.c,oo),Nr.subVectors(ea,Qs),Ur.subVectors(ta,ea),fs.subVectors(Qs,ta);let t=[0,-Nr.z,Nr.y,0,-Ur.z,Ur.y,0,-fs.z,fs.y,Nr.z,0,-Nr.x,Ur.z,0,-Ur.x,fs.z,0,-fs.x,-Nr.y,Nr.x,0,-Ur.y,Ur.x,0,-fs.y,fs.x,0];return!Iu(t,Qs,ea,ta,pl)||(t=[1,0,0,0,1,0,0,0,1],!Iu(t,Qs,ea,ta,pl))?!1:(ml.crossVectors(Nr,Ur),t=[ml.x,ml.y,ml.z],Iu(t,Qs,ea,ta,pl))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Ei).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Ei).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(ar[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),ar[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),ar[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),ar[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),ar[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),ar[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),ar[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),ar[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(ar),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}const ar=[new H,new H,new H,new H,new H,new H,new H,new H],Ei=new H,hl=new il,Qs=new H,ea=new H,ta=new H,Nr=new H,Ur=new H,fs=new H,oo=new H,pl=new H,ml=new H,hs=new H;function Iu(i,e,t,n,r){for(let s=0,o=i.length-3;s<=o;s+=3){hs.fromArray(i,s);const a=r.x*Math.abs(hs.x)+r.y*Math.abs(hs.y)+r.z*Math.abs(hs.z),l=e.dot(hs),u=t.dot(hs),c=n.dot(hs);if(Math.max(-Math.max(l,u,c),Math.min(l,u,c))>a)return!1}return!0}const nT=new il,lo=new H,Du=new H;class rl{constructor(e=new H,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):nT.setFromPoints(e).getCenter(n);let r=0;for(let s=0,o=e.length;s<o;s++)r=Math.max(r,n.distanceToSquared(e[s]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;lo.subVectors(e,this.center);const t=lo.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),r=(n-this.radius)*.5;this.center.addScaledVector(lo,r/n),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Du.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(lo.copy(e.center).add(Du)),this.expandByPoint(lo.copy(e.center).sub(Du))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}}const or=new H,Nu=new H,gl=new H,Fr=new H,Uu=new H,_l=new H,Fu=new H;class Nh{constructor(e=new H,t=new H(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,or)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=or.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(or.copy(this.origin).addScaledVector(this.direction,t),or.distanceToSquared(e))}distanceSqToSegment(e,t,n,r){Nu.copy(e).add(t).multiplyScalar(.5),gl.copy(t).sub(e).normalize(),Fr.copy(this.origin).sub(Nu);const s=e.distanceTo(t)*.5,o=-this.direction.dot(gl),a=Fr.dot(this.direction),l=-Fr.dot(gl),u=Fr.lengthSq(),c=Math.abs(1-o*o);let d,p,f,_;if(c>0)if(d=o*l-a,p=o*a-l,_=s*c,d>=0)if(p>=-_)if(p<=_){const m=1/c;d*=m,p*=m,f=d*(d+o*p+2*a)+p*(o*d+p+2*l)+u}else p=s,d=Math.max(0,-(o*p+a)),f=-d*d+p*(p+2*l)+u;else p=-s,d=Math.max(0,-(o*p+a)),f=-d*d+p*(p+2*l)+u;else p<=-_?(d=Math.max(0,-(-o*s+a)),p=d>0?-s:Math.min(Math.max(-s,-l),s),f=-d*d+p*(p+2*l)+u):p<=_?(d=0,p=Math.min(Math.max(-s,-l),s),f=p*(p+2*l)+u):(d=Math.max(0,-(o*s+a)),p=d>0?s:Math.min(Math.max(-s,-l),s),f=-d*d+p*(p+2*l)+u);else p=o>0?-s:s,d=Math.max(0,-(o*p+a)),f=-d*d+p*(p+2*l)+u;return n&&n.copy(this.origin).addScaledVector(this.direction,d),r&&r.copy(Nu).addScaledVector(gl,p),f}intersectSphere(e,t){or.subVectors(e.center,this.origin);const n=or.dot(this.direction),r=or.dot(or)-n*n,s=e.radius*e.radius;if(r>s)return null;const o=Math.sqrt(s-r),a=n-o,l=n+o;return l<0?null:a<0?this.at(l,t):this.at(a,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,r,s,o,a,l;const u=1/this.direction.x,c=1/this.direction.y,d=1/this.direction.z,p=this.origin;return u>=0?(n=(e.min.x-p.x)*u,r=(e.max.x-p.x)*u):(n=(e.max.x-p.x)*u,r=(e.min.x-p.x)*u),c>=0?(s=(e.min.y-p.y)*c,o=(e.max.y-p.y)*c):(s=(e.max.y-p.y)*c,o=(e.min.y-p.y)*c),n>o||s>r||((s>n||isNaN(n))&&(n=s),(o<r||isNaN(r))&&(r=o),d>=0?(a=(e.min.z-p.z)*d,l=(e.max.z-p.z)*d):(a=(e.max.z-p.z)*d,l=(e.min.z-p.z)*d),n>l||a>r)||((a>n||n!==n)&&(n=a),(l<r||r!==r)&&(r=l),r<0)?null:this.at(n>=0?n:r,t)}intersectsBox(e){return this.intersectBox(e,or)!==null}intersectTriangle(e,t,n,r,s){Uu.subVectors(t,e),_l.subVectors(n,e),Fu.crossVectors(Uu,_l);let o=this.direction.dot(Fu),a;if(o>0){if(r)return null;a=1}else if(o<0)a=-1,o=-o;else return null;Fr.subVectors(this.origin,e);const l=a*this.direction.dot(_l.crossVectors(Fr,_l));if(l<0)return null;const u=a*this.direction.dot(Uu.cross(Fr));if(u<0||l+u>o)return null;const c=-a*Fr.dot(Fu);return c<0?null:this.at(c/o,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class rn{constructor(e,t,n,r,s,o,a,l,u,c,d,p,f,_,m,g){rn.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,r,s,o,a,l,u,c,d,p,f,_,m,g)}set(e,t,n,r,s,o,a,l,u,c,d,p,f,_,m,g){const h=this.elements;return h[0]=e,h[4]=t,h[8]=n,h[12]=r,h[1]=s,h[5]=o,h[9]=a,h[13]=l,h[2]=u,h[6]=c,h[10]=d,h[14]=p,h[3]=f,h[7]=_,h[11]=m,h[15]=g,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new rn().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,n=e.elements,r=1/na.setFromMatrixColumn(e,0).length(),s=1/na.setFromMatrixColumn(e,1).length(),o=1/na.setFromMatrixColumn(e,2).length();return t[0]=n[0]*r,t[1]=n[1]*r,t[2]=n[2]*r,t[3]=0,t[4]=n[4]*s,t[5]=n[5]*s,t[6]=n[6]*s,t[7]=0,t[8]=n[8]*o,t[9]=n[9]*o,t[10]=n[10]*o,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,r=e.y,s=e.z,o=Math.cos(n),a=Math.sin(n),l=Math.cos(r),u=Math.sin(r),c=Math.cos(s),d=Math.sin(s);if(e.order==="XYZ"){const p=o*c,f=o*d,_=a*c,m=a*d;t[0]=l*c,t[4]=-l*d,t[8]=u,t[1]=f+_*u,t[5]=p-m*u,t[9]=-a*l,t[2]=m-p*u,t[6]=_+f*u,t[10]=o*l}else if(e.order==="YXZ"){const p=l*c,f=l*d,_=u*c,m=u*d;t[0]=p+m*a,t[4]=_*a-f,t[8]=o*u,t[1]=o*d,t[5]=o*c,t[9]=-a,t[2]=f*a-_,t[6]=m+p*a,t[10]=o*l}else if(e.order==="ZXY"){const p=l*c,f=l*d,_=u*c,m=u*d;t[0]=p-m*a,t[4]=-o*d,t[8]=_+f*a,t[1]=f+_*a,t[5]=o*c,t[9]=m-p*a,t[2]=-o*u,t[6]=a,t[10]=o*l}else if(e.order==="ZYX"){const p=o*c,f=o*d,_=a*c,m=a*d;t[0]=l*c,t[4]=_*u-f,t[8]=p*u+m,t[1]=l*d,t[5]=m*u+p,t[9]=f*u-_,t[2]=-u,t[6]=a*l,t[10]=o*l}else if(e.order==="YZX"){const p=o*l,f=o*u,_=a*l,m=a*u;t[0]=l*c,t[4]=m-p*d,t[8]=_*d+f,t[1]=d,t[5]=o*c,t[9]=-a*c,t[2]=-u*c,t[6]=f*d+_,t[10]=p-m*d}else if(e.order==="XZY"){const p=o*l,f=o*u,_=a*l,m=a*u;t[0]=l*c,t[4]=-d,t[8]=u*c,t[1]=p*d+m,t[5]=o*c,t[9]=f*d-_,t[2]=_*d-f,t[6]=a*c,t[10]=m*d+p}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(iT,e,rT)}lookAt(e,t,n){const r=this.elements;return ei.subVectors(e,t),ei.lengthSq()===0&&(ei.z=1),ei.normalize(),Br.crossVectors(n,ei),Br.lengthSq()===0&&(Math.abs(n.z)===1?ei.x+=1e-4:ei.z+=1e-4,ei.normalize(),Br.crossVectors(n,ei)),Br.normalize(),vl.crossVectors(ei,Br),r[0]=Br.x,r[4]=vl.x,r[8]=ei.x,r[1]=Br.y,r[5]=vl.y,r[9]=ei.y,r[2]=Br.z,r[6]=vl.z,r[10]=ei.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,r=t.elements,s=this.elements,o=n[0],a=n[4],l=n[8],u=n[12],c=n[1],d=n[5],p=n[9],f=n[13],_=n[2],m=n[6],g=n[10],h=n[14],v=n[3],M=n[7],S=n[11],P=n[15],E=r[0],A=r[4],L=r[8],y=r[12],x=r[1],C=r[5],N=r[9],D=r[13],I=r[2],J=r[6],q=r[10],oe=r[14],X=r[3],he=r[7],pe=r[11],Se=r[15];return s[0]=o*E+a*x+l*I+u*X,s[4]=o*A+a*C+l*J+u*he,s[8]=o*L+a*N+l*q+u*pe,s[12]=o*y+a*D+l*oe+u*Se,s[1]=c*E+d*x+p*I+f*X,s[5]=c*A+d*C+p*J+f*he,s[9]=c*L+d*N+p*q+f*pe,s[13]=c*y+d*D+p*oe+f*Se,s[2]=_*E+m*x+g*I+h*X,s[6]=_*A+m*C+g*J+h*he,s[10]=_*L+m*N+g*q+h*pe,s[14]=_*y+m*D+g*oe+h*Se,s[3]=v*E+M*x+S*I+P*X,s[7]=v*A+M*C+S*J+P*he,s[11]=v*L+M*N+S*q+P*pe,s[15]=v*y+M*D+S*oe+P*Se,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],r=e[8],s=e[12],o=e[1],a=e[5],l=e[9],u=e[13],c=e[2],d=e[6],p=e[10],f=e[14],_=e[3],m=e[7],g=e[11],h=e[15];return _*(+s*l*d-r*u*d-s*a*p+n*u*p+r*a*f-n*l*f)+m*(+t*l*f-t*u*p+s*o*p-r*o*f+r*u*c-s*l*c)+g*(+t*u*d-t*a*f-s*o*d+n*o*f+s*a*c-n*u*c)+h*(-r*a*c-t*l*d+t*a*p+r*o*d-n*o*p+n*l*c)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],r=e[2],s=e[3],o=e[4],a=e[5],l=e[6],u=e[7],c=e[8],d=e[9],p=e[10],f=e[11],_=e[12],m=e[13],g=e[14],h=e[15],v=d*g*u-m*p*u+m*l*f-a*g*f-d*l*h+a*p*h,M=_*p*u-c*g*u-_*l*f+o*g*f+c*l*h-o*p*h,S=c*m*u-_*d*u+_*a*f-o*m*f-c*a*h+o*d*h,P=_*d*l-c*m*l-_*a*p+o*m*p+c*a*g-o*d*g,E=t*v+n*M+r*S+s*P;if(E===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const A=1/E;return e[0]=v*A,e[1]=(m*p*s-d*g*s-m*r*f+n*g*f+d*r*h-n*p*h)*A,e[2]=(a*g*s-m*l*s+m*r*u-n*g*u-a*r*h+n*l*h)*A,e[3]=(d*l*s-a*p*s-d*r*u+n*p*u+a*r*f-n*l*f)*A,e[4]=M*A,e[5]=(c*g*s-_*p*s+_*r*f-t*g*f-c*r*h+t*p*h)*A,e[6]=(_*l*s-o*g*s-_*r*u+t*g*u+o*r*h-t*l*h)*A,e[7]=(o*p*s-c*l*s+c*r*u-t*p*u-o*r*f+t*l*f)*A,e[8]=S*A,e[9]=(_*d*s-c*m*s-_*n*f+t*m*f+c*n*h-t*d*h)*A,e[10]=(o*m*s-_*a*s+_*n*u-t*m*u-o*n*h+t*a*h)*A,e[11]=(c*a*s-o*d*s-c*n*u+t*d*u+o*n*f-t*a*f)*A,e[12]=P*A,e[13]=(c*m*r-_*d*r+_*n*p-t*m*p-c*n*g+t*d*g)*A,e[14]=(_*a*r-o*m*r-_*n*l+t*m*l+o*n*g-t*a*g)*A,e[15]=(o*d*r-c*a*r+c*n*l-t*d*l-o*n*p+t*a*p)*A,this}scale(e){const t=this.elements,n=e.x,r=e.y,s=e.z;return t[0]*=n,t[4]*=r,t[8]*=s,t[1]*=n,t[5]*=r,t[9]*=s,t[2]*=n,t[6]*=r,t[10]*=s,t[3]*=n,t[7]*=r,t[11]*=s,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,r))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),r=Math.sin(t),s=1-n,o=e.x,a=e.y,l=e.z,u=s*o,c=s*a;return this.set(u*o+n,u*a-r*l,u*l+r*a,0,u*a+r*l,c*a+n,c*l-r*o,0,u*l-r*a,c*l+r*o,s*l*l+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,r,s,o){return this.set(1,n,s,0,e,1,o,0,t,r,1,0,0,0,0,1),this}compose(e,t,n){const r=this.elements,s=t._x,o=t._y,a=t._z,l=t._w,u=s+s,c=o+o,d=a+a,p=s*u,f=s*c,_=s*d,m=o*c,g=o*d,h=a*d,v=l*u,M=l*c,S=l*d,P=n.x,E=n.y,A=n.z;return r[0]=(1-(m+h))*P,r[1]=(f+S)*P,r[2]=(_-M)*P,r[3]=0,r[4]=(f-S)*E,r[5]=(1-(p+h))*E,r[6]=(g+v)*E,r[7]=0,r[8]=(_+M)*A,r[9]=(g-v)*A,r[10]=(1-(p+m))*A,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,n){const r=this.elements;let s=na.set(r[0],r[1],r[2]).length();const o=na.set(r[4],r[5],r[6]).length(),a=na.set(r[8],r[9],r[10]).length();this.determinant()<0&&(s=-s),e.x=r[12],e.y=r[13],e.z=r[14],Ai.copy(this);const u=1/s,c=1/o,d=1/a;return Ai.elements[0]*=u,Ai.elements[1]*=u,Ai.elements[2]*=u,Ai.elements[4]*=c,Ai.elements[5]*=c,Ai.elements[6]*=c,Ai.elements[8]*=d,Ai.elements[9]*=d,Ai.elements[10]*=d,t.setFromRotationMatrix(Ai),n.x=s,n.y=o,n.z=a,this}makePerspective(e,t,n,r,s,o,a=Mr){const l=this.elements,u=2*s/(t-e),c=2*s/(n-r),d=(t+e)/(t-e),p=(n+r)/(n-r);let f,_;if(a===Mr)f=-(o+s)/(o-s),_=-2*o*s/(o-s);else if(a===bc)f=-o/(o-s),_=-o*s/(o-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=u,l[4]=0,l[8]=d,l[12]=0,l[1]=0,l[5]=c,l[9]=p,l[13]=0,l[2]=0,l[6]=0,l[10]=f,l[14]=_,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,n,r,s,o,a=Mr){const l=this.elements,u=1/(t-e),c=1/(n-r),d=1/(o-s),p=(t+e)*u,f=(n+r)*c;let _,m;if(a===Mr)_=(o+s)*d,m=-2*d;else if(a===bc)_=s*d,m=-1*d;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=2*u,l[4]=0,l[8]=0,l[12]=-p,l[1]=0,l[5]=2*c,l[9]=0,l[13]=-f,l[2]=0,l[6]=0,l[10]=m,l[14]=-_,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let r=0;r<16;r++)if(t[r]!==n[r])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}}const na=new H,Ai=new rn,iT=new H(0,0,0),rT=new H(1,1,1),Br=new H,vl=new H,ei=new H,rm=new rn,sm=new nl;class Lr{constructor(e=0,t=0,n=0,r=Lr.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,r=this._order){return this._x=e,this._y=t,this._z=n,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const r=e.elements,s=r[0],o=r[4],a=r[8],l=r[1],u=r[5],c=r[9],d=r[2],p=r[6],f=r[10];switch(t){case"XYZ":this._y=Math.asin(Yn(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-c,f),this._z=Math.atan2(-o,s)):(this._x=Math.atan2(p,u),this._z=0);break;case"YXZ":this._x=Math.asin(-Yn(c,-1,1)),Math.abs(c)<.9999999?(this._y=Math.atan2(a,f),this._z=Math.atan2(l,u)):(this._y=Math.atan2(-d,s),this._z=0);break;case"ZXY":this._x=Math.asin(Yn(p,-1,1)),Math.abs(p)<.9999999?(this._y=Math.atan2(-d,f),this._z=Math.atan2(-o,u)):(this._y=0,this._z=Math.atan2(l,s));break;case"ZYX":this._y=Math.asin(-Yn(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(p,f),this._z=Math.atan2(l,s)):(this._x=0,this._z=Math.atan2(-o,u));break;case"YZX":this._z=Math.asin(Yn(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-c,u),this._y=Math.atan2(-d,s)):(this._x=0,this._y=Math.atan2(a,f));break;case"XZY":this._z=Math.asin(-Yn(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(p,u),this._y=Math.atan2(a,s)):(this._x=Math.atan2(-c,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return rm.makeRotationFromQuaternion(e),this.setFromRotationMatrix(rm,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return sm.setFromEuler(this),this.setFromQuaternion(sm,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Lr.DEFAULT_ORDER="XYZ";class E_{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let sT=0;const am=new H,ia=new nl,lr=new rn,Ml=new H,co=new H,aT=new H,oT=new nl,om=new H(1,0,0),lm=new H(0,1,0),cm=new H(0,0,1),um={type:"added"},lT={type:"removed"},ra={type:"childadded",child:null},Bu={type:"childremoved",child:null};class Gn extends eo{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:sT++}),this.uuid=tl(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Gn.DEFAULT_UP.clone();const e=new H,t=new Lr,n=new nl,r=new H(1,1,1);function s(){n.setFromEuler(t,!1)}function o(){t.setFromQuaternion(n,void 0,!1)}t._onChange(s),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new rn},normalMatrix:{value:new at}}),this.matrix=new rn,this.matrixWorld=new rn,this.matrixAutoUpdate=Gn.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Gn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new E_,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return ia.setFromAxisAngle(e,t),this.quaternion.multiply(ia),this}rotateOnWorldAxis(e,t){return ia.setFromAxisAngle(e,t),this.quaternion.premultiply(ia),this}rotateX(e){return this.rotateOnAxis(om,e)}rotateY(e){return this.rotateOnAxis(lm,e)}rotateZ(e){return this.rotateOnAxis(cm,e)}translateOnAxis(e,t){return am.copy(e).applyQuaternion(this.quaternion),this.position.add(am.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(om,e)}translateY(e){return this.translateOnAxis(lm,e)}translateZ(e){return this.translateOnAxis(cm,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(lr.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?Ml.copy(e):Ml.set(e,t,n);const r=this.parent;this.updateWorldMatrix(!0,!1),co.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?lr.lookAt(co,Ml,this.up):lr.lookAt(Ml,co,this.up),this.quaternion.setFromRotationMatrix(lr),r&&(lr.extractRotation(r.matrixWorld),ia.setFromRotationMatrix(lr),this.quaternion.premultiply(ia.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(um),ra.child=e,this.dispatchEvent(ra),ra.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(lT),Bu.child=e,this.dispatchEvent(Bu),Bu.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),lr.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),lr.multiply(e.parent.matrixWorld)),e.applyMatrix4(lr),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(um),ra.child=e,this.dispatchEvent(ra),ra.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,r=this.children.length;n<r;n++){const o=this.children[n].getObjectByProperty(e,t);if(o!==void 0)return o}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const r=this.children;for(let s=0,o=r.length;s<o;s++)r[s].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(co,e,aT),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(co,oT,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t){const n=this.parent;if(e===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){const r=this.children;for(let s=0,o=r.length;s<o;s++)r[s].updateWorldMatrix(!1,!0)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.castShadow===!0&&(r.castShadow=!0),this.receiveShadow===!0&&(r.receiveShadow=!0),this.visible===!1&&(r.visible=!1),this.frustumCulled===!1&&(r.frustumCulled=!1),this.renderOrder!==0&&(r.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(r.matrixAutoUpdate=!1),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.visibility=this._visibility,r.active=this._active,r.bounds=this._bounds.map(a=>({boxInitialized:a.boxInitialized,boxMin:a.box.min.toArray(),boxMax:a.box.max.toArray(),sphereInitialized:a.sphereInitialized,sphereRadius:a.sphere.radius,sphereCenter:a.sphere.center.toArray()})),r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.geometryCount=this._geometryCount,r.matricesTexture=this._matricesTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere={center:r.boundingSphere.center.toArray(),radius:r.boundingSphere.radius}),this.boundingBox!==null&&(r.boundingBox={min:r.boundingBox.min.toArray(),max:r.boundingBox.max.toArray()}));function s(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=s(e.geometries,this.geometry);const a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){const l=a.shapes;if(Array.isArray(l))for(let u=0,c=l.length;u<c;u++){const d=l[u];s(e.shapes,d)}else s(e.shapes,l)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const a=[];for(let l=0,u=this.material.length;l<u;l++)a.push(s(e.materials,this.material[l]));r.material=a}else r.material=s(e.materials,this.material);if(this.children.length>0){r.children=[];for(let a=0;a<this.children.length;a++)r.children.push(this.children[a].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let a=0;a<this.animations.length;a++){const l=this.animations[a];r.animations.push(s(e.animations,l))}}if(t){const a=o(e.geometries),l=o(e.materials),u=o(e.textures),c=o(e.images),d=o(e.shapes),p=o(e.skeletons),f=o(e.animations),_=o(e.nodes);a.length>0&&(n.geometries=a),l.length>0&&(n.materials=l),u.length>0&&(n.textures=u),c.length>0&&(n.images=c),d.length>0&&(n.shapes=d),p.length>0&&(n.skeletons=p),f.length>0&&(n.animations=f),_.length>0&&(n.nodes=_)}return n.object=r,n;function o(a){const l=[];for(const u in a){const c=a[u];delete c.metadata,l.push(c)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const r=e.children[n];this.add(r.clone())}return this}}Gn.DEFAULT_UP=new H(0,1,0);Gn.DEFAULT_MATRIX_AUTO_UPDATE=!0;Gn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const wi=new H,cr=new H,Ou=new H,ur=new H,sa=new H,aa=new H,dm=new H,ku=new H,Hu=new H,Vu=new H,Gu=new un,zu=new un,Wu=new un;class mi{constructor(e=new H,t=new H,n=new H){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,r){r.subVectors(n,t),wi.subVectors(e,t),r.cross(wi);const s=r.lengthSq();return s>0?r.multiplyScalar(1/Math.sqrt(s)):r.set(0,0,0)}static getBarycoord(e,t,n,r,s){wi.subVectors(r,t),cr.subVectors(n,t),Ou.subVectors(e,t);const o=wi.dot(wi),a=wi.dot(cr),l=wi.dot(Ou),u=cr.dot(cr),c=cr.dot(Ou),d=o*u-a*a;if(d===0)return s.set(0,0,0),null;const p=1/d,f=(u*l-a*c)*p,_=(o*c-a*l)*p;return s.set(1-f-_,_,f)}static containsPoint(e,t,n,r){return this.getBarycoord(e,t,n,r,ur)===null?!1:ur.x>=0&&ur.y>=0&&ur.x+ur.y<=1}static getInterpolation(e,t,n,r,s,o,a,l){return this.getBarycoord(e,t,n,r,ur)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(s,ur.x),l.addScaledVector(o,ur.y),l.addScaledVector(a,ur.z),l)}static getInterpolatedAttribute(e,t,n,r,s,o){return Gu.setScalar(0),zu.setScalar(0),Wu.setScalar(0),Gu.fromBufferAttribute(e,t),zu.fromBufferAttribute(e,n),Wu.fromBufferAttribute(e,r),o.setScalar(0),o.addScaledVector(Gu,s.x),o.addScaledVector(zu,s.y),o.addScaledVector(Wu,s.z),o}static isFrontFacing(e,t,n,r){return wi.subVectors(n,t),cr.subVectors(e,t),wi.cross(cr).dot(r)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,r){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,n,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return wi.subVectors(this.c,this.b),cr.subVectors(this.a,this.b),wi.cross(cr).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return mi.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return mi.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,r,s){return mi.getInterpolation(e,this.a,this.b,this.c,t,n,r,s)}containsPoint(e){return mi.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return mi.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,r=this.b,s=this.c;let o,a;sa.subVectors(r,n),aa.subVectors(s,n),ku.subVectors(e,n);const l=sa.dot(ku),u=aa.dot(ku);if(l<=0&&u<=0)return t.copy(n);Hu.subVectors(e,r);const c=sa.dot(Hu),d=aa.dot(Hu);if(c>=0&&d<=c)return t.copy(r);const p=l*d-c*u;if(p<=0&&l>=0&&c<=0)return o=l/(l-c),t.copy(n).addScaledVector(sa,o);Vu.subVectors(e,s);const f=sa.dot(Vu),_=aa.dot(Vu);if(_>=0&&f<=_)return t.copy(s);const m=f*u-l*_;if(m<=0&&u>=0&&_<=0)return a=u/(u-_),t.copy(n).addScaledVector(aa,a);const g=c*_-f*d;if(g<=0&&d-c>=0&&f-_>=0)return dm.subVectors(s,r),a=(d-c)/(d-c+(f-_)),t.copy(r).addScaledVector(dm,a);const h=1/(g+m+p);return o=m*h,a=p*h,t.copy(n).addScaledVector(sa,o).addScaledVector(aa,a)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const A_={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Or={h:0,s:0,l:0},Sl={h:0,s:0,l:0};function Ku(i,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?i+(e-i)*6*t:t<1/2?e:t<2/3?i+(e-i)*6*(2/3-t):i}class pt{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=ni){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,vt.toWorkingColorSpace(this,t),this}setRGB(e,t,n,r=vt.workingColorSpace){return this.r=e,this.g=t,this.b=n,vt.toWorkingColorSpace(this,r),this}setHSL(e,t,n,r=vt.workingColorSpace){if(e=Xy(e,1),t=Yn(t,0,1),n=Yn(n,0,1),t===0)this.r=this.g=this.b=n;else{const s=n<=.5?n*(1+t):n+t-n*t,o=2*n-s;this.r=Ku(o,s,e+1/3),this.g=Ku(o,s,e),this.b=Ku(o,s,e-1/3)}return vt.toWorkingColorSpace(this,r),this}setStyle(e,t=ni){function n(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let s;const o=r[1],a=r[2];switch(o){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){const s=r[1],o=s.length;if(o===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(o===6)return this.setHex(parseInt(s,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=ni){const n=A_[e.toLowerCase()];return n!==void 0?this.setHex(n,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=br(e.r),this.g=br(e.g),this.b=br(e.b),this}copyLinearToSRGB(e){return this.r=wa(e.r),this.g=wa(e.g),this.b=wa(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=ni){return vt.fromWorkingColorSpace(Ln.copy(this),e),Math.round(Yn(Ln.r*255,0,255))*65536+Math.round(Yn(Ln.g*255,0,255))*256+Math.round(Yn(Ln.b*255,0,255))}getHexString(e=ni){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=vt.workingColorSpace){vt.fromWorkingColorSpace(Ln.copy(this),t);const n=Ln.r,r=Ln.g,s=Ln.b,o=Math.max(n,r,s),a=Math.min(n,r,s);let l,u;const c=(a+o)/2;if(a===o)l=0,u=0;else{const d=o-a;switch(u=c<=.5?d/(o+a):d/(2-o-a),o){case n:l=(r-s)/d+(r<s?6:0);break;case r:l=(s-n)/d+2;break;case s:l=(n-r)/d+4;break}l/=6}return e.h=l,e.s=u,e.l=c,e}getRGB(e,t=vt.workingColorSpace){return vt.fromWorkingColorSpace(Ln.copy(this),t),e.r=Ln.r,e.g=Ln.g,e.b=Ln.b,e}getStyle(e=ni){vt.fromWorkingColorSpace(Ln.copy(this),e);const t=Ln.r,n=Ln.g,r=Ln.b;return e!==ni?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(r*255)})`}offsetHSL(e,t,n){return this.getHSL(Or),this.setHSL(Or.h+e,Or.s+t,Or.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(Or),e.getHSL(Sl);const n=Cu(Or.h,Sl.h,t),r=Cu(Or.s,Sl.s,t),s=Cu(Or.l,Sl.l,t);return this.setHSL(n,r,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,r=this.b,s=e.elements;return this.r=s[0]*t+s[3]*n+s[6]*r,this.g=s[1]*t+s[4]*n+s[7]*r,this.b=s[2]*t+s[5]*n+s[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Ln=new pt;pt.NAMES=A_;let cT=0;class to extends eo{static get type(){return"Material"}get type(){return this.constructor.type}set type(e){}constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:cT++}),this.uuid=tl(),this.name="",this.blending=Ea,this.side=rs,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=jd,this.blendDst=Jd,this.blendEquation=xs,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new pt(0,0,0),this.blendAlpha=0,this.depthFunc=ka,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Yp,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=js,this.stencilZFail=js,this.stencilZPass=js,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}const r=this[t];if(r===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(n):r&&r.isVector3&&n&&n.isVector3?r.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==Ea&&(n.blending=this.blending),this.side!==rs&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==jd&&(n.blendSrc=this.blendSrc),this.blendDst!==Jd&&(n.blendDst=this.blendDst),this.blendEquation!==xs&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==ka&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Yp&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==js&&(n.stencilFail=this.stencilFail),this.stencilZFail!==js&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==js&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function r(s){const o=[];for(const a in s){const l=s[a];delete l.metadata,o.push(l)}return o}if(t){const s=r(e.textures),o=r(e.images);s.length>0&&(n.textures=s),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const r=t.length;n=new Array(r);for(let s=0;s!==r;++s)n[s]=t[s].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}}class xi extends to{static get type(){return"MeshBasicMaterial"}constructor(e){super(),this.isMeshBasicMaterial=!0,this.color=new pt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Lr,this.combine=c_,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const mn=new H,xl=new tt;class ir{constructor(e,t,n=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=$p,this.updateRanges=[],this.gpuType=vr,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let r=0,s=this.itemSize;r<s;r++)this.array[e+r]=t.array[n+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)xl.fromBufferAttribute(this,t),xl.applyMatrix3(e),this.setXY(t,xl.x,xl.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)mn.fromBufferAttribute(this,t),mn.applyMatrix3(e),this.setXYZ(t,mn.x,mn.y,mn.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)mn.fromBufferAttribute(this,t),mn.applyMatrix4(e),this.setXYZ(t,mn.x,mn.y,mn.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)mn.fromBufferAttribute(this,t),mn.applyNormalMatrix(e),this.setXYZ(t,mn.x,mn.y,mn.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)mn.fromBufferAttribute(this,t),mn.transformDirection(e),this.setXYZ(t,mn.x,mn.y,mn.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=ao(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=Xn(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=ao(t,this.array)),t}setX(e,t){return this.normalized&&(t=Xn(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=ao(t,this.array)),t}setY(e,t){return this.normalized&&(t=Xn(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=ao(t,this.array)),t}setZ(e,t){return this.normalized&&(t=Xn(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=ao(t,this.array)),t}setW(e,t){return this.normalized&&(t=Xn(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=Xn(t,this.array),n=Xn(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,r){return e*=this.itemSize,this.normalized&&(t=Xn(t,this.array),n=Xn(n,this.array),r=Xn(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this}setXYZW(e,t,n,r,s){return e*=this.itemSize,this.normalized&&(t=Xn(t,this.array),n=Xn(n,this.array),r=Xn(r,this.array),s=Xn(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==$p&&(e.usage=this.usage),e}}class w_ extends ir{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class C_ extends ir{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class At extends ir{constructor(e,t,n){super(new Float32Array(e),t,n)}}let uT=0;const ui=new rn,Xu=new Gn,oa=new H,ti=new il,uo=new il,Mn=new H;class sn extends eo{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:uT++}),this.uuid=tl(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(y_(e)?C_:w_)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const s=new at().getNormalMatrix(e);n.applyNormalMatrix(s),n.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return ui.makeRotationFromQuaternion(e),this.applyMatrix4(ui),this}rotateX(e){return ui.makeRotationX(e),this.applyMatrix4(ui),this}rotateY(e){return ui.makeRotationY(e),this.applyMatrix4(ui),this}rotateZ(e){return ui.makeRotationZ(e),this.applyMatrix4(ui),this}translate(e,t,n){return ui.makeTranslation(e,t,n),this.applyMatrix4(ui),this}scale(e,t,n){return ui.makeScale(e,t,n),this.applyMatrix4(ui),this}lookAt(e){return Xu.lookAt(e),Xu.updateMatrix(),this.applyMatrix4(Xu.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(oa).negate(),this.translate(oa.x,oa.y,oa.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let r=0,s=e.length;r<s;r++){const o=e[r];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new At(n,3))}else{for(let n=0,r=t.count;n<r;n++){const s=e[n];t.setXYZ(n,s.x,s.y,s.z||0)}e.length>t.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new il);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new H(-1/0,-1/0,-1/0),new H(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,r=t.length;n<r;n++){const s=t[n];ti.setFromBufferAttribute(s),this.morphTargetsRelative?(Mn.addVectors(this.boundingBox.min,ti.min),this.boundingBox.expandByPoint(Mn),Mn.addVectors(this.boundingBox.max,ti.max),this.boundingBox.expandByPoint(Mn)):(this.boundingBox.expandByPoint(ti.min),this.boundingBox.expandByPoint(ti.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new rl);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new H,1/0);return}if(e){const n=this.boundingSphere.center;if(ti.setFromBufferAttribute(e),t)for(let s=0,o=t.length;s<o;s++){const a=t[s];uo.setFromBufferAttribute(a),this.morphTargetsRelative?(Mn.addVectors(ti.min,uo.min),ti.expandByPoint(Mn),Mn.addVectors(ti.max,uo.max),ti.expandByPoint(Mn)):(ti.expandByPoint(uo.min),ti.expandByPoint(uo.max))}ti.getCenter(n);let r=0;for(let s=0,o=e.count;s<o;s++)Mn.fromBufferAttribute(e,s),r=Math.max(r,n.distanceToSquared(Mn));if(t)for(let s=0,o=t.length;s<o;s++){const a=t[s],l=this.morphTargetsRelative;for(let u=0,c=a.count;u<c;u++)Mn.fromBufferAttribute(a,u),l&&(oa.fromBufferAttribute(e,u),Mn.add(oa)),r=Math.max(r,n.distanceToSquared(Mn))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,r=t.normal,s=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new ir(new Float32Array(4*n.count),4));const o=this.getAttribute("tangent"),a=[],l=[];for(let L=0;L<n.count;L++)a[L]=new H,l[L]=new H;const u=new H,c=new H,d=new H,p=new tt,f=new tt,_=new tt,m=new H,g=new H;function h(L,y,x){u.fromBufferAttribute(n,L),c.fromBufferAttribute(n,y),d.fromBufferAttribute(n,x),p.fromBufferAttribute(s,L),f.fromBufferAttribute(s,y),_.fromBufferAttribute(s,x),c.sub(u),d.sub(u),f.sub(p),_.sub(p);const C=1/(f.x*_.y-_.x*f.y);isFinite(C)&&(m.copy(c).multiplyScalar(_.y).addScaledVector(d,-f.y).multiplyScalar(C),g.copy(d).multiplyScalar(f.x).addScaledVector(c,-_.x).multiplyScalar(C),a[L].add(m),a[y].add(m),a[x].add(m),l[L].add(g),l[y].add(g),l[x].add(g))}let v=this.groups;v.length===0&&(v=[{start:0,count:e.count}]);for(let L=0,y=v.length;L<y;++L){const x=v[L],C=x.start,N=x.count;for(let D=C,I=C+N;D<I;D+=3)h(e.getX(D+0),e.getX(D+1),e.getX(D+2))}const M=new H,S=new H,P=new H,E=new H;function A(L){P.fromBufferAttribute(r,L),E.copy(P);const y=a[L];M.copy(y),M.sub(P.multiplyScalar(P.dot(y))).normalize(),S.crossVectors(E,y);const C=S.dot(l[L])<0?-1:1;o.setXYZW(L,M.x,M.y,M.z,C)}for(let L=0,y=v.length;L<y;++L){const x=v[L],C=x.start,N=x.count;for(let D=C,I=C+N;D<I;D+=3)A(e.getX(D+0)),A(e.getX(D+1)),A(e.getX(D+2))}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new ir(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let p=0,f=n.count;p<f;p++)n.setXYZ(p,0,0,0);const r=new H,s=new H,o=new H,a=new H,l=new H,u=new H,c=new H,d=new H;if(e)for(let p=0,f=e.count;p<f;p+=3){const _=e.getX(p+0),m=e.getX(p+1),g=e.getX(p+2);r.fromBufferAttribute(t,_),s.fromBufferAttribute(t,m),o.fromBufferAttribute(t,g),c.subVectors(o,s),d.subVectors(r,s),c.cross(d),a.fromBufferAttribute(n,_),l.fromBufferAttribute(n,m),u.fromBufferAttribute(n,g),a.add(c),l.add(c),u.add(c),n.setXYZ(_,a.x,a.y,a.z),n.setXYZ(m,l.x,l.y,l.z),n.setXYZ(g,u.x,u.y,u.z)}else for(let p=0,f=t.count;p<f;p+=3)r.fromBufferAttribute(t,p+0),s.fromBufferAttribute(t,p+1),o.fromBufferAttribute(t,p+2),c.subVectors(o,s),d.subVectors(r,s),c.cross(d),n.setXYZ(p+0,c.x,c.y,c.z),n.setXYZ(p+1,c.x,c.y,c.z),n.setXYZ(p+2,c.x,c.y,c.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Mn.fromBufferAttribute(e,t),Mn.normalize(),e.setXYZ(t,Mn.x,Mn.y,Mn.z)}toNonIndexed(){function e(a,l){const u=a.array,c=a.itemSize,d=a.normalized,p=new u.constructor(l.length*c);let f=0,_=0;for(let m=0,g=l.length;m<g;m++){a.isInterleavedBufferAttribute?f=l[m]*a.data.stride+a.offset:f=l[m]*c;for(let h=0;h<c;h++)p[_++]=u[f++]}return new ir(p,c,d)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new sn,n=this.index.array,r=this.attributes;for(const a in r){const l=r[a],u=e(l,n);t.setAttribute(a,u)}const s=this.morphAttributes;for(const a in s){const l=[],u=s[a];for(let c=0,d=u.length;c<d;c++){const p=u[c],f=e(p,n);l.push(f)}t.morphAttributes[a]=l}t.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let a=0,l=o.length;a<l;a++){const u=o[a];t.addGroup(u.start,u.count,u.materialIndex)}return t}toJSON(){const e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const l=this.parameters;for(const u in l)l[u]!==void 0&&(e[u]=l[u]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const l in n){const u=n[l];e.data.attributes[l]=u.toJSON(e.data)}const r={};let s=!1;for(const l in this.morphAttributes){const u=this.morphAttributes[l],c=[];for(let d=0,p=u.length;d<p;d++){const f=u[d];c.push(f.toJSON(e.data))}c.length>0&&(r[l]=c,s=!0)}s&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));const a=this.boundingSphere;return a!==null&&(e.data.boundingSphere={center:a.center.toArray(),radius:a.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone(t));const r=e.attributes;for(const u in r){const c=r[u];this.setAttribute(u,c.clone(t))}const s=e.morphAttributes;for(const u in s){const c=[],d=s[u];for(let p=0,f=d.length;p<f;p++)c.push(d[p].clone(t));this.morphAttributes[u]=c}this.morphTargetsRelative=e.morphTargetsRelative;const o=e.groups;for(let u=0,c=o.length;u<c;u++){const d=o[u];this.addGroup(d.start,d.count,d.materialIndex)}const a=e.boundingBox;a!==null&&(this.boundingBox=a.clone());const l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const fm=new rn,ps=new Nh,yl=new rl,hm=new H,Tl=new H,bl=new H,El=new H,qu=new H,Al=new H,pm=new H,wl=new H;class je extends Gn{constructor(e=new sn,t=new xi){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const r=t[n[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,o=r.length;s<o;s++){const a=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=s}}}}getVertexPosition(e,t){const n=this.geometry,r=n.attributes.position,s=n.morphAttributes.position,o=n.morphTargetsRelative;t.fromBufferAttribute(r,e);const a=this.morphTargetInfluences;if(s&&a){Al.set(0,0,0);for(let l=0,u=s.length;l<u;l++){const c=a[l],d=s[l];c!==0&&(qu.fromBufferAttribute(d,e),o?Al.addScaledVector(qu,c):Al.addScaledVector(qu.sub(t),c))}t.add(Al)}return t}raycast(e,t){const n=this.geometry,r=this.material,s=this.matrixWorld;r!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),yl.copy(n.boundingSphere),yl.applyMatrix4(s),ps.copy(e.ray).recast(e.near),!(yl.containsPoint(ps.origin)===!1&&(ps.intersectSphere(yl,hm)===null||ps.origin.distanceToSquared(hm)>(e.far-e.near)**2))&&(fm.copy(s).invert(),ps.copy(e.ray).applyMatrix4(fm),!(n.boundingBox!==null&&ps.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,ps)))}_computeIntersections(e,t,n){let r;const s=this.geometry,o=this.material,a=s.index,l=s.attributes.position,u=s.attributes.uv,c=s.attributes.uv1,d=s.attributes.normal,p=s.groups,f=s.drawRange;if(a!==null)if(Array.isArray(o))for(let _=0,m=p.length;_<m;_++){const g=p[_],h=o[g.materialIndex],v=Math.max(g.start,f.start),M=Math.min(a.count,Math.min(g.start+g.count,f.start+f.count));for(let S=v,P=M;S<P;S+=3){const E=a.getX(S),A=a.getX(S+1),L=a.getX(S+2);r=Cl(this,h,e,n,u,c,d,E,A,L),r&&(r.faceIndex=Math.floor(S/3),r.face.materialIndex=g.materialIndex,t.push(r))}}else{const _=Math.max(0,f.start),m=Math.min(a.count,f.start+f.count);for(let g=_,h=m;g<h;g+=3){const v=a.getX(g),M=a.getX(g+1),S=a.getX(g+2);r=Cl(this,o,e,n,u,c,d,v,M,S),r&&(r.faceIndex=Math.floor(g/3),t.push(r))}}else if(l!==void 0)if(Array.isArray(o))for(let _=0,m=p.length;_<m;_++){const g=p[_],h=o[g.materialIndex],v=Math.max(g.start,f.start),M=Math.min(l.count,Math.min(g.start+g.count,f.start+f.count));for(let S=v,P=M;S<P;S+=3){const E=S,A=S+1,L=S+2;r=Cl(this,h,e,n,u,c,d,E,A,L),r&&(r.faceIndex=Math.floor(S/3),r.face.materialIndex=g.materialIndex,t.push(r))}}else{const _=Math.max(0,f.start),m=Math.min(l.count,f.start+f.count);for(let g=_,h=m;g<h;g+=3){const v=g,M=g+1,S=g+2;r=Cl(this,o,e,n,u,c,d,v,M,S),r&&(r.faceIndex=Math.floor(g/3),t.push(r))}}}}function dT(i,e,t,n,r,s,o,a){let l;if(e.side===Jn?l=n.intersectTriangle(o,s,r,!0,a):l=n.intersectTriangle(r,s,o,e.side===rs,a),l===null)return null;wl.copy(a),wl.applyMatrix4(i.matrixWorld);const u=t.ray.origin.distanceTo(wl);return u<t.near||u>t.far?null:{distance:u,point:wl.clone(),object:i}}function Cl(i,e,t,n,r,s,o,a,l,u){i.getVertexPosition(a,Tl),i.getVertexPosition(l,bl),i.getVertexPosition(u,El);const c=dT(i,e,t,n,Tl,bl,El,pm);if(c){const d=new H;mi.getBarycoord(pm,Tl,bl,El,d),r&&(c.uv=mi.getInterpolatedAttribute(r,a,l,u,d,new tt)),s&&(c.uv1=mi.getInterpolatedAttribute(s,a,l,u,d,new tt)),o&&(c.normal=mi.getInterpolatedAttribute(o,a,l,u,d,new H),c.normal.dot(n.direction)>0&&c.normal.multiplyScalar(-1));const p={a,b:l,c:u,normal:new H,materialIndex:0};mi.getNormal(Tl,bl,El,p.normal),c.face=p,c.barycoord=d}return c}class ss extends sn{constructor(e=1,t=1,n=1,r=1,s=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:r,heightSegments:s,depthSegments:o};const a=this;r=Math.floor(r),s=Math.floor(s),o=Math.floor(o);const l=[],u=[],c=[],d=[];let p=0,f=0;_("z","y","x",-1,-1,n,t,e,o,s,0),_("z","y","x",1,-1,n,t,-e,o,s,1),_("x","z","y",1,1,e,n,t,r,o,2),_("x","z","y",1,-1,e,n,-t,r,o,3),_("x","y","z",1,-1,e,t,n,r,s,4),_("x","y","z",-1,-1,e,t,-n,r,s,5),this.setIndex(l),this.setAttribute("position",new At(u,3)),this.setAttribute("normal",new At(c,3)),this.setAttribute("uv",new At(d,2));function _(m,g,h,v,M,S,P,E,A,L,y){const x=S/A,C=P/L,N=S/2,D=P/2,I=E/2,J=A+1,q=L+1;let oe=0,X=0;const he=new H;for(let pe=0;pe<q;pe++){const Se=pe*C-D;for(let Ne=0;Ne<J;Ne++){const nt=Ne*x-N;he[m]=nt*v,he[g]=Se*M,he[h]=I,u.push(he.x,he.y,he.z),he[m]=0,he[g]=0,he[h]=E>0?1:-1,c.push(he.x,he.y,he.z),d.push(Ne/A),d.push(1-pe/L),oe+=1}}for(let pe=0;pe<L;pe++)for(let Se=0;Se<A;Se++){const Ne=p+Se+J*pe,nt=p+Se+J*(pe+1),Z=p+(Se+1)+J*(pe+1),le=p+(Se+1)+J*pe;l.push(Ne,nt,le),l.push(nt,Z,le),X+=6}a.addGroup(f,X,y),f+=X,p+=oe}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ss(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function Wa(i){const e={};for(const t in i){e[t]={};for(const n in i[t]){const r=i[t][n];r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)?r.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=r.clone():Array.isArray(r)?e[t][n]=r.slice():e[t][n]=r}}return e}function Fn(i){const e={};for(let t=0;t<i.length;t++){const n=Wa(i[t]);for(const r in n)e[r]=n[r]}return e}function fT(i){const e=[];for(let t=0;t<i.length;t++)e.push(i[t].clone());return e}function R_(i){const e=i.getRenderTarget();return e===null?i.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:vt.workingColorSpace}const Ec={clone:Wa,merge:Fn};var hT=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,pT=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Zn extends to{static get type(){return"ShaderMaterial"}constructor(e){super(),this.isShaderMaterial=!0,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=hT,this.fragmentShader=pT,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Wa(e.uniforms),this.uniformsGroups=fT(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const r in this.uniforms){const o=this.uniforms[r].value;o&&o.isTexture?t.uniforms[r]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?t.uniforms[r]={type:"c",value:o.getHex()}:o&&o.isVector2?t.uniforms[r]={type:"v2",value:o.toArray()}:o&&o.isVector3?t.uniforms[r]={type:"v3",value:o.toArray()}:o&&o.isVector4?t.uniforms[r]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?t.uniforms[r]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?t.uniforms[r]={type:"m4",value:o.toArray()}:t.uniforms[r]={value:o}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const r in this.extensions)this.extensions[r]===!0&&(n[r]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}}class L_ extends Gn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new rn,this.projectionMatrix=new rn,this.projectionMatrixInverse=new rn,this.coordinateSystem=Mr}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const kr=new H,mm=new tt,gm=new tt;class pi extends L_{constructor(e=50,t=1,n=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=Bf*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(ec*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Bf*2*Math.atan(Math.tan(ec*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){kr.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(kr.x,kr.y).multiplyScalar(-e/kr.z),kr.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(kr.x,kr.y).multiplyScalar(-e/kr.z)}getViewSize(e,t){return this.getViewBounds(e,mm,gm),t.subVectors(gm,mm)}setViewOffset(e,t,n,r,s,o){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=s,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(ec*.5*this.fov)/this.zoom,n=2*t,r=this.aspect*n,s=-.5*r;const o=this.view;if(this.view!==null&&this.view.enabled){const l=o.fullWidth,u=o.fullHeight;s+=o.offsetX*r/l,t-=o.offsetY*n/u,r*=o.width/l,n*=o.height/u}const a=this.filmOffset;a!==0&&(s+=e*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+r,t,t-n,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const la=-90,ca=1;class mT extends Gn{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new pi(la,ca,e,t);r.layers=this.layers,this.add(r);const s=new pi(la,ca,e,t);s.layers=this.layers,this.add(s);const o=new pi(la,ca,e,t);o.layers=this.layers,this.add(o);const a=new pi(la,ca,e,t);a.layers=this.layers,this.add(a);const l=new pi(la,ca,e,t);l.layers=this.layers,this.add(l);const u=new pi(la,ca,e,t);u.layers=this.layers,this.add(u)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,r,s,o,a,l]=t;for(const u of t)this.remove(u);if(e===Mr)n.up.set(0,1,0),n.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===bc)n.up.set(0,-1,0),n.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const u of t)this.add(u),u.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[s,o,a,l,u,c]=this.children,d=e.getRenderTarget(),p=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),_=e.xr.enabled;e.xr.enabled=!1;const m=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,e.setRenderTarget(n,0,r),e.render(t,s),e.setRenderTarget(n,1,r),e.render(t,o),e.setRenderTarget(n,2,r),e.render(t,a),e.setRenderTarget(n,3,r),e.render(t,l),e.setRenderTarget(n,4,r),e.render(t,u),n.texture.generateMipmaps=m,e.setRenderTarget(n,5,r),e.render(t,c),e.setRenderTarget(d,p,f),e.xr.enabled=_,n.texture.needsPMREMUpdate=!0}}class P_ extends Vn{constructor(e,t,n,r,s,o,a,l,u,c){e=e!==void 0?e:[],t=t!==void 0?t:Ha,super(e,t,n,r,s,o,a,l,u,c),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class gT extends Bi{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},r=[n,n,n,n,n,n];this.texture=new P_(r,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0?t.generateMipmaps:!1,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:tr}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new ss(5,5,5),s=new Zn({name:"CubemapFromEquirect",uniforms:Wa(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Jn,blending:yr});s.uniforms.tEquirect.value=t;const o=new je(r,s),a=t.minFilter;return t.minFilter===Cs&&(t.minFilter=tr),new mT(1,10,this).update(e,o),t.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(e,t,n,r){const s=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(t,n,r);e.setRenderTarget(s)}}const Yu=new H,_T=new H,vT=new at;class vs{constructor(e=new H(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,r){return this.normal.set(e,t,n),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const r=Yu.subVectors(n,t).cross(_T.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const n=e.delta(Yu),r=this.normal.dot(n);if(r===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const s=-(e.start.dot(this.normal)+this.constant)/r;return s<0||s>1?null:t.copy(e.start).addScaledVector(n,s)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||vT.getNormalMatrix(e),r=this.coplanarPoint(Yu).applyMatrix4(e),s=this.normal.applyMatrix3(n).normalize();return this.constant=-r.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const ms=new rl,Rl=new H;class I_{constructor(e=new vs,t=new vs,n=new vs,r=new vs,s=new vs,o=new vs){this.planes=[e,t,n,r,s,o]}set(e,t,n,r,s,o){const a=this.planes;return a[0].copy(e),a[1].copy(t),a[2].copy(n),a[3].copy(r),a[4].copy(s),a[5].copy(o),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=Mr){const n=this.planes,r=e.elements,s=r[0],o=r[1],a=r[2],l=r[3],u=r[4],c=r[5],d=r[6],p=r[7],f=r[8],_=r[9],m=r[10],g=r[11],h=r[12],v=r[13],M=r[14],S=r[15];if(n[0].setComponents(l-s,p-u,g-f,S-h).normalize(),n[1].setComponents(l+s,p+u,g+f,S+h).normalize(),n[2].setComponents(l+o,p+c,g+_,S+v).normalize(),n[3].setComponents(l-o,p-c,g-_,S-v).normalize(),n[4].setComponents(l-a,p-d,g-m,S-M).normalize(),t===Mr)n[5].setComponents(l+a,p+d,g+m,S+M).normalize();else if(t===bc)n[5].setComponents(a,d,m,M).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),ms.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),ms.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(ms)}intersectsSprite(e){return ms.center.set(0,0,0),ms.radius=.7071067811865476,ms.applyMatrix4(e.matrixWorld),this.intersectsSphere(ms)}intersectsSphere(e){const t=this.planes,n=e.center,r=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(n)<r)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const r=t[n];if(Rl.x=r.normal.x>0?e.max.x:e.min.x,Rl.y=r.normal.y>0?e.max.y:e.min.y,Rl.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(Rl)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}function D_(){let i=null,e=!1,t=null,n=null;function r(s,o){t(s,o),n=i.requestAnimationFrame(r)}return{start:function(){e!==!0&&t!==null&&(n=i.requestAnimationFrame(r),e=!0)},stop:function(){i.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){i=s}}}function MT(i){const e=new WeakMap;function t(a,l){const u=a.array,c=a.usage,d=u.byteLength,p=i.createBuffer();i.bindBuffer(l,p),i.bufferData(l,u,c),a.onUploadCallback();let f;if(u instanceof Float32Array)f=i.FLOAT;else if(u instanceof Uint16Array)a.isFloat16BufferAttribute?f=i.HALF_FLOAT:f=i.UNSIGNED_SHORT;else if(u instanceof Int16Array)f=i.SHORT;else if(u instanceof Uint32Array)f=i.UNSIGNED_INT;else if(u instanceof Int32Array)f=i.INT;else if(u instanceof Int8Array)f=i.BYTE;else if(u instanceof Uint8Array)f=i.UNSIGNED_BYTE;else if(u instanceof Uint8ClampedArray)f=i.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+u);return{buffer:p,type:f,bytesPerElement:u.BYTES_PER_ELEMENT,version:a.version,size:d}}function n(a,l,u){const c=l.array,d=l.updateRanges;if(i.bindBuffer(u,a),d.length===0)i.bufferSubData(u,0,c);else{d.sort((f,_)=>f.start-_.start);let p=0;for(let f=1;f<d.length;f++){const _=d[p],m=d[f];m.start<=_.start+_.count+1?_.count=Math.max(_.count,m.start+m.count-_.start):(++p,d[p]=m)}d.length=p+1;for(let f=0,_=d.length;f<_;f++){const m=d[f];i.bufferSubData(u,m.start*c.BYTES_PER_ELEMENT,c,m.start,m.count)}l.clearUpdateRanges()}l.onUploadCallback()}function r(a){return a.isInterleavedBufferAttribute&&(a=a.data),e.get(a)}function s(a){a.isInterleavedBufferAttribute&&(a=a.data);const l=e.get(a);l&&(i.deleteBuffer(l.buffer),e.delete(a))}function o(a,l){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){const c=e.get(a);(!c||c.version<a.version)&&e.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}const u=e.get(a);if(u===void 0)e.set(a,t(a,l));else if(u.version<a.version){if(u.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(u.buffer,a,l),u.version=a.version}}return{get:r,remove:s,update:o}}class Hi extends sn{constructor(e=1,t=1,n=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:r};const s=e/2,o=t/2,a=Math.floor(n),l=Math.floor(r),u=a+1,c=l+1,d=e/a,p=t/l,f=[],_=[],m=[],g=[];for(let h=0;h<c;h++){const v=h*p-o;for(let M=0;M<u;M++){const S=M*d-s;_.push(S,-v,0),m.push(0,0,1),g.push(M/a),g.push(1-h/l)}}for(let h=0;h<l;h++)for(let v=0;v<a;v++){const M=v+u*h,S=v+u*(h+1),P=v+1+u*(h+1),E=v+1+u*h;f.push(M,S,E),f.push(S,P,E)}this.setIndex(f),this.setAttribute("position",new At(_,3)),this.setAttribute("normal",new At(m,3)),this.setAttribute("uv",new At(g,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Hi(e.width,e.height,e.widthSegments,e.heightSegments)}}var ST=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,xT=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,yT=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,TT=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,bT=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,ET=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,AT=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,wT=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,CT=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,RT=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,LT=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,PT=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,IT=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,DT=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,NT=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,UT=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,FT=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,BT=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,OT=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,kT=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,HT=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,VT=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,GT=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,zT=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,WT=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,KT=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,XT=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,qT=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,YT=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,$T=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,ZT="gl_FragColor = linearToOutputTexel( gl_FragColor );",jT=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,JT=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,QT=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,eb=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,tb=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,nb=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,ib=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,rb=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,sb=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,ab=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,ob=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,lb=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,cb=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,ub=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,db=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,fb=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,hb=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,pb=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,mb=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,gb=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,_b=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,vb=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Mb=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Sb=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,xb=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,yb=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,Tb=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,bb=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Eb=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,Ab=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,wb=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,Cb=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Rb=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Lb=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Pb=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Ib=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Db=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Nb=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Ub=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Fb=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Bb=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Ob=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,kb=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Hb=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Vb=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Gb=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,zb=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Wb=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,Kb=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,Xb=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,qb=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Yb=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,$b=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Zb=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,jb=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Jb=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Qb=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,eE=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,tE=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,nE=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,iE=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,rE=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,sE=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,aE=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,oE=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,lE=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,cE=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,uE=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,dE=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,fE=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,hE=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,pE=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,mE=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,gE=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,_E=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,vE=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const ME=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,SE=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,xE=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,yE=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,TE=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,bE=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,EE=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,AE=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,wE=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,CE=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,RE=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,LE=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,PE=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,IE=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,DE=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,NE=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,UE=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,FE=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,BE=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,OE=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,kE=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,HE=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,VE=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,GE=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,zE=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,WE=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,KE=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,XE=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,qE=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,YE=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,$E=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,ZE=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,jE=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,JE=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,ct={alphahash_fragment:ST,alphahash_pars_fragment:xT,alphamap_fragment:yT,alphamap_pars_fragment:TT,alphatest_fragment:bT,alphatest_pars_fragment:ET,aomap_fragment:AT,aomap_pars_fragment:wT,batching_pars_vertex:CT,batching_vertex:RT,begin_vertex:LT,beginnormal_vertex:PT,bsdfs:IT,iridescence_fragment:DT,bumpmap_pars_fragment:NT,clipping_planes_fragment:UT,clipping_planes_pars_fragment:FT,clipping_planes_pars_vertex:BT,clipping_planes_vertex:OT,color_fragment:kT,color_pars_fragment:HT,color_pars_vertex:VT,color_vertex:GT,common:zT,cube_uv_reflection_fragment:WT,defaultnormal_vertex:KT,displacementmap_pars_vertex:XT,displacementmap_vertex:qT,emissivemap_fragment:YT,emissivemap_pars_fragment:$T,colorspace_fragment:ZT,colorspace_pars_fragment:jT,envmap_fragment:JT,envmap_common_pars_fragment:QT,envmap_pars_fragment:eb,envmap_pars_vertex:tb,envmap_physical_pars_fragment:fb,envmap_vertex:nb,fog_vertex:ib,fog_pars_vertex:rb,fog_fragment:sb,fog_pars_fragment:ab,gradientmap_pars_fragment:ob,lightmap_pars_fragment:lb,lights_lambert_fragment:cb,lights_lambert_pars_fragment:ub,lights_pars_begin:db,lights_toon_fragment:hb,lights_toon_pars_fragment:pb,lights_phong_fragment:mb,lights_phong_pars_fragment:gb,lights_physical_fragment:_b,lights_physical_pars_fragment:vb,lights_fragment_begin:Mb,lights_fragment_maps:Sb,lights_fragment_end:xb,logdepthbuf_fragment:yb,logdepthbuf_pars_fragment:Tb,logdepthbuf_pars_vertex:bb,logdepthbuf_vertex:Eb,map_fragment:Ab,map_pars_fragment:wb,map_particle_fragment:Cb,map_particle_pars_fragment:Rb,metalnessmap_fragment:Lb,metalnessmap_pars_fragment:Pb,morphinstance_vertex:Ib,morphcolor_vertex:Db,morphnormal_vertex:Nb,morphtarget_pars_vertex:Ub,morphtarget_vertex:Fb,normal_fragment_begin:Bb,normal_fragment_maps:Ob,normal_pars_fragment:kb,normal_pars_vertex:Hb,normal_vertex:Vb,normalmap_pars_fragment:Gb,clearcoat_normal_fragment_begin:zb,clearcoat_normal_fragment_maps:Wb,clearcoat_pars_fragment:Kb,iridescence_pars_fragment:Xb,opaque_fragment:qb,packing:Yb,premultiplied_alpha_fragment:$b,project_vertex:Zb,dithering_fragment:jb,dithering_pars_fragment:Jb,roughnessmap_fragment:Qb,roughnessmap_pars_fragment:eE,shadowmap_pars_fragment:tE,shadowmap_pars_vertex:nE,shadowmap_vertex:iE,shadowmask_pars_fragment:rE,skinbase_vertex:sE,skinning_pars_vertex:aE,skinning_vertex:oE,skinnormal_vertex:lE,specularmap_fragment:cE,specularmap_pars_fragment:uE,tonemapping_fragment:dE,tonemapping_pars_fragment:fE,transmission_fragment:hE,transmission_pars_fragment:pE,uv_pars_fragment:mE,uv_pars_vertex:gE,uv_vertex:_E,worldpos_vertex:vE,background_vert:ME,background_frag:SE,backgroundCube_vert:xE,backgroundCube_frag:yE,cube_vert:TE,cube_frag:bE,depth_vert:EE,depth_frag:AE,distanceRGBA_vert:wE,distanceRGBA_frag:CE,equirect_vert:RE,equirect_frag:LE,linedashed_vert:PE,linedashed_frag:IE,meshbasic_vert:DE,meshbasic_frag:NE,meshlambert_vert:UE,meshlambert_frag:FE,meshmatcap_vert:BE,meshmatcap_frag:OE,meshnormal_vert:kE,meshnormal_frag:HE,meshphong_vert:VE,meshphong_frag:GE,meshphysical_vert:zE,meshphysical_frag:WE,meshtoon_vert:KE,meshtoon_frag:XE,points_vert:qE,points_frag:YE,shadow_vert:$E,shadow_frag:ZE,sprite_vert:jE,sprite_frag:JE},me={common:{diffuse:{value:new pt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new at},alphaMap:{value:null},alphaMapTransform:{value:new at},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new at}},envmap:{envMap:{value:null},envMapRotation:{value:new at},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new at}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new at}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new at},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new at},normalScale:{value:new tt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new at},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new at}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new at}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new at}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new pt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new pt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new at},alphaTest:{value:0},uvTransform:{value:new at}},sprite:{diffuse:{value:new pt(16777215)},opacity:{value:1},center:{value:new tt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new at},alphaMap:{value:null},alphaMapTransform:{value:new at},alphaTest:{value:0}}},Ji={basic:{uniforms:Fn([me.common,me.specularmap,me.envmap,me.aomap,me.lightmap,me.fog]),vertexShader:ct.meshbasic_vert,fragmentShader:ct.meshbasic_frag},lambert:{uniforms:Fn([me.common,me.specularmap,me.envmap,me.aomap,me.lightmap,me.emissivemap,me.bumpmap,me.normalmap,me.displacementmap,me.fog,me.lights,{emissive:{value:new pt(0)}}]),vertexShader:ct.meshlambert_vert,fragmentShader:ct.meshlambert_frag},phong:{uniforms:Fn([me.common,me.specularmap,me.envmap,me.aomap,me.lightmap,me.emissivemap,me.bumpmap,me.normalmap,me.displacementmap,me.fog,me.lights,{emissive:{value:new pt(0)},specular:{value:new pt(1118481)},shininess:{value:30}}]),vertexShader:ct.meshphong_vert,fragmentShader:ct.meshphong_frag},standard:{uniforms:Fn([me.common,me.envmap,me.aomap,me.lightmap,me.emissivemap,me.bumpmap,me.normalmap,me.displacementmap,me.roughnessmap,me.metalnessmap,me.fog,me.lights,{emissive:{value:new pt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:ct.meshphysical_vert,fragmentShader:ct.meshphysical_frag},toon:{uniforms:Fn([me.common,me.aomap,me.lightmap,me.emissivemap,me.bumpmap,me.normalmap,me.displacementmap,me.gradientmap,me.fog,me.lights,{emissive:{value:new pt(0)}}]),vertexShader:ct.meshtoon_vert,fragmentShader:ct.meshtoon_frag},matcap:{uniforms:Fn([me.common,me.bumpmap,me.normalmap,me.displacementmap,me.fog,{matcap:{value:null}}]),vertexShader:ct.meshmatcap_vert,fragmentShader:ct.meshmatcap_frag},points:{uniforms:Fn([me.points,me.fog]),vertexShader:ct.points_vert,fragmentShader:ct.points_frag},dashed:{uniforms:Fn([me.common,me.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:ct.linedashed_vert,fragmentShader:ct.linedashed_frag},depth:{uniforms:Fn([me.common,me.displacementmap]),vertexShader:ct.depth_vert,fragmentShader:ct.depth_frag},normal:{uniforms:Fn([me.common,me.bumpmap,me.normalmap,me.displacementmap,{opacity:{value:1}}]),vertexShader:ct.meshnormal_vert,fragmentShader:ct.meshnormal_frag},sprite:{uniforms:Fn([me.sprite,me.fog]),vertexShader:ct.sprite_vert,fragmentShader:ct.sprite_frag},background:{uniforms:{uvTransform:{value:new at},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:ct.background_vert,fragmentShader:ct.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new at}},vertexShader:ct.backgroundCube_vert,fragmentShader:ct.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:ct.cube_vert,fragmentShader:ct.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:ct.equirect_vert,fragmentShader:ct.equirect_frag},distanceRGBA:{uniforms:Fn([me.common,me.displacementmap,{referencePosition:{value:new H},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:ct.distanceRGBA_vert,fragmentShader:ct.distanceRGBA_frag},shadow:{uniforms:Fn([me.lights,me.fog,{color:{value:new pt(0)},opacity:{value:1}}]),vertexShader:ct.shadow_vert,fragmentShader:ct.shadow_frag}};Ji.physical={uniforms:Fn([Ji.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new at},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new at},clearcoatNormalScale:{value:new tt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new at},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new at},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new at},sheen:{value:0},sheenColor:{value:new pt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new at},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new at},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new at},transmissionSamplerSize:{value:new tt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new at},attenuationDistance:{value:0},attenuationColor:{value:new pt(0)},specularColor:{value:new pt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new at},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new at},anisotropyVector:{value:new tt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new at}}]),vertexShader:ct.meshphysical_vert,fragmentShader:ct.meshphysical_frag};const Ll={r:0,b:0,g:0},gs=new Lr,QE=new rn;function eA(i,e,t,n,r,s,o){const a=new pt(0);let l=s===!0?0:1,u,c,d=null,p=0,f=null;function _(v){let M=v.isScene===!0?v.background:null;return M&&M.isTexture&&(M=(v.backgroundBlurriness>0?t:e).get(M)),M}function m(v){let M=!1;const S=_(v);S===null?h(a,l):S&&S.isColor&&(h(S,1),M=!0);const P=i.xr.getEnvironmentBlendMode();P==="additive"?n.buffers.color.setClear(0,0,0,1,o):P==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(i.autoClear||M)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),i.clear(i.autoClearColor,i.autoClearDepth,i.autoClearStencil))}function g(v,M){const S=_(M);S&&(S.isCubeTexture||S.mapping===ru)?(c===void 0&&(c=new je(new ss(1,1,1),new Zn({name:"BackgroundCubeMaterial",uniforms:Wa(Ji.backgroundCube.uniforms),vertexShader:Ji.backgroundCube.vertexShader,fragmentShader:Ji.backgroundCube.fragmentShader,side:Jn,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(P,E,A){this.matrixWorld.copyPosition(A.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(c)),gs.copy(M.backgroundRotation),gs.x*=-1,gs.y*=-1,gs.z*=-1,S.isCubeTexture&&S.isRenderTargetTexture===!1&&(gs.y*=-1,gs.z*=-1),c.material.uniforms.envMap.value=S,c.material.uniforms.flipEnvMap.value=S.isCubeTexture&&S.isRenderTargetTexture===!1?-1:1,c.material.uniforms.backgroundBlurriness.value=M.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=M.backgroundIntensity,c.material.uniforms.backgroundRotation.value.setFromMatrix4(QE.makeRotationFromEuler(gs)),c.material.toneMapped=vt.getTransfer(S.colorSpace)!==Ut,(d!==S||p!==S.version||f!==i.toneMapping)&&(c.material.needsUpdate=!0,d=S,p=S.version,f=i.toneMapping),c.layers.enableAll(),v.unshift(c,c.geometry,c.material,0,0,null)):S&&S.isTexture&&(u===void 0&&(u=new je(new Hi(2,2),new Zn({name:"BackgroundMaterial",uniforms:Wa(Ji.background.uniforms),vertexShader:Ji.background.vertexShader,fragmentShader:Ji.background.fragmentShader,side:rs,depthTest:!1,depthWrite:!1,fog:!1})),u.geometry.deleteAttribute("normal"),Object.defineProperty(u.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(u)),u.material.uniforms.t2D.value=S,u.material.uniforms.backgroundIntensity.value=M.backgroundIntensity,u.material.toneMapped=vt.getTransfer(S.colorSpace)!==Ut,S.matrixAutoUpdate===!0&&S.updateMatrix(),u.material.uniforms.uvTransform.value.copy(S.matrix),(d!==S||p!==S.version||f!==i.toneMapping)&&(u.material.needsUpdate=!0,d=S,p=S.version,f=i.toneMapping),u.layers.enableAll(),v.unshift(u,u.geometry,u.material,0,0,null))}function h(v,M){v.getRGB(Ll,R_(i)),n.buffers.color.setClear(Ll.r,Ll.g,Ll.b,M,o)}return{getClearColor:function(){return a},setClearColor:function(v,M=1){a.set(v),l=M,h(a,l)},getClearAlpha:function(){return l},setClearAlpha:function(v){l=v,h(a,l)},render:m,addToRenderList:g}}function tA(i,e){const t=i.getParameter(i.MAX_VERTEX_ATTRIBS),n={},r=p(null);let s=r,o=!1;function a(x,C,N,D,I){let J=!1;const q=d(D,N,C);s!==q&&(s=q,u(s.object)),J=f(x,D,N,I),J&&_(x,D,N,I),I!==null&&e.update(I,i.ELEMENT_ARRAY_BUFFER),(J||o)&&(o=!1,S(x,C,N,D),I!==null&&i.bindBuffer(i.ELEMENT_ARRAY_BUFFER,e.get(I).buffer))}function l(){return i.createVertexArray()}function u(x){return i.bindVertexArray(x)}function c(x){return i.deleteVertexArray(x)}function d(x,C,N){const D=N.wireframe===!0;let I=n[x.id];I===void 0&&(I={},n[x.id]=I);let J=I[C.id];J===void 0&&(J={},I[C.id]=J);let q=J[D];return q===void 0&&(q=p(l()),J[D]=q),q}function p(x){const C=[],N=[],D=[];for(let I=0;I<t;I++)C[I]=0,N[I]=0,D[I]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:C,enabledAttributes:N,attributeDivisors:D,object:x,attributes:{},index:null}}function f(x,C,N,D){const I=s.attributes,J=C.attributes;let q=0;const oe=N.getAttributes();for(const X in oe)if(oe[X].location>=0){const pe=I[X];let Se=J[X];if(Se===void 0&&(X==="instanceMatrix"&&x.instanceMatrix&&(Se=x.instanceMatrix),X==="instanceColor"&&x.instanceColor&&(Se=x.instanceColor)),pe===void 0||pe.attribute!==Se||Se&&pe.data!==Se.data)return!0;q++}return s.attributesNum!==q||s.index!==D}function _(x,C,N,D){const I={},J=C.attributes;let q=0;const oe=N.getAttributes();for(const X in oe)if(oe[X].location>=0){let pe=J[X];pe===void 0&&(X==="instanceMatrix"&&x.instanceMatrix&&(pe=x.instanceMatrix),X==="instanceColor"&&x.instanceColor&&(pe=x.instanceColor));const Se={};Se.attribute=pe,pe&&pe.data&&(Se.data=pe.data),I[X]=Se,q++}s.attributes=I,s.attributesNum=q,s.index=D}function m(){const x=s.newAttributes;for(let C=0,N=x.length;C<N;C++)x[C]=0}function g(x){h(x,0)}function h(x,C){const N=s.newAttributes,D=s.enabledAttributes,I=s.attributeDivisors;N[x]=1,D[x]===0&&(i.enableVertexAttribArray(x),D[x]=1),I[x]!==C&&(i.vertexAttribDivisor(x,C),I[x]=C)}function v(){const x=s.newAttributes,C=s.enabledAttributes;for(let N=0,D=C.length;N<D;N++)C[N]!==x[N]&&(i.disableVertexAttribArray(N),C[N]=0)}function M(x,C,N,D,I,J,q){q===!0?i.vertexAttribIPointer(x,C,N,I,J):i.vertexAttribPointer(x,C,N,D,I,J)}function S(x,C,N,D){m();const I=D.attributes,J=N.getAttributes(),q=C.defaultAttributeValues;for(const oe in J){const X=J[oe];if(X.location>=0){let he=I[oe];if(he===void 0&&(oe==="instanceMatrix"&&x.instanceMatrix&&(he=x.instanceMatrix),oe==="instanceColor"&&x.instanceColor&&(he=x.instanceColor)),he!==void 0){const pe=he.normalized,Se=he.itemSize,Ne=e.get(he);if(Ne===void 0)continue;const nt=Ne.buffer,Z=Ne.type,le=Ne.bytesPerElement,Ce=Z===i.INT||Z===i.UNSIGNED_INT||he.gpuType===Ch;if(he.isInterleavedBufferAttribute){const ue=he.data,Pe=ue.stride,ze=he.offset;if(ue.isInstancedInterleavedBuffer){for(let Ze=0;Ze<X.locationSize;Ze++)h(X.location+Ze,ue.meshPerAttribute);x.isInstancedMesh!==!0&&D._maxInstanceCount===void 0&&(D._maxInstanceCount=ue.meshPerAttribute*ue.count)}else for(let Ze=0;Ze<X.locationSize;Ze++)g(X.location+Ze);i.bindBuffer(i.ARRAY_BUFFER,nt);for(let Ze=0;Ze<X.locationSize;Ze++)M(X.location+Ze,Se/X.locationSize,Z,pe,Pe*le,(ze+Se/X.locationSize*Ze)*le,Ce)}else{if(he.isInstancedBufferAttribute){for(let ue=0;ue<X.locationSize;ue++)h(X.location+ue,he.meshPerAttribute);x.isInstancedMesh!==!0&&D._maxInstanceCount===void 0&&(D._maxInstanceCount=he.meshPerAttribute*he.count)}else for(let ue=0;ue<X.locationSize;ue++)g(X.location+ue);i.bindBuffer(i.ARRAY_BUFFER,nt);for(let ue=0;ue<X.locationSize;ue++)M(X.location+ue,Se/X.locationSize,Z,pe,Se*le,Se/X.locationSize*ue*le,Ce)}}else if(q!==void 0){const pe=q[oe];if(pe!==void 0)switch(pe.length){case 2:i.vertexAttrib2fv(X.location,pe);break;case 3:i.vertexAttrib3fv(X.location,pe);break;case 4:i.vertexAttrib4fv(X.location,pe);break;default:i.vertexAttrib1fv(X.location,pe)}}}}v()}function P(){L();for(const x in n){const C=n[x];for(const N in C){const D=C[N];for(const I in D)c(D[I].object),delete D[I];delete C[N]}delete n[x]}}function E(x){if(n[x.id]===void 0)return;const C=n[x.id];for(const N in C){const D=C[N];for(const I in D)c(D[I].object),delete D[I];delete C[N]}delete n[x.id]}function A(x){for(const C in n){const N=n[C];if(N[x.id]===void 0)continue;const D=N[x.id];for(const I in D)c(D[I].object),delete D[I];delete N[x.id]}}function L(){y(),o=!0,s!==r&&(s=r,u(s.object))}function y(){r.geometry=null,r.program=null,r.wireframe=!1}return{setup:a,reset:L,resetDefaultState:y,dispose:P,releaseStatesOfGeometry:E,releaseStatesOfProgram:A,initAttributes:m,enableAttribute:g,disableUnusedAttributes:v}}function nA(i,e,t){let n;function r(u){n=u}function s(u,c){i.drawArrays(n,u,c),t.update(c,n,1)}function o(u,c,d){d!==0&&(i.drawArraysInstanced(n,u,c,d),t.update(c,n,d))}function a(u,c,d){if(d===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,u,0,c,0,d);let f=0;for(let _=0;_<d;_++)f+=c[_];t.update(f,n,1)}function l(u,c,d,p){if(d===0)return;const f=e.get("WEBGL_multi_draw");if(f===null)for(let _=0;_<u.length;_++)o(u[_],c[_],p[_]);else{f.multiDrawArraysInstancedWEBGL(n,u,0,c,0,p,0,d);let _=0;for(let m=0;m<d;m++)_+=c[m]*p[m];t.update(_,n,1)}}this.setMode=r,this.render=s,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=l}function iA(i,e,t,n){let r;function s(){if(r!==void 0)return r;if(e.has("EXT_texture_filter_anisotropic")===!0){const A=e.get("EXT_texture_filter_anisotropic");r=i.getParameter(A.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else r=0;return r}function o(A){return!(A!==Ii&&n.convert(A)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(A){const L=A===Tr&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(A!==Rr&&n.convert(A)!==i.getParameter(i.IMPLEMENTATION_COLOR_READ_TYPE)&&A!==vr&&!L)}function l(A){if(A==="highp"){if(i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.HIGH_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.HIGH_FLOAT).precision>0)return"highp";A="mediump"}return A==="mediump"&&i.getShaderPrecisionFormat(i.VERTEX_SHADER,i.MEDIUM_FLOAT).precision>0&&i.getShaderPrecisionFormat(i.FRAGMENT_SHADER,i.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let u=t.precision!==void 0?t.precision:"highp";const c=l(u);c!==u&&(console.warn("THREE.WebGLRenderer:",u,"not supported, using",c,"instead."),u=c);const d=t.logarithmicDepthBuffer===!0,p=t.reverseDepthBuffer===!0&&e.has("EXT_clip_control"),f=i.getParameter(i.MAX_TEXTURE_IMAGE_UNITS),_=i.getParameter(i.MAX_VERTEX_TEXTURE_IMAGE_UNITS),m=i.getParameter(i.MAX_TEXTURE_SIZE),g=i.getParameter(i.MAX_CUBE_MAP_TEXTURE_SIZE),h=i.getParameter(i.MAX_VERTEX_ATTRIBS),v=i.getParameter(i.MAX_VERTEX_UNIFORM_VECTORS),M=i.getParameter(i.MAX_VARYING_VECTORS),S=i.getParameter(i.MAX_FRAGMENT_UNIFORM_VECTORS),P=_>0,E=i.getParameter(i.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:s,getMaxPrecision:l,textureFormatReadable:o,textureTypeReadable:a,precision:u,logarithmicDepthBuffer:d,reverseDepthBuffer:p,maxTextures:f,maxVertexTextures:_,maxTextureSize:m,maxCubemapSize:g,maxAttributes:h,maxVertexUniforms:v,maxVaryings:M,maxFragmentUniforms:S,vertexTextures:P,maxSamples:E}}function rA(i){const e=this;let t=null,n=0,r=!1,s=!1;const o=new vs,a=new at,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(d,p){const f=d.length!==0||p||n!==0||r;return r=p,n=d.length,f},this.beginShadows=function(){s=!0,c(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(d,p){t=c(d,p,0)},this.setState=function(d,p,f){const _=d.clippingPlanes,m=d.clipIntersection,g=d.clipShadows,h=i.get(d);if(!r||_===null||_.length===0||s&&!g)s?c(null):u();else{const v=s?0:n,M=v*4;let S=h.clippingState||null;l.value=S,S=c(_,p,M,f);for(let P=0;P!==M;++P)S[P]=t[P];h.clippingState=S,this.numIntersection=m?this.numPlanes:0,this.numPlanes+=v}};function u(){l.value!==t&&(l.value=t,l.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function c(d,p,f,_){const m=d!==null?d.length:0;let g=null;if(m!==0){if(g=l.value,_!==!0||g===null){const h=f+m*4,v=p.matrixWorldInverse;a.getNormalMatrix(v),(g===null||g.length<h)&&(g=new Float32Array(h));for(let M=0,S=f;M!==m;++M,S+=4)o.copy(d[M]).applyMatrix4(v,a),o.normal.toArray(g,S),g[S+3]=o.constant}l.value=g,l.needsUpdate=!0}return e.numPlanes=m,e.numIntersection=0,g}}function sA(i){let e=new WeakMap;function t(o,a){return a===of?o.mapping=Ha:a===lf&&(o.mapping=Va),o}function n(o){if(o&&o.isTexture){const a=o.mapping;if(a===of||a===lf)if(e.has(o)){const l=e.get(o).texture;return t(l,o.mapping)}else{const l=o.image;if(l&&l.height>0){const u=new gT(l.height);return u.fromEquirectangularTexture(i,o),e.set(o,u),o.addEventListener("dispose",r),t(u.texture,o.mapping)}else return null}}return o}function r(o){const a=o.target;a.removeEventListener("dispose",r);const l=e.get(a);l!==void 0&&(e.delete(a),l.dispose())}function s(){e=new WeakMap}return{get:n,dispose:s}}class N_ extends L_{constructor(e=-1,t=1,n=1,r=-1,s=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=r,this.near=s,this.far=o,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,r,s,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=s,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let s=n-e,o=n+e,a=r+t,l=r-t;if(this.view!==null&&this.view.enabled){const u=(this.right-this.left)/this.view.fullWidth/this.zoom,c=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=u*this.view.offsetX,o=s+u*this.view.width,a-=c*this.view.offsetY,l=a-c*this.view.height}this.projectionMatrix.makeOrthographic(s,o,a,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}const _a=4,_m=[.125,.215,.35,.446,.526,.582],ys=20,$u=new N_,vm=new pt;let Zu=null,ju=0,Ju=0,Qu=!1;const Ms=(1+Math.sqrt(5))/2,ua=1/Ms,Mm=[new H(-Ms,ua,0),new H(Ms,ua,0),new H(-ua,0,Ms),new H(ua,0,Ms),new H(0,Ms,-ua),new H(0,Ms,ua),new H(-1,1,-1),new H(1,1,-1),new H(-1,1,1),new H(1,1,1)];class Sm{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,n=.1,r=100){Zu=this._renderer.getRenderTarget(),ju=this._renderer.getActiveCubeFace(),Ju=this._renderer.getActiveMipmapLevel(),Qu=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(256);const s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(e,n,r,s),t>0&&this._blur(s,0,0,t),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Tm(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=ym(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(Zu,ju,Ju),this._renderer.xr.enabled=Qu,e.scissorTest=!1,Pl(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Ha||e.mapping===Va?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),Zu=this._renderer.getRenderTarget(),ju=this._renderer.getActiveCubeFace(),Ju=this._renderer.getActiveMipmapLevel(),Qu=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:tr,minFilter:tr,generateMipmaps:!1,type:Tr,format:Ii,colorSpace:Qa,depthBuffer:!1},r=xm(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=xm(e,t,n);const{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=aA(s)),this._blurMaterial=oA(s,e,t)}return r}_compileMaterial(e){const t=new je(this._lodPlanes[0],e);this._renderer.compile(t,$u)}_sceneToCubeUV(e,t,n,r){const a=new pi(90,1,t,n),l=[1,-1,1,1,1,1],u=[1,1,1,-1,-1,-1],c=this._renderer,d=c.autoClear,p=c.toneMapping;c.getClearColor(vm),c.toneMapping=jr,c.autoClear=!1;const f=new xi({name:"PMREM.Background",side:Jn,depthWrite:!1,depthTest:!1}),_=new je(new ss,f);let m=!1;const g=e.background;g?g.isColor&&(f.color.copy(g),e.background=null,m=!0):(f.color.copy(vm),m=!0);for(let h=0;h<6;h++){const v=h%3;v===0?(a.up.set(0,l[h],0),a.lookAt(u[h],0,0)):v===1?(a.up.set(0,0,l[h]),a.lookAt(0,u[h],0)):(a.up.set(0,l[h],0),a.lookAt(0,0,u[h]));const M=this._cubeSize;Pl(r,v*M,h>2?M:0,M,M),c.setRenderTarget(r),m&&c.render(_,a),c.render(e,a)}_.geometry.dispose(),_.material.dispose(),c.toneMapping=p,c.autoClear=d,e.background=g}_textureToCubeUV(e,t){const n=this._renderer,r=e.mapping===Ha||e.mapping===Va;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=Tm()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=ym());const s=r?this._cubemapMaterial:this._equirectMaterial,o=new je(this._lodPlanes[0],s),a=s.uniforms;a.envMap.value=e;const l=this._cubeSize;Pl(t,0,0,3*l,2*l),n.setRenderTarget(t),n.render(o,$u)}_applyPMREM(e){const t=this._renderer,n=t.autoClear;t.autoClear=!1;const r=this._lodPlanes.length;for(let s=1;s<r;s++){const o=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),a=Mm[(r-s-1)%Mm.length];this._blur(e,s-1,s,o,a)}t.autoClear=n}_blur(e,t,n,r,s){const o=this._pingPongRenderTarget;this._halfBlur(e,o,t,n,r,"latitudinal",s),this._halfBlur(o,e,n,n,r,"longitudinal",s)}_halfBlur(e,t,n,r,s,o,a){const l=this._renderer,u=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const c=3,d=new je(this._lodPlanes[r],u),p=u.uniforms,f=this._sizeLods[n]-1,_=isFinite(s)?Math.PI/(2*f):2*Math.PI/(2*ys-1),m=s/_,g=isFinite(s)?1+Math.floor(c*m):ys;g>ys&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${g} samples when the maximum is set to ${ys}`);const h=[];let v=0;for(let A=0;A<ys;++A){const L=A/m,y=Math.exp(-L*L/2);h.push(y),A===0?v+=y:A<g&&(v+=2*y)}for(let A=0;A<h.length;A++)h[A]=h[A]/v;p.envMap.value=e.texture,p.samples.value=g,p.weights.value=h,p.latitudinal.value=o==="latitudinal",a&&(p.poleAxis.value=a);const{_lodMax:M}=this;p.dTheta.value=_,p.mipInt.value=M-n;const S=this._sizeLods[r],P=3*S*(r>M-_a?r-M+_a:0),E=4*(this._cubeSize-S);Pl(t,P,E,3*S,2*S),l.setRenderTarget(t),l.render(d,$u)}}function aA(i){const e=[],t=[],n=[];let r=i;const s=i-_a+1+_m.length;for(let o=0;o<s;o++){const a=Math.pow(2,r);t.push(a);let l=1/a;o>i-_a?l=_m[o-i+_a-1]:o===0&&(l=0),n.push(l);const u=1/(a-2),c=-u,d=1+u,p=[c,c,d,c,d,d,c,c,d,d,c,d],f=6,_=6,m=3,g=2,h=1,v=new Float32Array(m*_*f),M=new Float32Array(g*_*f),S=new Float32Array(h*_*f);for(let E=0;E<f;E++){const A=E%3*2/3-1,L=E>2?0:-1,y=[A,L,0,A+2/3,L,0,A+2/3,L+1,0,A,L,0,A+2/3,L+1,0,A,L+1,0];v.set(y,m*_*E),M.set(p,g*_*E);const x=[E,E,E,E,E,E];S.set(x,h*_*E)}const P=new sn;P.setAttribute("position",new ir(v,m)),P.setAttribute("uv",new ir(M,g)),P.setAttribute("faceIndex",new ir(S,h)),e.push(P),r>_a&&r--}return{lodPlanes:e,sizeLods:t,sigmas:n}}function xm(i,e,t){const n=new Bi(i,e,t);return n.texture.mapping=ru,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Pl(i,e,t,n,r){i.viewport.set(e,t,n,r),i.scissor.set(e,t,n,r)}function oA(i,e,t){const n=new Float32Array(ys),r=new H(0,1,0);return new Zn({name:"SphericalGaussianBlur",defines:{n:ys,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${i}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:r}},vertexShader:Uh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:yr,depthTest:!1,depthWrite:!1})}function ym(){return new Zn({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Uh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:yr,depthTest:!1,depthWrite:!1})}function Tm(){return new Zn({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Uh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:yr,depthTest:!1,depthWrite:!1})}function Uh(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function lA(i){let e=new WeakMap,t=null;function n(a){if(a&&a.isTexture){const l=a.mapping,u=l===of||l===lf,c=l===Ha||l===Va;if(u||c){let d=e.get(a);const p=d!==void 0?d.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==p)return t===null&&(t=new Sm(i)),d=u?t.fromEquirectangular(a,d):t.fromCubemap(a,d),d.texture.pmremVersion=a.pmremVersion,e.set(a,d),d.texture;if(d!==void 0)return d.texture;{const f=a.image;return u&&f&&f.height>0||c&&f&&r(f)?(t===null&&(t=new Sm(i)),d=u?t.fromEquirectangular(a):t.fromCubemap(a),d.texture.pmremVersion=a.pmremVersion,e.set(a,d),a.addEventListener("dispose",s),d.texture):null}}}return a}function r(a){let l=0;const u=6;for(let c=0;c<u;c++)a[c]!==void 0&&l++;return l===u}function s(a){const l=a.target;l.removeEventListener("dispose",s);const u=e.get(l);u!==void 0&&(e.delete(l),u.dispose())}function o(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:n,dispose:o}}function cA(i){const e={};function t(n){if(e[n]!==void 0)return e[n];let r;switch(n){case"WEBGL_depth_texture":r=i.getExtension("WEBGL_depth_texture")||i.getExtension("MOZ_WEBGL_depth_texture")||i.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":r=i.getExtension("EXT_texture_filter_anisotropic")||i.getExtension("MOZ_EXT_texture_filter_anisotropic")||i.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":r=i.getExtension("WEBGL_compressed_texture_s3tc")||i.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":r=i.getExtension("WEBGL_compressed_texture_pvrtc")||i.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:r=i.getExtension(n)}return e[n]=r,r}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const r=t(n);return r===null&&So("THREE.WebGLRenderer: "+n+" extension not supported."),r}}}function uA(i,e,t,n){const r={},s=new WeakMap;function o(d){const p=d.target;p.index!==null&&e.remove(p.index);for(const _ in p.attributes)e.remove(p.attributes[_]);for(const _ in p.morphAttributes){const m=p.morphAttributes[_];for(let g=0,h=m.length;g<h;g++)e.remove(m[g])}p.removeEventListener("dispose",o),delete r[p.id];const f=s.get(p);f&&(e.remove(f),s.delete(p)),n.releaseStatesOfGeometry(p),p.isInstancedBufferGeometry===!0&&delete p._maxInstanceCount,t.memory.geometries--}function a(d,p){return r[p.id]===!0||(p.addEventListener("dispose",o),r[p.id]=!0,t.memory.geometries++),p}function l(d){const p=d.attributes;for(const _ in p)e.update(p[_],i.ARRAY_BUFFER);const f=d.morphAttributes;for(const _ in f){const m=f[_];for(let g=0,h=m.length;g<h;g++)e.update(m[g],i.ARRAY_BUFFER)}}function u(d){const p=[],f=d.index,_=d.attributes.position;let m=0;if(f!==null){const v=f.array;m=f.version;for(let M=0,S=v.length;M<S;M+=3){const P=v[M+0],E=v[M+1],A=v[M+2];p.push(P,E,E,A,A,P)}}else if(_!==void 0){const v=_.array;m=_.version;for(let M=0,S=v.length/3-1;M<S;M+=3){const P=M+0,E=M+1,A=M+2;p.push(P,E,E,A,A,P)}}else return;const g=new(y_(p)?C_:w_)(p,1);g.version=m;const h=s.get(d);h&&e.remove(h),s.set(d,g)}function c(d){const p=s.get(d);if(p){const f=d.index;f!==null&&p.version<f.version&&u(d)}else u(d);return s.get(d)}return{get:a,update:l,getWireframeAttribute:c}}function dA(i,e,t){let n;function r(p){n=p}let s,o;function a(p){s=p.type,o=p.bytesPerElement}function l(p,f){i.drawElements(n,f,s,p*o),t.update(f,n,1)}function u(p,f,_){_!==0&&(i.drawElementsInstanced(n,f,s,p*o,_),t.update(f,n,_))}function c(p,f,_){if(_===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,f,0,s,p,0,_);let g=0;for(let h=0;h<_;h++)g+=f[h];t.update(g,n,1)}function d(p,f,_,m){if(_===0)return;const g=e.get("WEBGL_multi_draw");if(g===null)for(let h=0;h<p.length;h++)u(p[h]/o,f[h],m[h]);else{g.multiDrawElementsInstancedWEBGL(n,f,0,s,p,0,m,0,_);let h=0;for(let v=0;v<_;v++)h+=f[v]*m[v];t.update(h,n,1)}}this.setMode=r,this.setIndex=a,this.render=l,this.renderInstances=u,this.renderMultiDraw=c,this.renderMultiDrawInstances=d}function fA(i){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(s,o,a){switch(t.calls++,o){case i.TRIANGLES:t.triangles+=a*(s/3);break;case i.LINES:t.lines+=a*(s/2);break;case i.LINE_STRIP:t.lines+=a*(s-1);break;case i.LINE_LOOP:t.lines+=a*s;break;case i.POINTS:t.points+=a*s;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function r(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:r,update:n}}function hA(i,e,t){const n=new WeakMap,r=new un;function s(o,a,l){const u=o.morphTargetInfluences,c=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,d=c!==void 0?c.length:0;let p=n.get(a);if(p===void 0||p.count!==d){let y=function(){A.dispose(),n.delete(a),a.removeEventListener("dispose",y)};p!==void 0&&p.texture.dispose();const f=a.morphAttributes.position!==void 0,_=a.morphAttributes.normal!==void 0,m=a.morphAttributes.color!==void 0,g=a.morphAttributes.position||[],h=a.morphAttributes.normal||[],v=a.morphAttributes.color||[];let M=0;f===!0&&(M=1),_===!0&&(M=2),m===!0&&(M=3);let S=a.attributes.position.count*M,P=1;S>e.maxTextureSize&&(P=Math.ceil(S/e.maxTextureSize),S=e.maxTextureSize);const E=new Float32Array(S*P*4*d),A=new b_(E,S,P,d);A.type=vr,A.needsUpdate=!0;const L=M*4;for(let x=0;x<d;x++){const C=g[x],N=h[x],D=v[x],I=S*P*4*x;for(let J=0;J<C.count;J++){const q=J*L;f===!0&&(r.fromBufferAttribute(C,J),E[I+q+0]=r.x,E[I+q+1]=r.y,E[I+q+2]=r.z,E[I+q+3]=0),_===!0&&(r.fromBufferAttribute(N,J),E[I+q+4]=r.x,E[I+q+5]=r.y,E[I+q+6]=r.z,E[I+q+7]=0),m===!0&&(r.fromBufferAttribute(D,J),E[I+q+8]=r.x,E[I+q+9]=r.y,E[I+q+10]=r.z,E[I+q+11]=D.itemSize===4?r.w:1)}}p={count:d,texture:A,size:new tt(S,P)},n.set(a,p),a.addEventListener("dispose",y)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)l.getUniforms().setValue(i,"morphTexture",o.morphTexture,t);else{let f=0;for(let m=0;m<u.length;m++)f+=u[m];const _=a.morphTargetsRelative?1:1-f;l.getUniforms().setValue(i,"morphTargetBaseInfluence",_),l.getUniforms().setValue(i,"morphTargetInfluences",u)}l.getUniforms().setValue(i,"morphTargetsTexture",p.texture,t),l.getUniforms().setValue(i,"morphTargetsTextureSize",p.size)}return{update:s}}function pA(i,e,t,n){let r=new WeakMap;function s(l){const u=n.render.frame,c=l.geometry,d=e.get(l,c);if(r.get(d)!==u&&(e.update(d),r.set(d,u)),l.isInstancedMesh&&(l.hasEventListener("dispose",a)===!1&&l.addEventListener("dispose",a),r.get(l)!==u&&(t.update(l.instanceMatrix,i.ARRAY_BUFFER),l.instanceColor!==null&&t.update(l.instanceColor,i.ARRAY_BUFFER),r.set(l,u))),l.isSkinnedMesh){const p=l.skeleton;r.get(p)!==u&&(p.update(),r.set(p,u))}return d}function o(){r=new WeakMap}function a(l){const u=l.target;u.removeEventListener("dispose",a),t.remove(u.instanceMatrix),u.instanceColor!==null&&t.remove(u.instanceColor)}return{update:s,dispose:o}}class U_ extends Vn{constructor(e,t,n,r,s,o,a,l,u,c=Aa){if(c!==Aa&&c!==za)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&c===Aa&&(n=Vs),n===void 0&&c===za&&(n=Ga),super(null,r,s,o,a,l,c,n,u),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=a!==void 0?a:Fi,this.minFilter=l!==void 0?l:Fi,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}const F_=new Vn,bm=new U_(1,1),B_=new b_,O_=new tT,k_=new P_,Em=[],Am=[],wm=new Float32Array(16),Cm=new Float32Array(9),Rm=new Float32Array(4);function no(i,e,t){const n=i[0];if(n<=0||n>0)return i;const r=e*t;let s=Em[r];if(s===void 0&&(s=new Float32Array(r),Em[r]=s),e!==0){n.toArray(s,0);for(let o=1,a=0;o!==e;++o)a+=t,i[o].toArray(s,a)}return s}function _n(i,e){if(i.length!==e.length)return!1;for(let t=0,n=i.length;t<n;t++)if(i[t]!==e[t])return!1;return!0}function vn(i,e){for(let t=0,n=e.length;t<n;t++)i[t]=e[t]}function au(i,e){let t=Am[e];t===void 0&&(t=new Int32Array(e),Am[e]=t);for(let n=0;n!==e;++n)t[n]=i.allocateTextureUnit();return t}function mA(i,e){const t=this.cache;t[0]!==e&&(i.uniform1f(this.addr,e),t[0]=e)}function gA(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(_n(t,e))return;i.uniform2fv(this.addr,e),vn(t,e)}}function _A(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(i.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(_n(t,e))return;i.uniform3fv(this.addr,e),vn(t,e)}}function vA(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(_n(t,e))return;i.uniform4fv(this.addr,e),vn(t,e)}}function MA(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(_n(t,e))return;i.uniformMatrix2fv(this.addr,!1,e),vn(t,e)}else{if(_n(t,n))return;Rm.set(n),i.uniformMatrix2fv(this.addr,!1,Rm),vn(t,n)}}function SA(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(_n(t,e))return;i.uniformMatrix3fv(this.addr,!1,e),vn(t,e)}else{if(_n(t,n))return;Cm.set(n),i.uniformMatrix3fv(this.addr,!1,Cm),vn(t,n)}}function xA(i,e){const t=this.cache,n=e.elements;if(n===void 0){if(_n(t,e))return;i.uniformMatrix4fv(this.addr,!1,e),vn(t,e)}else{if(_n(t,n))return;wm.set(n),i.uniformMatrix4fv(this.addr,!1,wm),vn(t,n)}}function yA(i,e){const t=this.cache;t[0]!==e&&(i.uniform1i(this.addr,e),t[0]=e)}function TA(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(_n(t,e))return;i.uniform2iv(this.addr,e),vn(t,e)}}function bA(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(_n(t,e))return;i.uniform3iv(this.addr,e),vn(t,e)}}function EA(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(_n(t,e))return;i.uniform4iv(this.addr,e),vn(t,e)}}function AA(i,e){const t=this.cache;t[0]!==e&&(i.uniform1ui(this.addr,e),t[0]=e)}function wA(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(i.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(_n(t,e))return;i.uniform2uiv(this.addr,e),vn(t,e)}}function CA(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(i.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(_n(t,e))return;i.uniform3uiv(this.addr,e),vn(t,e)}}function RA(i,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(i.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(_n(t,e))return;i.uniform4uiv(this.addr,e),vn(t,e)}}function LA(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r);let s;this.type===i.SAMPLER_2D_SHADOW?(bm.compareFunction=x_,s=bm):s=F_,t.setTexture2D(e||s,r)}function PA(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTexture3D(e||O_,r)}function IA(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTextureCube(e||k_,r)}function DA(i,e,t){const n=this.cache,r=t.allocateTextureUnit();n[0]!==r&&(i.uniform1i(this.addr,r),n[0]=r),t.setTexture2DArray(e||B_,r)}function NA(i){switch(i){case 5126:return mA;case 35664:return gA;case 35665:return _A;case 35666:return vA;case 35674:return MA;case 35675:return SA;case 35676:return xA;case 5124:case 35670:return yA;case 35667:case 35671:return TA;case 35668:case 35672:return bA;case 35669:case 35673:return EA;case 5125:return AA;case 36294:return wA;case 36295:return CA;case 36296:return RA;case 35678:case 36198:case 36298:case 36306:case 35682:return LA;case 35679:case 36299:case 36307:return PA;case 35680:case 36300:case 36308:case 36293:return IA;case 36289:case 36303:case 36311:case 36292:return DA}}function UA(i,e){i.uniform1fv(this.addr,e)}function FA(i,e){const t=no(e,this.size,2);i.uniform2fv(this.addr,t)}function BA(i,e){const t=no(e,this.size,3);i.uniform3fv(this.addr,t)}function OA(i,e){const t=no(e,this.size,4);i.uniform4fv(this.addr,t)}function kA(i,e){const t=no(e,this.size,4);i.uniformMatrix2fv(this.addr,!1,t)}function HA(i,e){const t=no(e,this.size,9);i.uniformMatrix3fv(this.addr,!1,t)}function VA(i,e){const t=no(e,this.size,16);i.uniformMatrix4fv(this.addr,!1,t)}function GA(i,e){i.uniform1iv(this.addr,e)}function zA(i,e){i.uniform2iv(this.addr,e)}function WA(i,e){i.uniform3iv(this.addr,e)}function KA(i,e){i.uniform4iv(this.addr,e)}function XA(i,e){i.uniform1uiv(this.addr,e)}function qA(i,e){i.uniform2uiv(this.addr,e)}function YA(i,e){i.uniform3uiv(this.addr,e)}function $A(i,e){i.uniform4uiv(this.addr,e)}function ZA(i,e,t){const n=this.cache,r=e.length,s=au(t,r);_n(n,s)||(i.uniform1iv(this.addr,s),vn(n,s));for(let o=0;o!==r;++o)t.setTexture2D(e[o]||F_,s[o])}function jA(i,e,t){const n=this.cache,r=e.length,s=au(t,r);_n(n,s)||(i.uniform1iv(this.addr,s),vn(n,s));for(let o=0;o!==r;++o)t.setTexture3D(e[o]||O_,s[o])}function JA(i,e,t){const n=this.cache,r=e.length,s=au(t,r);_n(n,s)||(i.uniform1iv(this.addr,s),vn(n,s));for(let o=0;o!==r;++o)t.setTextureCube(e[o]||k_,s[o])}function QA(i,e,t){const n=this.cache,r=e.length,s=au(t,r);_n(n,s)||(i.uniform1iv(this.addr,s),vn(n,s));for(let o=0;o!==r;++o)t.setTexture2DArray(e[o]||B_,s[o])}function ew(i){switch(i){case 5126:return UA;case 35664:return FA;case 35665:return BA;case 35666:return OA;case 35674:return kA;case 35675:return HA;case 35676:return VA;case 5124:case 35670:return GA;case 35667:case 35671:return zA;case 35668:case 35672:return WA;case 35669:case 35673:return KA;case 5125:return XA;case 36294:return qA;case 36295:return YA;case 36296:return $A;case 35678:case 36198:case 36298:case 36306:case 35682:return ZA;case 35679:case 36299:case 36307:return jA;case 35680:case 36300:case 36308:case 36293:return JA;case 36289:case 36303:case 36311:case 36292:return QA}}class tw{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=NA(t.type)}}class nw{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=ew(t.type)}}class iw{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const r=this.seq;for(let s=0,o=r.length;s!==o;++s){const a=r[s];a.setValue(e,t[a.id],n)}}}const ed=/(\w+)(\])?(\[|\.)?/g;function Lm(i,e){i.seq.push(e),i.map[e.id]=e}function rw(i,e,t){const n=i.name,r=n.length;for(ed.lastIndex=0;;){const s=ed.exec(n),o=ed.lastIndex;let a=s[1];const l=s[2]==="]",u=s[3];if(l&&(a=a|0),u===void 0||u==="["&&o+2===r){Lm(t,u===void 0?new tw(a,i,e):new nw(a,i,e));break}else{let d=t.map[a];d===void 0&&(d=new iw(a),Lm(t,d)),t=d}}}class tc{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<n;++r){const s=e.getActiveUniform(t,r),o=e.getUniformLocation(t,s.name);rw(s,o,this)}}setValue(e,t,n,r){const s=this.map[t];s!==void 0&&s.setValue(e,n,r)}setOptional(e,t,n){const r=t[n];r!==void 0&&this.setValue(e,n,r)}static upload(e,t,n,r){for(let s=0,o=t.length;s!==o;++s){const a=t[s],l=n[a.id];l.needsUpdate!==!1&&a.setValue(e,l.value,r)}}static seqWithValue(e,t){const n=[];for(let r=0,s=e.length;r!==s;++r){const o=e[r];o.id in t&&n.push(o)}return n}}function Pm(i,e,t){const n=i.createShader(e);return i.shaderSource(n,t),i.compileShader(n),n}const sw=37297;let aw=0;function ow(i,e){const t=i.split(`
`),n=[],r=Math.max(e-6,0),s=Math.min(e+6,t.length);for(let o=r;o<s;o++){const a=o+1;n.push(`${a===e?">":" "} ${a}: ${t[o]}`)}return n.join(`
`)}const Im=new at;function lw(i){vt._getMatrix(Im,vt.workingColorSpace,i);const e=`mat3( ${Im.elements.map(t=>t.toFixed(4))} )`;switch(vt.getTransfer(i)){case su:return[e,"LinearTransferOETF"];case Ut:return[e,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",i),[e,"LinearTransferOETF"]}}function Dm(i,e,t){const n=i.getShaderParameter(e,i.COMPILE_STATUS),r=i.getShaderInfoLog(e).trim();if(n&&r==="")return"";const s=/ERROR: 0:(\d+)/.exec(r);if(s){const o=parseInt(s[1]);return t.toUpperCase()+`

`+r+`

`+ow(i.getShaderSource(e),o)}else return r}function cw(i,e){const t=lw(e);return[`vec4 ${i}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function uw(i,e){let t;switch(e){case wy:t="Linear";break;case Cy:t="Reinhard";break;case Ry:t="Cineon";break;case Ly:t="ACESFilmic";break;case Iy:t="AgX";break;case Dy:t="Neutral";break;case Py:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+i+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const Il=new H;function dw(){vt.getLuminanceCoefficients(Il);const i=Il.x.toFixed(4),e=Il.y.toFixed(4),t=Il.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${i}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function fw(i){return[i.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",i.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(xo).join(`
`)}function hw(i){const e=[];for(const t in i){const n=i[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function pw(i,e){const t={},n=i.getProgramParameter(e,i.ACTIVE_ATTRIBUTES);for(let r=0;r<n;r++){const s=i.getActiveAttrib(e,r),o=s.name;let a=1;s.type===i.FLOAT_MAT2&&(a=2),s.type===i.FLOAT_MAT3&&(a=3),s.type===i.FLOAT_MAT4&&(a=4),t[o]={type:s.type,location:i.getAttribLocation(e,o),locationSize:a}}return t}function xo(i){return i!==""}function Nm(i,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return i.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Um(i,e){return i.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const mw=/^[ \t]*#include +<([\w\d./]+)>/gm;function Of(i){return i.replace(mw,_w)}const gw=new Map;function _w(i,e){let t=ct[e];if(t===void 0){const n=gw.get(e);if(n!==void 0)t=ct[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("Can not resolve #include <"+e+">")}return Of(t)}const vw=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Fm(i){return i.replace(vw,Mw)}function Mw(i,e,t,n){let r="";for(let s=parseInt(e);s<parseInt(t);s++)r+=n.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return r}function Bm(i){let e=`precision ${i.precision} float;
	precision ${i.precision} int;
	precision ${i.precision} sampler2D;
	precision ${i.precision} samplerCube;
	precision ${i.precision} sampler3D;
	precision ${i.precision} sampler2DArray;
	precision ${i.precision} sampler2DShadow;
	precision ${i.precision} samplerCubeShadow;
	precision ${i.precision} sampler2DArrayShadow;
	precision ${i.precision} isampler2D;
	precision ${i.precision} isampler3D;
	precision ${i.precision} isamplerCube;
	precision ${i.precision} isampler2DArray;
	precision ${i.precision} usampler2D;
	precision ${i.precision} usampler3D;
	precision ${i.precision} usamplerCube;
	precision ${i.precision} usampler2DArray;
	`;return i.precision==="highp"?e+=`
#define HIGH_PRECISION`:i.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:i.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function Sw(i){let e="SHADOWMAP_TYPE_BASIC";return i.shadowMapType===l_?e="SHADOWMAP_TYPE_PCF":i.shadowMapType===ay?e="SHADOWMAP_TYPE_PCF_SOFT":i.shadowMapType===dr&&(e="SHADOWMAP_TYPE_VSM"),e}function xw(i){let e="ENVMAP_TYPE_CUBE";if(i.envMap)switch(i.envMapMode){case Ha:case Va:e="ENVMAP_TYPE_CUBE";break;case ru:e="ENVMAP_TYPE_CUBE_UV";break}return e}function yw(i){let e="ENVMAP_MODE_REFLECTION";if(i.envMap)switch(i.envMapMode){case Va:e="ENVMAP_MODE_REFRACTION";break}return e}function Tw(i){let e="ENVMAP_BLENDING_NONE";if(i.envMap)switch(i.combine){case c_:e="ENVMAP_BLENDING_MULTIPLY";break;case Ey:e="ENVMAP_BLENDING_MIX";break;case Ay:e="ENVMAP_BLENDING_ADD";break}return e}function bw(i){const e=i.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:n,maxMip:t}}function Ew(i,e,t,n){const r=i.getContext(),s=t.defines;let o=t.vertexShader,a=t.fragmentShader;const l=Sw(t),u=xw(t),c=yw(t),d=Tw(t),p=bw(t),f=fw(t),_=hw(s),m=r.createProgram();let g,h,v=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(g=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,_].filter(xo).join(`
`),g.length>0&&(g+=`
`),h=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,_].filter(xo).join(`
`),h.length>0&&(h+=`
`)):(g=[Bm(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,_,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(xo).join(`
`),h=[Bm(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,_,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+u:"",t.envMap?"#define "+c:"",t.envMap?"#define "+d:"",p?"#define CUBEUV_TEXEL_WIDTH "+p.texelWidth:"",p?"#define CUBEUV_TEXEL_HEIGHT "+p.texelHeight:"",p?"#define CUBEUV_MAX_MIP "+p.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==jr?"#define TONE_MAPPING":"",t.toneMapping!==jr?ct.tonemapping_pars_fragment:"",t.toneMapping!==jr?uw("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",ct.colorspace_pars_fragment,cw("linearToOutputTexel",t.outputColorSpace),dw(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(xo).join(`
`)),o=Of(o),o=Nm(o,t),o=Um(o,t),a=Of(a),a=Nm(a,t),a=Um(a,t),o=Fm(o),a=Fm(a),t.isRawShaderMaterial!==!0&&(v=`#version 300 es
`,g=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+g,h=["#define varying in",t.glslVersion===Zp?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Zp?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+h);const M=v+g+o,S=v+h+a,P=Pm(r,r.VERTEX_SHADER,M),E=Pm(r,r.FRAGMENT_SHADER,S);r.attachShader(m,P),r.attachShader(m,E),t.index0AttributeName!==void 0?r.bindAttribLocation(m,0,t.index0AttributeName):t.morphTargets===!0&&r.bindAttribLocation(m,0,"position"),r.linkProgram(m);function A(C){if(i.debug.checkShaderErrors){const N=r.getProgramInfoLog(m).trim(),D=r.getShaderInfoLog(P).trim(),I=r.getShaderInfoLog(E).trim();let J=!0,q=!0;if(r.getProgramParameter(m,r.LINK_STATUS)===!1)if(J=!1,typeof i.debug.onShaderError=="function")i.debug.onShaderError(r,m,P,E);else{const oe=Dm(r,P,"vertex"),X=Dm(r,E,"fragment");console.error("THREE.WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(m,r.VALIDATE_STATUS)+`

Material Name: `+C.name+`
Material Type: `+C.type+`

Program Info Log: `+N+`
`+oe+`
`+X)}else N!==""?console.warn("THREE.WebGLProgram: Program Info Log:",N):(D===""||I==="")&&(q=!1);q&&(C.diagnostics={runnable:J,programLog:N,vertexShader:{log:D,prefix:g},fragmentShader:{log:I,prefix:h}})}r.deleteShader(P),r.deleteShader(E),L=new tc(r,m),y=pw(r,m)}let L;this.getUniforms=function(){return L===void 0&&A(this),L};let y;this.getAttributes=function(){return y===void 0&&A(this),y};let x=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return x===!1&&(x=r.getProgramParameter(m,sw)),x},this.destroy=function(){n.releaseStatesOfProgram(this),r.deleteProgram(m),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=aw++,this.cacheKey=e,this.usedTimes=1,this.program=m,this.vertexShader=P,this.fragmentShader=E,this}let Aw=0;class ww{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,n=e.fragmentShader,r=this._getShaderStage(t),s=this._getShaderStage(n),o=this._getShaderCacheForMaterial(e);return o.has(r)===!1&&(o.add(r),r.usedTimes++),o.has(s)===!1&&(o.add(s),s.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new Cw(e),t.set(e,n)),n}}class Cw{constructor(e){this.id=Aw++,this.code=e,this.usedTimes=0}}function Rw(i,e,t,n,r,s,o){const a=new E_,l=new ww,u=new Set,c=[],d=r.logarithmicDepthBuffer,p=r.vertexTextures;let f=r.precision;const _={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function m(y){return u.add(y),y===0?"uv":`uv${y}`}function g(y,x,C,N,D){const I=N.fog,J=D.geometry,q=y.isMeshStandardMaterial?N.environment:null,oe=(y.isMeshStandardMaterial?t:e).get(y.envMap||q),X=oe&&oe.mapping===ru?oe.image.height:null,he=_[y.type];y.precision!==null&&(f=r.getMaxPrecision(y.precision),f!==y.precision&&console.warn("THREE.WebGLProgram.getParameters:",y.precision,"not supported, using",f,"instead."));const pe=J.morphAttributes.position||J.morphAttributes.normal||J.morphAttributes.color,Se=pe!==void 0?pe.length:0;let Ne=0;J.morphAttributes.position!==void 0&&(Ne=1),J.morphAttributes.normal!==void 0&&(Ne=2),J.morphAttributes.color!==void 0&&(Ne=3);let nt,Z,le,Ce;if(he){const Rt=Ji[he];nt=Rt.vertexShader,Z=Rt.fragmentShader}else nt=y.vertexShader,Z=y.fragmentShader,l.update(y),le=l.getVertexShaderID(y),Ce=l.getFragmentShaderID(y);const ue=i.getRenderTarget(),Pe=i.state.buffers.depth.getReversed(),ze=D.isInstancedMesh===!0,Ze=D.isBatchedMesh===!0,wt=!!y.map,Oe=!!y.matcap,Ht=!!oe,F=!!y.aoMap,Y=!!y.lightMap,Ve=!!y.bumpMap,Xe=!!y.normalMap,ee=!!y.displacementMap,Ct=!!y.emissiveMap,qe=!!y.metalnessMap,R=!!y.roughnessMap,T=y.anisotropy>0,G=y.clearcoat>0,Q=y.dispersion>0,se=y.iridescence>0,j=y.sheen>0,De=y.transmission>0,ge=T&&!!y.anisotropyMap,be=G&&!!y.clearcoatMap,dt=G&&!!y.clearcoatNormalMap,ce=G&&!!y.clearcoatRoughnessMap,Ee=se&&!!y.iridescenceMap,Je=se&&!!y.iridescenceThicknessMap,Qe=j&&!!y.sheenColorMap,Le=j&&!!y.sheenRoughnessMap,ht=!!y.specularMap,lt=!!y.specularColorMap,Bt=!!y.specularIntensityMap,U=De&&!!y.transmissionMap,Me=De&&!!y.thicknessMap,$=!!y.gradientMap,ne=!!y.alphaMap,Te=y.alphaTest>0,xe=!!y.alphaHash,rt=!!y.extensions;let Qt=jr;y.toneMapped&&(ue===null||ue.isXRRenderTarget===!0)&&(Qt=i.toneMapping);const Cn={shaderID:he,shaderType:y.type,shaderName:y.name,vertexShader:nt,fragmentShader:Z,defines:y.defines,customVertexShaderID:le,customFragmentShaderID:Ce,isRawShaderMaterial:y.isRawShaderMaterial===!0,glslVersion:y.glslVersion,precision:f,batching:Ze,batchingColor:Ze&&D._colorsTexture!==null,instancing:ze,instancingColor:ze&&D.instanceColor!==null,instancingMorph:ze&&D.morphTexture!==null,supportsVertexTextures:p,outputColorSpace:ue===null?i.outputColorSpace:ue.isXRRenderTarget===!0?ue.texture.colorSpace:Qa,alphaToCoverage:!!y.alphaToCoverage,map:wt,matcap:Oe,envMap:Ht,envMapMode:Ht&&oe.mapping,envMapCubeUVHeight:X,aoMap:F,lightMap:Y,bumpMap:Ve,normalMap:Xe,displacementMap:p&&ee,emissiveMap:Ct,normalMapObjectSpace:Xe&&y.normalMapType===Oy,normalMapTangentSpace:Xe&&y.normalMapType===By,metalnessMap:qe,roughnessMap:R,anisotropy:T,anisotropyMap:ge,clearcoat:G,clearcoatMap:be,clearcoatNormalMap:dt,clearcoatRoughnessMap:ce,dispersion:Q,iridescence:se,iridescenceMap:Ee,iridescenceThicknessMap:Je,sheen:j,sheenColorMap:Qe,sheenRoughnessMap:Le,specularMap:ht,specularColorMap:lt,specularIntensityMap:Bt,transmission:De,transmissionMap:U,thicknessMap:Me,gradientMap:$,opaque:y.transparent===!1&&y.blending===Ea&&y.alphaToCoverage===!1,alphaMap:ne,alphaTest:Te,alphaHash:xe,combine:y.combine,mapUv:wt&&m(y.map.channel),aoMapUv:F&&m(y.aoMap.channel),lightMapUv:Y&&m(y.lightMap.channel),bumpMapUv:Ve&&m(y.bumpMap.channel),normalMapUv:Xe&&m(y.normalMap.channel),displacementMapUv:ee&&m(y.displacementMap.channel),emissiveMapUv:Ct&&m(y.emissiveMap.channel),metalnessMapUv:qe&&m(y.metalnessMap.channel),roughnessMapUv:R&&m(y.roughnessMap.channel),anisotropyMapUv:ge&&m(y.anisotropyMap.channel),clearcoatMapUv:be&&m(y.clearcoatMap.channel),clearcoatNormalMapUv:dt&&m(y.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:ce&&m(y.clearcoatRoughnessMap.channel),iridescenceMapUv:Ee&&m(y.iridescenceMap.channel),iridescenceThicknessMapUv:Je&&m(y.iridescenceThicknessMap.channel),sheenColorMapUv:Qe&&m(y.sheenColorMap.channel),sheenRoughnessMapUv:Le&&m(y.sheenRoughnessMap.channel),specularMapUv:ht&&m(y.specularMap.channel),specularColorMapUv:lt&&m(y.specularColorMap.channel),specularIntensityMapUv:Bt&&m(y.specularIntensityMap.channel),transmissionMapUv:U&&m(y.transmissionMap.channel),thicknessMapUv:Me&&m(y.thicknessMap.channel),alphaMapUv:ne&&m(y.alphaMap.channel),vertexTangents:!!J.attributes.tangent&&(Xe||T),vertexColors:y.vertexColors,vertexAlphas:y.vertexColors===!0&&!!J.attributes.color&&J.attributes.color.itemSize===4,pointsUvs:D.isPoints===!0&&!!J.attributes.uv&&(wt||ne),fog:!!I,useFog:y.fog===!0,fogExp2:!!I&&I.isFogExp2,flatShading:y.flatShading===!0,sizeAttenuation:y.sizeAttenuation===!0,logarithmicDepthBuffer:d,reverseDepthBuffer:Pe,skinning:D.isSkinnedMesh===!0,morphTargets:J.morphAttributes.position!==void 0,morphNormals:J.morphAttributes.normal!==void 0,morphColors:J.morphAttributes.color!==void 0,morphTargetsCount:Se,morphTextureStride:Ne,numDirLights:x.directional.length,numPointLights:x.point.length,numSpotLights:x.spot.length,numSpotLightMaps:x.spotLightMap.length,numRectAreaLights:x.rectArea.length,numHemiLights:x.hemi.length,numDirLightShadows:x.directionalShadowMap.length,numPointLightShadows:x.pointShadowMap.length,numSpotLightShadows:x.spotShadowMap.length,numSpotLightShadowsWithMaps:x.numSpotLightShadowsWithMaps,numLightProbes:x.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:y.dithering,shadowMapEnabled:i.shadowMap.enabled&&C.length>0,shadowMapType:i.shadowMap.type,toneMapping:Qt,decodeVideoTexture:wt&&y.map.isVideoTexture===!0&&vt.getTransfer(y.map.colorSpace)===Ut,decodeVideoTextureEmissive:Ct&&y.emissiveMap.isVideoTexture===!0&&vt.getTransfer(y.emissiveMap.colorSpace)===Ut,premultipliedAlpha:y.premultipliedAlpha,doubleSided:y.side===Qi,flipSided:y.side===Jn,useDepthPacking:y.depthPacking>=0,depthPacking:y.depthPacking||0,index0AttributeName:y.index0AttributeName,extensionClipCullDistance:rt&&y.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(rt&&y.extensions.multiDraw===!0||Ze)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:y.customProgramCacheKey()};return Cn.vertexUv1s=u.has(1),Cn.vertexUv2s=u.has(2),Cn.vertexUv3s=u.has(3),u.clear(),Cn}function h(y){const x=[];if(y.shaderID?x.push(y.shaderID):(x.push(y.customVertexShaderID),x.push(y.customFragmentShaderID)),y.defines!==void 0)for(const C in y.defines)x.push(C),x.push(y.defines[C]);return y.isRawShaderMaterial===!1&&(v(x,y),M(x,y),x.push(i.outputColorSpace)),x.push(y.customProgramCacheKey),x.join()}function v(y,x){y.push(x.precision),y.push(x.outputColorSpace),y.push(x.envMapMode),y.push(x.envMapCubeUVHeight),y.push(x.mapUv),y.push(x.alphaMapUv),y.push(x.lightMapUv),y.push(x.aoMapUv),y.push(x.bumpMapUv),y.push(x.normalMapUv),y.push(x.displacementMapUv),y.push(x.emissiveMapUv),y.push(x.metalnessMapUv),y.push(x.roughnessMapUv),y.push(x.anisotropyMapUv),y.push(x.clearcoatMapUv),y.push(x.clearcoatNormalMapUv),y.push(x.clearcoatRoughnessMapUv),y.push(x.iridescenceMapUv),y.push(x.iridescenceThicknessMapUv),y.push(x.sheenColorMapUv),y.push(x.sheenRoughnessMapUv),y.push(x.specularMapUv),y.push(x.specularColorMapUv),y.push(x.specularIntensityMapUv),y.push(x.transmissionMapUv),y.push(x.thicknessMapUv),y.push(x.combine),y.push(x.fogExp2),y.push(x.sizeAttenuation),y.push(x.morphTargetsCount),y.push(x.morphAttributeCount),y.push(x.numDirLights),y.push(x.numPointLights),y.push(x.numSpotLights),y.push(x.numSpotLightMaps),y.push(x.numHemiLights),y.push(x.numRectAreaLights),y.push(x.numDirLightShadows),y.push(x.numPointLightShadows),y.push(x.numSpotLightShadows),y.push(x.numSpotLightShadowsWithMaps),y.push(x.numLightProbes),y.push(x.shadowMapType),y.push(x.toneMapping),y.push(x.numClippingPlanes),y.push(x.numClipIntersection),y.push(x.depthPacking)}function M(y,x){a.disableAll(),x.supportsVertexTextures&&a.enable(0),x.instancing&&a.enable(1),x.instancingColor&&a.enable(2),x.instancingMorph&&a.enable(3),x.matcap&&a.enable(4),x.envMap&&a.enable(5),x.normalMapObjectSpace&&a.enable(6),x.normalMapTangentSpace&&a.enable(7),x.clearcoat&&a.enable(8),x.iridescence&&a.enable(9),x.alphaTest&&a.enable(10),x.vertexColors&&a.enable(11),x.vertexAlphas&&a.enable(12),x.vertexUv1s&&a.enable(13),x.vertexUv2s&&a.enable(14),x.vertexUv3s&&a.enable(15),x.vertexTangents&&a.enable(16),x.anisotropy&&a.enable(17),x.alphaHash&&a.enable(18),x.batching&&a.enable(19),x.dispersion&&a.enable(20),x.batchingColor&&a.enable(21),y.push(a.mask),a.disableAll(),x.fog&&a.enable(0),x.useFog&&a.enable(1),x.flatShading&&a.enable(2),x.logarithmicDepthBuffer&&a.enable(3),x.reverseDepthBuffer&&a.enable(4),x.skinning&&a.enable(5),x.morphTargets&&a.enable(6),x.morphNormals&&a.enable(7),x.morphColors&&a.enable(8),x.premultipliedAlpha&&a.enable(9),x.shadowMapEnabled&&a.enable(10),x.doubleSided&&a.enable(11),x.flipSided&&a.enable(12),x.useDepthPacking&&a.enable(13),x.dithering&&a.enable(14),x.transmission&&a.enable(15),x.sheen&&a.enable(16),x.opaque&&a.enable(17),x.pointsUvs&&a.enable(18),x.decodeVideoTexture&&a.enable(19),x.decodeVideoTextureEmissive&&a.enable(20),x.alphaToCoverage&&a.enable(21),y.push(a.mask)}function S(y){const x=_[y.type];let C;if(x){const N=Ji[x];C=Ec.clone(N.uniforms)}else C=y.uniforms;return C}function P(y,x){let C;for(let N=0,D=c.length;N<D;N++){const I=c[N];if(I.cacheKey===x){C=I,++C.usedTimes;break}}return C===void 0&&(C=new Ew(i,x,y,s),c.push(C)),C}function E(y){if(--y.usedTimes===0){const x=c.indexOf(y);c[x]=c[c.length-1],c.pop(),y.destroy()}}function A(y){l.remove(y)}function L(){l.dispose()}return{getParameters:g,getProgramCacheKey:h,getUniforms:S,acquireProgram:P,releaseProgram:E,releaseShaderCache:A,programs:c,dispose:L}}function Lw(){let i=new WeakMap;function e(o){return i.has(o)}function t(o){let a=i.get(o);return a===void 0&&(a={},i.set(o,a)),a}function n(o){i.delete(o)}function r(o,a,l){i.get(o)[a]=l}function s(){i=new WeakMap}return{has:e,get:t,remove:n,update:r,dispose:s}}function Pw(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.material.id!==e.material.id?i.material.id-e.material.id:i.z!==e.z?i.z-e.z:i.id-e.id}function Om(i,e){return i.groupOrder!==e.groupOrder?i.groupOrder-e.groupOrder:i.renderOrder!==e.renderOrder?i.renderOrder-e.renderOrder:i.z!==e.z?e.z-i.z:i.id-e.id}function km(){const i=[];let e=0;const t=[],n=[],r=[];function s(){e=0,t.length=0,n.length=0,r.length=0}function o(d,p,f,_,m,g){let h=i[e];return h===void 0?(h={id:d.id,object:d,geometry:p,material:f,groupOrder:_,renderOrder:d.renderOrder,z:m,group:g},i[e]=h):(h.id=d.id,h.object=d,h.geometry=p,h.material=f,h.groupOrder=_,h.renderOrder=d.renderOrder,h.z=m,h.group=g),e++,h}function a(d,p,f,_,m,g){const h=o(d,p,f,_,m,g);f.transmission>0?n.push(h):f.transparent===!0?r.push(h):t.push(h)}function l(d,p,f,_,m,g){const h=o(d,p,f,_,m,g);f.transmission>0?n.unshift(h):f.transparent===!0?r.unshift(h):t.unshift(h)}function u(d,p){t.length>1&&t.sort(d||Pw),n.length>1&&n.sort(p||Om),r.length>1&&r.sort(p||Om)}function c(){for(let d=e,p=i.length;d<p;d++){const f=i[d];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:t,transmissive:n,transparent:r,init:s,push:a,unshift:l,finish:c,sort:u}}function Iw(){let i=new WeakMap;function e(n,r){const s=i.get(n);let o;return s===void 0?(o=new km,i.set(n,[o])):r>=s.length?(o=new km,s.push(o)):o=s[r],o}function t(){i=new WeakMap}return{get:e,dispose:t}}function Dw(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new H,color:new pt};break;case"SpotLight":t={position:new H,direction:new H,color:new pt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new H,color:new pt,distance:0,decay:0};break;case"HemisphereLight":t={direction:new H,skyColor:new pt,groundColor:new pt};break;case"RectAreaLight":t={color:new pt,position:new H,halfWidth:new H,halfHeight:new H};break}return i[e.id]=t,t}}}function Nw(){const i={};return{get:function(e){if(i[e.id]!==void 0)return i[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new tt};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new tt};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new tt,shadowCameraNear:1,shadowCameraFar:1e3};break}return i[e.id]=t,t}}}let Uw=0;function Fw(i,e){return(e.castShadow?2:0)-(i.castShadow?2:0)+(e.map?1:0)-(i.map?1:0)}function Bw(i){const e=new Dw,t=Nw(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let u=0;u<9;u++)n.probe.push(new H);const r=new H,s=new rn,o=new rn;function a(u){let c=0,d=0,p=0;for(let y=0;y<9;y++)n.probe[y].set(0,0,0);let f=0,_=0,m=0,g=0,h=0,v=0,M=0,S=0,P=0,E=0,A=0;u.sort(Fw);for(let y=0,x=u.length;y<x;y++){const C=u[y],N=C.color,D=C.intensity,I=C.distance,J=C.shadow&&C.shadow.map?C.shadow.map.texture:null;if(C.isAmbientLight)c+=N.r*D,d+=N.g*D,p+=N.b*D;else if(C.isLightProbe){for(let q=0;q<9;q++)n.probe[q].addScaledVector(C.sh.coefficients[q],D);A++}else if(C.isDirectionalLight){const q=e.get(C);if(q.color.copy(C.color).multiplyScalar(C.intensity),C.castShadow){const oe=C.shadow,X=t.get(C);X.shadowIntensity=oe.intensity,X.shadowBias=oe.bias,X.shadowNormalBias=oe.normalBias,X.shadowRadius=oe.radius,X.shadowMapSize=oe.mapSize,n.directionalShadow[f]=X,n.directionalShadowMap[f]=J,n.directionalShadowMatrix[f]=C.shadow.matrix,v++}n.directional[f]=q,f++}else if(C.isSpotLight){const q=e.get(C);q.position.setFromMatrixPosition(C.matrixWorld),q.color.copy(N).multiplyScalar(D),q.distance=I,q.coneCos=Math.cos(C.angle),q.penumbraCos=Math.cos(C.angle*(1-C.penumbra)),q.decay=C.decay,n.spot[m]=q;const oe=C.shadow;if(C.map&&(n.spotLightMap[P]=C.map,P++,oe.updateMatrices(C),C.castShadow&&E++),n.spotLightMatrix[m]=oe.matrix,C.castShadow){const X=t.get(C);X.shadowIntensity=oe.intensity,X.shadowBias=oe.bias,X.shadowNormalBias=oe.normalBias,X.shadowRadius=oe.radius,X.shadowMapSize=oe.mapSize,n.spotShadow[m]=X,n.spotShadowMap[m]=J,S++}m++}else if(C.isRectAreaLight){const q=e.get(C);q.color.copy(N).multiplyScalar(D),q.halfWidth.set(C.width*.5,0,0),q.halfHeight.set(0,C.height*.5,0),n.rectArea[g]=q,g++}else if(C.isPointLight){const q=e.get(C);if(q.color.copy(C.color).multiplyScalar(C.intensity),q.distance=C.distance,q.decay=C.decay,C.castShadow){const oe=C.shadow,X=t.get(C);X.shadowIntensity=oe.intensity,X.shadowBias=oe.bias,X.shadowNormalBias=oe.normalBias,X.shadowRadius=oe.radius,X.shadowMapSize=oe.mapSize,X.shadowCameraNear=oe.camera.near,X.shadowCameraFar=oe.camera.far,n.pointShadow[_]=X,n.pointShadowMap[_]=J,n.pointShadowMatrix[_]=C.shadow.matrix,M++}n.point[_]=q,_++}else if(C.isHemisphereLight){const q=e.get(C);q.skyColor.copy(C.color).multiplyScalar(D),q.groundColor.copy(C.groundColor).multiplyScalar(D),n.hemi[h]=q,h++}}g>0&&(i.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=me.LTC_FLOAT_1,n.rectAreaLTC2=me.LTC_FLOAT_2):(n.rectAreaLTC1=me.LTC_HALF_1,n.rectAreaLTC2=me.LTC_HALF_2)),n.ambient[0]=c,n.ambient[1]=d,n.ambient[2]=p;const L=n.hash;(L.directionalLength!==f||L.pointLength!==_||L.spotLength!==m||L.rectAreaLength!==g||L.hemiLength!==h||L.numDirectionalShadows!==v||L.numPointShadows!==M||L.numSpotShadows!==S||L.numSpotMaps!==P||L.numLightProbes!==A)&&(n.directional.length=f,n.spot.length=m,n.rectArea.length=g,n.point.length=_,n.hemi.length=h,n.directionalShadow.length=v,n.directionalShadowMap.length=v,n.pointShadow.length=M,n.pointShadowMap.length=M,n.spotShadow.length=S,n.spotShadowMap.length=S,n.directionalShadowMatrix.length=v,n.pointShadowMatrix.length=M,n.spotLightMatrix.length=S+P-E,n.spotLightMap.length=P,n.numSpotLightShadowsWithMaps=E,n.numLightProbes=A,L.directionalLength=f,L.pointLength=_,L.spotLength=m,L.rectAreaLength=g,L.hemiLength=h,L.numDirectionalShadows=v,L.numPointShadows=M,L.numSpotShadows=S,L.numSpotMaps=P,L.numLightProbes=A,n.version=Uw++)}function l(u,c){let d=0,p=0,f=0,_=0,m=0;const g=c.matrixWorldInverse;for(let h=0,v=u.length;h<v;h++){const M=u[h];if(M.isDirectionalLight){const S=n.directional[d];S.direction.setFromMatrixPosition(M.matrixWorld),r.setFromMatrixPosition(M.target.matrixWorld),S.direction.sub(r),S.direction.transformDirection(g),d++}else if(M.isSpotLight){const S=n.spot[f];S.position.setFromMatrixPosition(M.matrixWorld),S.position.applyMatrix4(g),S.direction.setFromMatrixPosition(M.matrixWorld),r.setFromMatrixPosition(M.target.matrixWorld),S.direction.sub(r),S.direction.transformDirection(g),f++}else if(M.isRectAreaLight){const S=n.rectArea[_];S.position.setFromMatrixPosition(M.matrixWorld),S.position.applyMatrix4(g),o.identity(),s.copy(M.matrixWorld),s.premultiply(g),o.extractRotation(s),S.halfWidth.set(M.width*.5,0,0),S.halfHeight.set(0,M.height*.5,0),S.halfWidth.applyMatrix4(o),S.halfHeight.applyMatrix4(o),_++}else if(M.isPointLight){const S=n.point[p];S.position.setFromMatrixPosition(M.matrixWorld),S.position.applyMatrix4(g),p++}else if(M.isHemisphereLight){const S=n.hemi[m];S.direction.setFromMatrixPosition(M.matrixWorld),S.direction.transformDirection(g),m++}}}return{setup:a,setupView:l,state:n}}function Hm(i){const e=new Bw(i),t=[],n=[];function r(c){u.camera=c,t.length=0,n.length=0}function s(c){t.push(c)}function o(c){n.push(c)}function a(){e.setup(t)}function l(c){e.setupView(t,c)}const u={lightsArray:t,shadowsArray:n,camera:null,lights:e,transmissionRenderTarget:{}};return{init:r,state:u,setupLights:a,setupLightsView:l,pushLight:s,pushShadow:o}}function Ow(i){let e=new WeakMap;function t(r,s=0){const o=e.get(r);let a;return o===void 0?(a=new Hm(i),e.set(r,[a])):s>=o.length?(a=new Hm(i),o.push(a)):a=o[s],a}function n(){e=new WeakMap}return{get:t,dispose:n}}class kw extends to{static get type(){return"MeshDepthMaterial"}constructor(e){super(),this.isMeshDepthMaterial=!0,this.depthPacking=Uy,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class Hw extends to{static get type(){return"MeshDistanceMaterial"}constructor(e){super(),this.isMeshDistanceMaterial=!0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const Vw=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Gw=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function zw(i,e,t){let n=new I_;const r=new tt,s=new tt,o=new un,a=new kw({depthPacking:Fy}),l=new Hw,u={},c=t.maxTextureSize,d={[rs]:Jn,[Jn]:rs,[Qi]:Qi},p=new Zn({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new tt},radius:{value:4}},vertexShader:Vw,fragmentShader:Gw}),f=p.clone();f.defines.HORIZONTAL_PASS=1;const _=new sn;_.setAttribute("position",new ir(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const m=new je(_,p),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=l_;let h=this.type;this.render=function(E,A,L){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||E.length===0)return;const y=i.getRenderTarget(),x=i.getActiveCubeFace(),C=i.getActiveMipmapLevel(),N=i.state;N.setBlending(yr),N.buffers.color.setClear(1,1,1,1),N.buffers.depth.setTest(!0),N.setScissorTest(!1);const D=h!==dr&&this.type===dr,I=h===dr&&this.type!==dr;for(let J=0,q=E.length;J<q;J++){const oe=E[J],X=oe.shadow;if(X===void 0){console.warn("THREE.WebGLShadowMap:",oe,"has no shadow.");continue}if(X.autoUpdate===!1&&X.needsUpdate===!1)continue;r.copy(X.mapSize);const he=X.getFrameExtents();if(r.multiply(he),s.copy(X.mapSize),(r.x>c||r.y>c)&&(r.x>c&&(s.x=Math.floor(c/he.x),r.x=s.x*he.x,X.mapSize.x=s.x),r.y>c&&(s.y=Math.floor(c/he.y),r.y=s.y*he.y,X.mapSize.y=s.y)),X.map===null||D===!0||I===!0){const Se=this.type!==dr?{minFilter:Fi,magFilter:Fi}:{};X.map!==null&&X.map.dispose(),X.map=new Bi(r.x,r.y,Se),X.map.texture.name=oe.name+".shadowMap",X.camera.updateProjectionMatrix()}i.setRenderTarget(X.map),i.clear();const pe=X.getViewportCount();for(let Se=0;Se<pe;Se++){const Ne=X.getViewport(Se);o.set(s.x*Ne.x,s.y*Ne.y,s.x*Ne.z,s.y*Ne.w),N.viewport(o),X.updateMatrices(oe,Se),n=X.getFrustum(),S(A,L,X.camera,oe,this.type)}X.isPointLightShadow!==!0&&this.type===dr&&v(X,L),X.needsUpdate=!1}h=this.type,g.needsUpdate=!1,i.setRenderTarget(y,x,C)};function v(E,A){const L=e.update(m);p.defines.VSM_SAMPLES!==E.blurSamples&&(p.defines.VSM_SAMPLES=E.blurSamples,f.defines.VSM_SAMPLES=E.blurSamples,p.needsUpdate=!0,f.needsUpdate=!0),E.mapPass===null&&(E.mapPass=new Bi(r.x,r.y)),p.uniforms.shadow_pass.value=E.map.texture,p.uniforms.resolution.value=E.mapSize,p.uniforms.radius.value=E.radius,i.setRenderTarget(E.mapPass),i.clear(),i.renderBufferDirect(A,null,L,p,m,null),f.uniforms.shadow_pass.value=E.mapPass.texture,f.uniforms.resolution.value=E.mapSize,f.uniforms.radius.value=E.radius,i.setRenderTarget(E.map),i.clear(),i.renderBufferDirect(A,null,L,f,m,null)}function M(E,A,L,y){let x=null;const C=L.isPointLight===!0?E.customDistanceMaterial:E.customDepthMaterial;if(C!==void 0)x=C;else if(x=L.isPointLight===!0?l:a,i.localClippingEnabled&&A.clipShadows===!0&&Array.isArray(A.clippingPlanes)&&A.clippingPlanes.length!==0||A.displacementMap&&A.displacementScale!==0||A.alphaMap&&A.alphaTest>0||A.map&&A.alphaTest>0){const N=x.uuid,D=A.uuid;let I=u[N];I===void 0&&(I={},u[N]=I);let J=I[D];J===void 0&&(J=x.clone(),I[D]=J,A.addEventListener("dispose",P)),x=J}if(x.visible=A.visible,x.wireframe=A.wireframe,y===dr?x.side=A.shadowSide!==null?A.shadowSide:A.side:x.side=A.shadowSide!==null?A.shadowSide:d[A.side],x.alphaMap=A.alphaMap,x.alphaTest=A.alphaTest,x.map=A.map,x.clipShadows=A.clipShadows,x.clippingPlanes=A.clippingPlanes,x.clipIntersection=A.clipIntersection,x.displacementMap=A.displacementMap,x.displacementScale=A.displacementScale,x.displacementBias=A.displacementBias,x.wireframeLinewidth=A.wireframeLinewidth,x.linewidth=A.linewidth,L.isPointLight===!0&&x.isMeshDistanceMaterial===!0){const N=i.properties.get(x);N.light=L}return x}function S(E,A,L,y,x){if(E.visible===!1)return;if(E.layers.test(A.layers)&&(E.isMesh||E.isLine||E.isPoints)&&(E.castShadow||E.receiveShadow&&x===dr)&&(!E.frustumCulled||n.intersectsObject(E))){E.modelViewMatrix.multiplyMatrices(L.matrixWorldInverse,E.matrixWorld);const D=e.update(E),I=E.material;if(Array.isArray(I)){const J=D.groups;for(let q=0,oe=J.length;q<oe;q++){const X=J[q],he=I[X.materialIndex];if(he&&he.visible){const pe=M(E,he,y,x);E.onBeforeShadow(i,E,A,L,D,pe,X),i.renderBufferDirect(L,null,D,pe,E,X),E.onAfterShadow(i,E,A,L,D,pe,X)}}}else if(I.visible){const J=M(E,I,y,x);E.onBeforeShadow(i,E,A,L,D,J,null),i.renderBufferDirect(L,null,D,J,E,null),E.onAfterShadow(i,E,A,L,D,J,null)}}const N=E.children;for(let D=0,I=N.length;D<I;D++)S(N[D],A,L,y,x)}function P(E){E.target.removeEventListener("dispose",P);for(const L in u){const y=u[L],x=E.target.uuid;x in y&&(y[x].dispose(),delete y[x])}}}const Ww={[Qd]:ef,[tf]:sf,[nf]:af,[ka]:rf,[ef]:Qd,[sf]:tf,[af]:nf,[rf]:ka};function Kw(i,e){function t(){let U=!1;const Me=new un;let $=null;const ne=new un(0,0,0,0);return{setMask:function(Te){$!==Te&&!U&&(i.colorMask(Te,Te,Te,Te),$=Te)},setLocked:function(Te){U=Te},setClear:function(Te,xe,rt,Qt,Cn){Cn===!0&&(Te*=Qt,xe*=Qt,rt*=Qt),Me.set(Te,xe,rt,Qt),ne.equals(Me)===!1&&(i.clearColor(Te,xe,rt,Qt),ne.copy(Me))},reset:function(){U=!1,$=null,ne.set(-1,0,0,0)}}}function n(){let U=!1,Me=!1,$=null,ne=null,Te=null;return{setReversed:function(xe){if(Me!==xe){const rt=e.get("EXT_clip_control");Me?rt.clipControlEXT(rt.LOWER_LEFT_EXT,rt.ZERO_TO_ONE_EXT):rt.clipControlEXT(rt.LOWER_LEFT_EXT,rt.NEGATIVE_ONE_TO_ONE_EXT);const Qt=Te;Te=null,this.setClear(Qt)}Me=xe},getReversed:function(){return Me},setTest:function(xe){xe?ue(i.DEPTH_TEST):Pe(i.DEPTH_TEST)},setMask:function(xe){$!==xe&&!U&&(i.depthMask(xe),$=xe)},setFunc:function(xe){if(Me&&(xe=Ww[xe]),ne!==xe){switch(xe){case Qd:i.depthFunc(i.NEVER);break;case ef:i.depthFunc(i.ALWAYS);break;case tf:i.depthFunc(i.LESS);break;case ka:i.depthFunc(i.LEQUAL);break;case nf:i.depthFunc(i.EQUAL);break;case rf:i.depthFunc(i.GEQUAL);break;case sf:i.depthFunc(i.GREATER);break;case af:i.depthFunc(i.NOTEQUAL);break;default:i.depthFunc(i.LEQUAL)}ne=xe}},setLocked:function(xe){U=xe},setClear:function(xe){Te!==xe&&(Me&&(xe=1-xe),i.clearDepth(xe),Te=xe)},reset:function(){U=!1,$=null,ne=null,Te=null,Me=!1}}}function r(){let U=!1,Me=null,$=null,ne=null,Te=null,xe=null,rt=null,Qt=null,Cn=null;return{setTest:function(Rt){U||(Rt?ue(i.STENCIL_TEST):Pe(i.STENCIL_TEST))},setMask:function(Rt){Me!==Rt&&!U&&(i.stencilMask(Rt),Me=Rt)},setFunc:function(Rt,Ti,rr){($!==Rt||ne!==Ti||Te!==rr)&&(i.stencilFunc(Rt,Ti,rr),$=Rt,ne=Ti,Te=rr)},setOp:function(Rt,Ti,rr){(xe!==Rt||rt!==Ti||Qt!==rr)&&(i.stencilOp(Rt,Ti,rr),xe=Rt,rt=Ti,Qt=rr)},setLocked:function(Rt){U=Rt},setClear:function(Rt){Cn!==Rt&&(i.clearStencil(Rt),Cn=Rt)},reset:function(){U=!1,Me=null,$=null,ne=null,Te=null,xe=null,rt=null,Qt=null,Cn=null}}}const s=new t,o=new n,a=new r,l=new WeakMap,u=new WeakMap;let c={},d={},p=new WeakMap,f=[],_=null,m=!1,g=null,h=null,v=null,M=null,S=null,P=null,E=null,A=new pt(0,0,0),L=0,y=!1,x=null,C=null,N=null,D=null,I=null;const J=i.getParameter(i.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let q=!1,oe=0;const X=i.getParameter(i.VERSION);X.indexOf("WebGL")!==-1?(oe=parseFloat(/^WebGL (\d)/.exec(X)[1]),q=oe>=1):X.indexOf("OpenGL ES")!==-1&&(oe=parseFloat(/^OpenGL ES (\d)/.exec(X)[1]),q=oe>=2);let he=null,pe={};const Se=i.getParameter(i.SCISSOR_BOX),Ne=i.getParameter(i.VIEWPORT),nt=new un().fromArray(Se),Z=new un().fromArray(Ne);function le(U,Me,$,ne){const Te=new Uint8Array(4),xe=i.createTexture();i.bindTexture(U,xe),i.texParameteri(U,i.TEXTURE_MIN_FILTER,i.NEAREST),i.texParameteri(U,i.TEXTURE_MAG_FILTER,i.NEAREST);for(let rt=0;rt<$;rt++)U===i.TEXTURE_3D||U===i.TEXTURE_2D_ARRAY?i.texImage3D(Me,0,i.RGBA,1,1,ne,0,i.RGBA,i.UNSIGNED_BYTE,Te):i.texImage2D(Me+rt,0,i.RGBA,1,1,0,i.RGBA,i.UNSIGNED_BYTE,Te);return xe}const Ce={};Ce[i.TEXTURE_2D]=le(i.TEXTURE_2D,i.TEXTURE_2D,1),Ce[i.TEXTURE_CUBE_MAP]=le(i.TEXTURE_CUBE_MAP,i.TEXTURE_CUBE_MAP_POSITIVE_X,6),Ce[i.TEXTURE_2D_ARRAY]=le(i.TEXTURE_2D_ARRAY,i.TEXTURE_2D_ARRAY,1,1),Ce[i.TEXTURE_3D]=le(i.TEXTURE_3D,i.TEXTURE_3D,1,1),s.setClear(0,0,0,1),o.setClear(1),a.setClear(0),ue(i.DEPTH_TEST),o.setFunc(ka),Ve(!1),Xe(Kp),ue(i.CULL_FACE),F(yr);function ue(U){c[U]!==!0&&(i.enable(U),c[U]=!0)}function Pe(U){c[U]!==!1&&(i.disable(U),c[U]=!1)}function ze(U,Me){return d[U]!==Me?(i.bindFramebuffer(U,Me),d[U]=Me,U===i.DRAW_FRAMEBUFFER&&(d[i.FRAMEBUFFER]=Me),U===i.FRAMEBUFFER&&(d[i.DRAW_FRAMEBUFFER]=Me),!0):!1}function Ze(U,Me){let $=f,ne=!1;if(U){$=p.get(Me),$===void 0&&($=[],p.set(Me,$));const Te=U.textures;if($.length!==Te.length||$[0]!==i.COLOR_ATTACHMENT0){for(let xe=0,rt=Te.length;xe<rt;xe++)$[xe]=i.COLOR_ATTACHMENT0+xe;$.length=Te.length,ne=!0}}else $[0]!==i.BACK&&($[0]=i.BACK,ne=!0);ne&&i.drawBuffers($)}function wt(U){return _!==U?(i.useProgram(U),_=U,!0):!1}const Oe={[xs]:i.FUNC_ADD,[ly]:i.FUNC_SUBTRACT,[cy]:i.FUNC_REVERSE_SUBTRACT};Oe[uy]=i.MIN,Oe[dy]=i.MAX;const Ht={[fy]:i.ZERO,[hy]:i.ONE,[py]:i.SRC_COLOR,[jd]:i.SRC_ALPHA,[Sy]:i.SRC_ALPHA_SATURATE,[vy]:i.DST_COLOR,[gy]:i.DST_ALPHA,[my]:i.ONE_MINUS_SRC_COLOR,[Jd]:i.ONE_MINUS_SRC_ALPHA,[My]:i.ONE_MINUS_DST_COLOR,[_y]:i.ONE_MINUS_DST_ALPHA,[xy]:i.CONSTANT_COLOR,[yy]:i.ONE_MINUS_CONSTANT_COLOR,[Ty]:i.CONSTANT_ALPHA,[by]:i.ONE_MINUS_CONSTANT_ALPHA};function F(U,Me,$,ne,Te,xe,rt,Qt,Cn,Rt){if(U===yr){m===!0&&(Pe(i.BLEND),m=!1);return}if(m===!1&&(ue(i.BLEND),m=!0),U!==oy){if(U!==g||Rt!==y){if((h!==xs||S!==xs)&&(i.blendEquation(i.FUNC_ADD),h=xs,S=xs),Rt)switch(U){case Ea:i.blendFuncSeparate(i.ONE,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Hs:i.blendFunc(i.ONE,i.ONE);break;case Xp:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case qp:i.blendFuncSeparate(i.ZERO,i.SRC_COLOR,i.ZERO,i.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",U);break}else switch(U){case Ea:i.blendFuncSeparate(i.SRC_ALPHA,i.ONE_MINUS_SRC_ALPHA,i.ONE,i.ONE_MINUS_SRC_ALPHA);break;case Hs:i.blendFunc(i.SRC_ALPHA,i.ONE);break;case Xp:i.blendFuncSeparate(i.ZERO,i.ONE_MINUS_SRC_COLOR,i.ZERO,i.ONE);break;case qp:i.blendFunc(i.ZERO,i.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",U);break}v=null,M=null,P=null,E=null,A.set(0,0,0),L=0,g=U,y=Rt}return}Te=Te||Me,xe=xe||$,rt=rt||ne,(Me!==h||Te!==S)&&(i.blendEquationSeparate(Oe[Me],Oe[Te]),h=Me,S=Te),($!==v||ne!==M||xe!==P||rt!==E)&&(i.blendFuncSeparate(Ht[$],Ht[ne],Ht[xe],Ht[rt]),v=$,M=ne,P=xe,E=rt),(Qt.equals(A)===!1||Cn!==L)&&(i.blendColor(Qt.r,Qt.g,Qt.b,Cn),A.copy(Qt),L=Cn),g=U,y=!1}function Y(U,Me){U.side===Qi?Pe(i.CULL_FACE):ue(i.CULL_FACE);let $=U.side===Jn;Me&&($=!$),Ve($),U.blending===Ea&&U.transparent===!1?F(yr):F(U.blending,U.blendEquation,U.blendSrc,U.blendDst,U.blendEquationAlpha,U.blendSrcAlpha,U.blendDstAlpha,U.blendColor,U.blendAlpha,U.premultipliedAlpha),o.setFunc(U.depthFunc),o.setTest(U.depthTest),o.setMask(U.depthWrite),s.setMask(U.colorWrite);const ne=U.stencilWrite;a.setTest(ne),ne&&(a.setMask(U.stencilWriteMask),a.setFunc(U.stencilFunc,U.stencilRef,U.stencilFuncMask),a.setOp(U.stencilFail,U.stencilZFail,U.stencilZPass)),Ct(U.polygonOffset,U.polygonOffsetFactor,U.polygonOffsetUnits),U.alphaToCoverage===!0?ue(i.SAMPLE_ALPHA_TO_COVERAGE):Pe(i.SAMPLE_ALPHA_TO_COVERAGE)}function Ve(U){x!==U&&(U?i.frontFace(i.CW):i.frontFace(i.CCW),x=U)}function Xe(U){U!==ry?(ue(i.CULL_FACE),U!==C&&(U===Kp?i.cullFace(i.BACK):U===sy?i.cullFace(i.FRONT):i.cullFace(i.FRONT_AND_BACK))):Pe(i.CULL_FACE),C=U}function ee(U){U!==N&&(q&&i.lineWidth(U),N=U)}function Ct(U,Me,$){U?(ue(i.POLYGON_OFFSET_FILL),(D!==Me||I!==$)&&(i.polygonOffset(Me,$),D=Me,I=$)):Pe(i.POLYGON_OFFSET_FILL)}function qe(U){U?ue(i.SCISSOR_TEST):Pe(i.SCISSOR_TEST)}function R(U){U===void 0&&(U=i.TEXTURE0+J-1),he!==U&&(i.activeTexture(U),he=U)}function T(U,Me,$){$===void 0&&(he===null?$=i.TEXTURE0+J-1:$=he);let ne=pe[$];ne===void 0&&(ne={type:void 0,texture:void 0},pe[$]=ne),(ne.type!==U||ne.texture!==Me)&&(he!==$&&(i.activeTexture($),he=$),i.bindTexture(U,Me||Ce[U]),ne.type=U,ne.texture=Me)}function G(){const U=pe[he];U!==void 0&&U.type!==void 0&&(i.bindTexture(U.type,null),U.type=void 0,U.texture=void 0)}function Q(){try{i.compressedTexImage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function se(){try{i.compressedTexImage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function j(){try{i.texSubImage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function De(){try{i.texSubImage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function ge(){try{i.compressedTexSubImage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function be(){try{i.compressedTexSubImage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function dt(){try{i.texStorage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function ce(){try{i.texStorage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Ee(){try{i.texImage2D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Je(){try{i.texImage3D.apply(i,arguments)}catch(U){console.error("THREE.WebGLState:",U)}}function Qe(U){nt.equals(U)===!1&&(i.scissor(U.x,U.y,U.z,U.w),nt.copy(U))}function Le(U){Z.equals(U)===!1&&(i.viewport(U.x,U.y,U.z,U.w),Z.copy(U))}function ht(U,Me){let $=u.get(Me);$===void 0&&($=new WeakMap,u.set(Me,$));let ne=$.get(U);ne===void 0&&(ne=i.getUniformBlockIndex(Me,U.name),$.set(U,ne))}function lt(U,Me){const ne=u.get(Me).get(U);l.get(Me)!==ne&&(i.uniformBlockBinding(Me,ne,U.__bindingPointIndex),l.set(Me,ne))}function Bt(){i.disable(i.BLEND),i.disable(i.CULL_FACE),i.disable(i.DEPTH_TEST),i.disable(i.POLYGON_OFFSET_FILL),i.disable(i.SCISSOR_TEST),i.disable(i.STENCIL_TEST),i.disable(i.SAMPLE_ALPHA_TO_COVERAGE),i.blendEquation(i.FUNC_ADD),i.blendFunc(i.ONE,i.ZERO),i.blendFuncSeparate(i.ONE,i.ZERO,i.ONE,i.ZERO),i.blendColor(0,0,0,0),i.colorMask(!0,!0,!0,!0),i.clearColor(0,0,0,0),i.depthMask(!0),i.depthFunc(i.LESS),o.setReversed(!1),i.clearDepth(1),i.stencilMask(4294967295),i.stencilFunc(i.ALWAYS,0,4294967295),i.stencilOp(i.KEEP,i.KEEP,i.KEEP),i.clearStencil(0),i.cullFace(i.BACK),i.frontFace(i.CCW),i.polygonOffset(0,0),i.activeTexture(i.TEXTURE0),i.bindFramebuffer(i.FRAMEBUFFER,null),i.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),i.bindFramebuffer(i.READ_FRAMEBUFFER,null),i.useProgram(null),i.lineWidth(1),i.scissor(0,0,i.canvas.width,i.canvas.height),i.viewport(0,0,i.canvas.width,i.canvas.height),c={},he=null,pe={},d={},p=new WeakMap,f=[],_=null,m=!1,g=null,h=null,v=null,M=null,S=null,P=null,E=null,A=new pt(0,0,0),L=0,y=!1,x=null,C=null,N=null,D=null,I=null,nt.set(0,0,i.canvas.width,i.canvas.height),Z.set(0,0,i.canvas.width,i.canvas.height),s.reset(),o.reset(),a.reset()}return{buffers:{color:s,depth:o,stencil:a},enable:ue,disable:Pe,bindFramebuffer:ze,drawBuffers:Ze,useProgram:wt,setBlending:F,setMaterial:Y,setFlipSided:Ve,setCullFace:Xe,setLineWidth:ee,setPolygonOffset:Ct,setScissorTest:qe,activeTexture:R,bindTexture:T,unbindTexture:G,compressedTexImage2D:Q,compressedTexImage3D:se,texImage2D:Ee,texImage3D:Je,updateUBOMapping:ht,uniformBlockBinding:lt,texStorage2D:dt,texStorage3D:ce,texSubImage2D:j,texSubImage3D:De,compressedTexSubImage2D:ge,compressedTexSubImage3D:be,scissor:Qe,viewport:Le,reset:Bt}}function Vm(i,e,t,n){const r=Xw(n);switch(t){case p_:return i*e;case g_:return i*e;case __:return i*e*2;case v_:return i*e/r.components*r.byteLength;case Ph:return i*e/r.components*r.byteLength;case M_:return i*e*2/r.components*r.byteLength;case Ih:return i*e*2/r.components*r.byteLength;case m_:return i*e*3/r.components*r.byteLength;case Ii:return i*e*4/r.components*r.byteLength;case Dh:return i*e*4/r.components*r.byteLength;case $l:case Zl:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case jl:case Jl:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case ff:case pf:return Math.max(i,16)*Math.max(e,8)/4;case df:case hf:return Math.max(i,8)*Math.max(e,8)/2;case mf:case gf:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*8;case _f:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case vf:return Math.floor((i+3)/4)*Math.floor((e+3)/4)*16;case Mf:return Math.floor((i+4)/5)*Math.floor((e+3)/4)*16;case Sf:return Math.floor((i+4)/5)*Math.floor((e+4)/5)*16;case xf:return Math.floor((i+5)/6)*Math.floor((e+4)/5)*16;case yf:return Math.floor((i+5)/6)*Math.floor((e+5)/6)*16;case Tf:return Math.floor((i+7)/8)*Math.floor((e+4)/5)*16;case bf:return Math.floor((i+7)/8)*Math.floor((e+5)/6)*16;case Ef:return Math.floor((i+7)/8)*Math.floor((e+7)/8)*16;case Af:return Math.floor((i+9)/10)*Math.floor((e+4)/5)*16;case wf:return Math.floor((i+9)/10)*Math.floor((e+5)/6)*16;case Cf:return Math.floor((i+9)/10)*Math.floor((e+7)/8)*16;case Rf:return Math.floor((i+9)/10)*Math.floor((e+9)/10)*16;case Lf:return Math.floor((i+11)/12)*Math.floor((e+9)/10)*16;case Pf:return Math.floor((i+11)/12)*Math.floor((e+11)/12)*16;case Ql:case If:case Df:return Math.ceil(i/4)*Math.ceil(e/4)*16;case S_:case Nf:return Math.ceil(i/4)*Math.ceil(e/4)*8;case Uf:case Ff:return Math.ceil(i/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function Xw(i){switch(i){case Rr:case d_:return{byteLength:1,components:1};case Xo:case f_:case Tr:return{byteLength:2,components:1};case Rh:case Lh:return{byteLength:2,components:4};case Vs:case Ch:case vr:return{byteLength:4,components:1};case h_:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${i}.`)}function qw(i,e,t,n,r,s,o){const a=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),u=new tt,c=new WeakMap;let d;const p=new WeakMap;let f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function _(R,T){return f?new OffscreenCanvas(R,T):qo("canvas")}function m(R,T,G){let Q=1;const se=qe(R);if((se.width>G||se.height>G)&&(Q=G/Math.max(se.width,se.height)),Q<1)if(typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&R instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&R instanceof ImageBitmap||typeof VideoFrame<"u"&&R instanceof VideoFrame){const j=Math.floor(Q*se.width),De=Math.floor(Q*se.height);d===void 0&&(d=_(j,De));const ge=T?_(j,De):d;return ge.width=j,ge.height=De,ge.getContext("2d").drawImage(R,0,0,j,De),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+se.width+"x"+se.height+") to ("+j+"x"+De+")."),ge}else return"data"in R&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+se.width+"x"+se.height+")."),R;return R}function g(R){return R.generateMipmaps}function h(R){i.generateMipmap(R)}function v(R){return R.isWebGLCubeRenderTarget?i.TEXTURE_CUBE_MAP:R.isWebGL3DRenderTarget?i.TEXTURE_3D:R.isWebGLArrayRenderTarget||R.isCompressedArrayTexture?i.TEXTURE_2D_ARRAY:i.TEXTURE_2D}function M(R,T,G,Q,se=!1){if(R!==null){if(i[R]!==void 0)return i[R];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+R+"'")}let j=T;if(T===i.RED&&(G===i.FLOAT&&(j=i.R32F),G===i.HALF_FLOAT&&(j=i.R16F),G===i.UNSIGNED_BYTE&&(j=i.R8)),T===i.RED_INTEGER&&(G===i.UNSIGNED_BYTE&&(j=i.R8UI),G===i.UNSIGNED_SHORT&&(j=i.R16UI),G===i.UNSIGNED_INT&&(j=i.R32UI),G===i.BYTE&&(j=i.R8I),G===i.SHORT&&(j=i.R16I),G===i.INT&&(j=i.R32I)),T===i.RG&&(G===i.FLOAT&&(j=i.RG32F),G===i.HALF_FLOAT&&(j=i.RG16F),G===i.UNSIGNED_BYTE&&(j=i.RG8)),T===i.RG_INTEGER&&(G===i.UNSIGNED_BYTE&&(j=i.RG8UI),G===i.UNSIGNED_SHORT&&(j=i.RG16UI),G===i.UNSIGNED_INT&&(j=i.RG32UI),G===i.BYTE&&(j=i.RG8I),G===i.SHORT&&(j=i.RG16I),G===i.INT&&(j=i.RG32I)),T===i.RGB_INTEGER&&(G===i.UNSIGNED_BYTE&&(j=i.RGB8UI),G===i.UNSIGNED_SHORT&&(j=i.RGB16UI),G===i.UNSIGNED_INT&&(j=i.RGB32UI),G===i.BYTE&&(j=i.RGB8I),G===i.SHORT&&(j=i.RGB16I),G===i.INT&&(j=i.RGB32I)),T===i.RGBA_INTEGER&&(G===i.UNSIGNED_BYTE&&(j=i.RGBA8UI),G===i.UNSIGNED_SHORT&&(j=i.RGBA16UI),G===i.UNSIGNED_INT&&(j=i.RGBA32UI),G===i.BYTE&&(j=i.RGBA8I),G===i.SHORT&&(j=i.RGBA16I),G===i.INT&&(j=i.RGBA32I)),T===i.RGB&&G===i.UNSIGNED_INT_5_9_9_9_REV&&(j=i.RGB9_E5),T===i.RGBA){const De=se?su:vt.getTransfer(Q);G===i.FLOAT&&(j=i.RGBA32F),G===i.HALF_FLOAT&&(j=i.RGBA16F),G===i.UNSIGNED_BYTE&&(j=De===Ut?i.SRGB8_ALPHA8:i.RGBA8),G===i.UNSIGNED_SHORT_4_4_4_4&&(j=i.RGBA4),G===i.UNSIGNED_SHORT_5_5_5_1&&(j=i.RGB5_A1)}return(j===i.R16F||j===i.R32F||j===i.RG16F||j===i.RG32F||j===i.RGBA16F||j===i.RGBA32F)&&e.get("EXT_color_buffer_float"),j}function S(R,T){let G;return R?T===null||T===Vs||T===Ga?G=i.DEPTH24_STENCIL8:T===vr?G=i.DEPTH32F_STENCIL8:T===Xo&&(G=i.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):T===null||T===Vs||T===Ga?G=i.DEPTH_COMPONENT24:T===vr?G=i.DEPTH_COMPONENT32F:T===Xo&&(G=i.DEPTH_COMPONENT16),G}function P(R,T){return g(R)===!0||R.isFramebufferTexture&&R.minFilter!==Fi&&R.minFilter!==tr?Math.log2(Math.max(T.width,T.height))+1:R.mipmaps!==void 0&&R.mipmaps.length>0?R.mipmaps.length:R.isCompressedTexture&&Array.isArray(R.image)?T.mipmaps.length:1}function E(R){const T=R.target;T.removeEventListener("dispose",E),L(T),T.isVideoTexture&&c.delete(T)}function A(R){const T=R.target;T.removeEventListener("dispose",A),x(T)}function L(R){const T=n.get(R);if(T.__webglInit===void 0)return;const G=R.source,Q=p.get(G);if(Q){const se=Q[T.__cacheKey];se.usedTimes--,se.usedTimes===0&&y(R),Object.keys(Q).length===0&&p.delete(G)}n.remove(R)}function y(R){const T=n.get(R);i.deleteTexture(T.__webglTexture);const G=R.source,Q=p.get(G);delete Q[T.__cacheKey],o.memory.textures--}function x(R){const T=n.get(R);if(R.depthTexture&&(R.depthTexture.dispose(),n.remove(R.depthTexture)),R.isWebGLCubeRenderTarget)for(let Q=0;Q<6;Q++){if(Array.isArray(T.__webglFramebuffer[Q]))for(let se=0;se<T.__webglFramebuffer[Q].length;se++)i.deleteFramebuffer(T.__webglFramebuffer[Q][se]);else i.deleteFramebuffer(T.__webglFramebuffer[Q]);T.__webglDepthbuffer&&i.deleteRenderbuffer(T.__webglDepthbuffer[Q])}else{if(Array.isArray(T.__webglFramebuffer))for(let Q=0;Q<T.__webglFramebuffer.length;Q++)i.deleteFramebuffer(T.__webglFramebuffer[Q]);else i.deleteFramebuffer(T.__webglFramebuffer);if(T.__webglDepthbuffer&&i.deleteRenderbuffer(T.__webglDepthbuffer),T.__webglMultisampledFramebuffer&&i.deleteFramebuffer(T.__webglMultisampledFramebuffer),T.__webglColorRenderbuffer)for(let Q=0;Q<T.__webglColorRenderbuffer.length;Q++)T.__webglColorRenderbuffer[Q]&&i.deleteRenderbuffer(T.__webglColorRenderbuffer[Q]);T.__webglDepthRenderbuffer&&i.deleteRenderbuffer(T.__webglDepthRenderbuffer)}const G=R.textures;for(let Q=0,se=G.length;Q<se;Q++){const j=n.get(G[Q]);j.__webglTexture&&(i.deleteTexture(j.__webglTexture),o.memory.textures--),n.remove(G[Q])}n.remove(R)}let C=0;function N(){C=0}function D(){const R=C;return R>=r.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+R+" texture units while this GPU supports only "+r.maxTextures),C+=1,R}function I(R){const T=[];return T.push(R.wrapS),T.push(R.wrapT),T.push(R.wrapR||0),T.push(R.magFilter),T.push(R.minFilter),T.push(R.anisotropy),T.push(R.internalFormat),T.push(R.format),T.push(R.type),T.push(R.generateMipmaps),T.push(R.premultiplyAlpha),T.push(R.flipY),T.push(R.unpackAlignment),T.push(R.colorSpace),T.join()}function J(R,T){const G=n.get(R);if(R.isVideoTexture&&ee(R),R.isRenderTargetTexture===!1&&R.version>0&&G.__version!==R.version){const Q=R.image;if(Q===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(Q.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{Z(G,R,T);return}}t.bindTexture(i.TEXTURE_2D,G.__webglTexture,i.TEXTURE0+T)}function q(R,T){const G=n.get(R);if(R.version>0&&G.__version!==R.version){Z(G,R,T);return}t.bindTexture(i.TEXTURE_2D_ARRAY,G.__webglTexture,i.TEXTURE0+T)}function oe(R,T){const G=n.get(R);if(R.version>0&&G.__version!==R.version){Z(G,R,T);return}t.bindTexture(i.TEXTURE_3D,G.__webglTexture,i.TEXTURE0+T)}function X(R,T){const G=n.get(R);if(R.version>0&&G.__version!==R.version){le(G,R,T);return}t.bindTexture(i.TEXTURE_CUBE_MAP,G.__webglTexture,i.TEXTURE0+T)}const he={[cf]:i.REPEAT,[ws]:i.CLAMP_TO_EDGE,[uf]:i.MIRRORED_REPEAT},pe={[Fi]:i.NEAREST,[Ny]:i.NEAREST_MIPMAP_NEAREST,[fl]:i.NEAREST_MIPMAP_LINEAR,[tr]:i.LINEAR,[wu]:i.LINEAR_MIPMAP_NEAREST,[Cs]:i.LINEAR_MIPMAP_LINEAR},Se={[ky]:i.NEVER,[Ky]:i.ALWAYS,[Hy]:i.LESS,[x_]:i.LEQUAL,[Vy]:i.EQUAL,[Wy]:i.GEQUAL,[Gy]:i.GREATER,[zy]:i.NOTEQUAL};function Ne(R,T){if(T.type===vr&&e.has("OES_texture_float_linear")===!1&&(T.magFilter===tr||T.magFilter===wu||T.magFilter===fl||T.magFilter===Cs||T.minFilter===tr||T.minFilter===wu||T.minFilter===fl||T.minFilter===Cs)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),i.texParameteri(R,i.TEXTURE_WRAP_S,he[T.wrapS]),i.texParameteri(R,i.TEXTURE_WRAP_T,he[T.wrapT]),(R===i.TEXTURE_3D||R===i.TEXTURE_2D_ARRAY)&&i.texParameteri(R,i.TEXTURE_WRAP_R,he[T.wrapR]),i.texParameteri(R,i.TEXTURE_MAG_FILTER,pe[T.magFilter]),i.texParameteri(R,i.TEXTURE_MIN_FILTER,pe[T.minFilter]),T.compareFunction&&(i.texParameteri(R,i.TEXTURE_COMPARE_MODE,i.COMPARE_REF_TO_TEXTURE),i.texParameteri(R,i.TEXTURE_COMPARE_FUNC,Se[T.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(T.magFilter===Fi||T.minFilter!==fl&&T.minFilter!==Cs||T.type===vr&&e.has("OES_texture_float_linear")===!1)return;if(T.anisotropy>1||n.get(T).__currentAnisotropy){const G=e.get("EXT_texture_filter_anisotropic");i.texParameterf(R,G.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(T.anisotropy,r.getMaxAnisotropy())),n.get(T).__currentAnisotropy=T.anisotropy}}}function nt(R,T){let G=!1;R.__webglInit===void 0&&(R.__webglInit=!0,T.addEventListener("dispose",E));const Q=T.source;let se=p.get(Q);se===void 0&&(se={},p.set(Q,se));const j=I(T);if(j!==R.__cacheKey){se[j]===void 0&&(se[j]={texture:i.createTexture(),usedTimes:0},o.memory.textures++,G=!0),se[j].usedTimes++;const De=se[R.__cacheKey];De!==void 0&&(se[R.__cacheKey].usedTimes--,De.usedTimes===0&&y(T)),R.__cacheKey=j,R.__webglTexture=se[j].texture}return G}function Z(R,T,G){let Q=i.TEXTURE_2D;(T.isDataArrayTexture||T.isCompressedArrayTexture)&&(Q=i.TEXTURE_2D_ARRAY),T.isData3DTexture&&(Q=i.TEXTURE_3D);const se=nt(R,T),j=T.source;t.bindTexture(Q,R.__webglTexture,i.TEXTURE0+G);const De=n.get(j);if(j.version!==De.__version||se===!0){t.activeTexture(i.TEXTURE0+G);const ge=vt.getPrimaries(vt.workingColorSpace),be=T.colorSpace===Xr?null:vt.getPrimaries(T.colorSpace),dt=T.colorSpace===Xr||ge===be?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,T.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,T.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,dt);let ce=m(T.image,!1,r.maxTextureSize);ce=Ct(T,ce);const Ee=s.convert(T.format,T.colorSpace),Je=s.convert(T.type);let Qe=M(T.internalFormat,Ee,Je,T.colorSpace,T.isVideoTexture);Ne(Q,T);let Le;const ht=T.mipmaps,lt=T.isVideoTexture!==!0,Bt=De.__version===void 0||se===!0,U=j.dataReady,Me=P(T,ce);if(T.isDepthTexture)Qe=S(T.format===za,T.type),Bt&&(lt?t.texStorage2D(i.TEXTURE_2D,1,Qe,ce.width,ce.height):t.texImage2D(i.TEXTURE_2D,0,Qe,ce.width,ce.height,0,Ee,Je,null));else if(T.isDataTexture)if(ht.length>0){lt&&Bt&&t.texStorage2D(i.TEXTURE_2D,Me,Qe,ht[0].width,ht[0].height);for(let $=0,ne=ht.length;$<ne;$++)Le=ht[$],lt?U&&t.texSubImage2D(i.TEXTURE_2D,$,0,0,Le.width,Le.height,Ee,Je,Le.data):t.texImage2D(i.TEXTURE_2D,$,Qe,Le.width,Le.height,0,Ee,Je,Le.data);T.generateMipmaps=!1}else lt?(Bt&&t.texStorage2D(i.TEXTURE_2D,Me,Qe,ce.width,ce.height),U&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,ce.width,ce.height,Ee,Je,ce.data)):t.texImage2D(i.TEXTURE_2D,0,Qe,ce.width,ce.height,0,Ee,Je,ce.data);else if(T.isCompressedTexture)if(T.isCompressedArrayTexture){lt&&Bt&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Me,Qe,ht[0].width,ht[0].height,ce.depth);for(let $=0,ne=ht.length;$<ne;$++)if(Le=ht[$],T.format!==Ii)if(Ee!==null)if(lt){if(U)if(T.layerUpdates.size>0){const Te=Vm(Le.width,Le.height,T.format,T.type);for(const xe of T.layerUpdates){const rt=Le.data.subarray(xe*Te/Le.data.BYTES_PER_ELEMENT,(xe+1)*Te/Le.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,$,0,0,xe,Le.width,Le.height,1,Ee,rt)}T.clearLayerUpdates()}else t.compressedTexSubImage3D(i.TEXTURE_2D_ARRAY,$,0,0,0,Le.width,Le.height,ce.depth,Ee,Le.data)}else t.compressedTexImage3D(i.TEXTURE_2D_ARRAY,$,Qe,Le.width,Le.height,ce.depth,0,Le.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else lt?U&&t.texSubImage3D(i.TEXTURE_2D_ARRAY,$,0,0,0,Le.width,Le.height,ce.depth,Ee,Je,Le.data):t.texImage3D(i.TEXTURE_2D_ARRAY,$,Qe,Le.width,Le.height,ce.depth,0,Ee,Je,Le.data)}else{lt&&Bt&&t.texStorage2D(i.TEXTURE_2D,Me,Qe,ht[0].width,ht[0].height);for(let $=0,ne=ht.length;$<ne;$++)Le=ht[$],T.format!==Ii?Ee!==null?lt?U&&t.compressedTexSubImage2D(i.TEXTURE_2D,$,0,0,Le.width,Le.height,Ee,Le.data):t.compressedTexImage2D(i.TEXTURE_2D,$,Qe,Le.width,Le.height,0,Le.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):lt?U&&t.texSubImage2D(i.TEXTURE_2D,$,0,0,Le.width,Le.height,Ee,Je,Le.data):t.texImage2D(i.TEXTURE_2D,$,Qe,Le.width,Le.height,0,Ee,Je,Le.data)}else if(T.isDataArrayTexture)if(lt){if(Bt&&t.texStorage3D(i.TEXTURE_2D_ARRAY,Me,Qe,ce.width,ce.height,ce.depth),U)if(T.layerUpdates.size>0){const $=Vm(ce.width,ce.height,T.format,T.type);for(const ne of T.layerUpdates){const Te=ce.data.subarray(ne*$/ce.data.BYTES_PER_ELEMENT,(ne+1)*$/ce.data.BYTES_PER_ELEMENT);t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,ne,ce.width,ce.height,1,Ee,Je,Te)}T.clearLayerUpdates()}else t.texSubImage3D(i.TEXTURE_2D_ARRAY,0,0,0,0,ce.width,ce.height,ce.depth,Ee,Je,ce.data)}else t.texImage3D(i.TEXTURE_2D_ARRAY,0,Qe,ce.width,ce.height,ce.depth,0,Ee,Je,ce.data);else if(T.isData3DTexture)lt?(Bt&&t.texStorage3D(i.TEXTURE_3D,Me,Qe,ce.width,ce.height,ce.depth),U&&t.texSubImage3D(i.TEXTURE_3D,0,0,0,0,ce.width,ce.height,ce.depth,Ee,Je,ce.data)):t.texImage3D(i.TEXTURE_3D,0,Qe,ce.width,ce.height,ce.depth,0,Ee,Je,ce.data);else if(T.isFramebufferTexture){if(Bt)if(lt)t.texStorage2D(i.TEXTURE_2D,Me,Qe,ce.width,ce.height);else{let $=ce.width,ne=ce.height;for(let Te=0;Te<Me;Te++)t.texImage2D(i.TEXTURE_2D,Te,Qe,$,ne,0,Ee,Je,null),$>>=1,ne>>=1}}else if(ht.length>0){if(lt&&Bt){const $=qe(ht[0]);t.texStorage2D(i.TEXTURE_2D,Me,Qe,$.width,$.height)}for(let $=0,ne=ht.length;$<ne;$++)Le=ht[$],lt?U&&t.texSubImage2D(i.TEXTURE_2D,$,0,0,Ee,Je,Le):t.texImage2D(i.TEXTURE_2D,$,Qe,Ee,Je,Le);T.generateMipmaps=!1}else if(lt){if(Bt){const $=qe(ce);t.texStorage2D(i.TEXTURE_2D,Me,Qe,$.width,$.height)}U&&t.texSubImage2D(i.TEXTURE_2D,0,0,0,Ee,Je,ce)}else t.texImage2D(i.TEXTURE_2D,0,Qe,Ee,Je,ce);g(T)&&h(Q),De.__version=j.version,T.onUpdate&&T.onUpdate(T)}R.__version=T.version}function le(R,T,G){if(T.image.length!==6)return;const Q=nt(R,T),se=T.source;t.bindTexture(i.TEXTURE_CUBE_MAP,R.__webglTexture,i.TEXTURE0+G);const j=n.get(se);if(se.version!==j.__version||Q===!0){t.activeTexture(i.TEXTURE0+G);const De=vt.getPrimaries(vt.workingColorSpace),ge=T.colorSpace===Xr?null:vt.getPrimaries(T.colorSpace),be=T.colorSpace===Xr||De===ge?i.NONE:i.BROWSER_DEFAULT_WEBGL;i.pixelStorei(i.UNPACK_FLIP_Y_WEBGL,T.flipY),i.pixelStorei(i.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),i.pixelStorei(i.UNPACK_ALIGNMENT,T.unpackAlignment),i.pixelStorei(i.UNPACK_COLORSPACE_CONVERSION_WEBGL,be);const dt=T.isCompressedTexture||T.image[0].isCompressedTexture,ce=T.image[0]&&T.image[0].isDataTexture,Ee=[];for(let ne=0;ne<6;ne++)!dt&&!ce?Ee[ne]=m(T.image[ne],!0,r.maxCubemapSize):Ee[ne]=ce?T.image[ne].image:T.image[ne],Ee[ne]=Ct(T,Ee[ne]);const Je=Ee[0],Qe=s.convert(T.format,T.colorSpace),Le=s.convert(T.type),ht=M(T.internalFormat,Qe,Le,T.colorSpace),lt=T.isVideoTexture!==!0,Bt=j.__version===void 0||Q===!0,U=se.dataReady;let Me=P(T,Je);Ne(i.TEXTURE_CUBE_MAP,T);let $;if(dt){lt&&Bt&&t.texStorage2D(i.TEXTURE_CUBE_MAP,Me,ht,Je.width,Je.height);for(let ne=0;ne<6;ne++){$=Ee[ne].mipmaps;for(let Te=0;Te<$.length;Te++){const xe=$[Te];T.format!==Ii?Qe!==null?lt?U&&t.compressedTexSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,Te,0,0,xe.width,xe.height,Qe,xe.data):t.compressedTexImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,Te,ht,xe.width,xe.height,0,xe.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):lt?U&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,Te,0,0,xe.width,xe.height,Qe,Le,xe.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,Te,ht,xe.width,xe.height,0,Qe,Le,xe.data)}}}else{if($=T.mipmaps,lt&&Bt){$.length>0&&Me++;const ne=qe(Ee[0]);t.texStorage2D(i.TEXTURE_CUBE_MAP,Me,ht,ne.width,ne.height)}for(let ne=0;ne<6;ne++)if(ce){lt?U&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,0,0,0,Ee[ne].width,Ee[ne].height,Qe,Le,Ee[ne].data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,0,ht,Ee[ne].width,Ee[ne].height,0,Qe,Le,Ee[ne].data);for(let Te=0;Te<$.length;Te++){const rt=$[Te].image[ne].image;lt?U&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,Te+1,0,0,rt.width,rt.height,Qe,Le,rt.data):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,Te+1,ht,rt.width,rt.height,0,Qe,Le,rt.data)}}else{lt?U&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,0,0,0,Qe,Le,Ee[ne]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,0,ht,Qe,Le,Ee[ne]);for(let Te=0;Te<$.length;Te++){const xe=$[Te];lt?U&&t.texSubImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,Te+1,0,0,Qe,Le,xe.image[ne]):t.texImage2D(i.TEXTURE_CUBE_MAP_POSITIVE_X+ne,Te+1,ht,Qe,Le,xe.image[ne])}}}g(T)&&h(i.TEXTURE_CUBE_MAP),j.__version=se.version,T.onUpdate&&T.onUpdate(T)}R.__version=T.version}function Ce(R,T,G,Q,se,j){const De=s.convert(G.format,G.colorSpace),ge=s.convert(G.type),be=M(G.internalFormat,De,ge,G.colorSpace),dt=n.get(T),ce=n.get(G);if(ce.__renderTarget=T,!dt.__hasExternalTextures){const Ee=Math.max(1,T.width>>j),Je=Math.max(1,T.height>>j);se===i.TEXTURE_3D||se===i.TEXTURE_2D_ARRAY?t.texImage3D(se,j,be,Ee,Je,T.depth,0,De,ge,null):t.texImage2D(se,j,be,Ee,Je,0,De,ge,null)}t.bindFramebuffer(i.FRAMEBUFFER,R),Xe(T)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,Q,se,ce.__webglTexture,0,Ve(T)):(se===i.TEXTURE_2D||se>=i.TEXTURE_CUBE_MAP_POSITIVE_X&&se<=i.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&i.framebufferTexture2D(i.FRAMEBUFFER,Q,se,ce.__webglTexture,j),t.bindFramebuffer(i.FRAMEBUFFER,null)}function ue(R,T,G){if(i.bindRenderbuffer(i.RENDERBUFFER,R),T.depthBuffer){const Q=T.depthTexture,se=Q&&Q.isDepthTexture?Q.type:null,j=S(T.stencilBuffer,se),De=T.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,ge=Ve(T);Xe(T)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,ge,j,T.width,T.height):G?i.renderbufferStorageMultisample(i.RENDERBUFFER,ge,j,T.width,T.height):i.renderbufferStorage(i.RENDERBUFFER,j,T.width,T.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,De,i.RENDERBUFFER,R)}else{const Q=T.textures;for(let se=0;se<Q.length;se++){const j=Q[se],De=s.convert(j.format,j.colorSpace),ge=s.convert(j.type),be=M(j.internalFormat,De,ge,j.colorSpace),dt=Ve(T);G&&Xe(T)===!1?i.renderbufferStorageMultisample(i.RENDERBUFFER,dt,be,T.width,T.height):Xe(T)?a.renderbufferStorageMultisampleEXT(i.RENDERBUFFER,dt,be,T.width,T.height):i.renderbufferStorage(i.RENDERBUFFER,be,T.width,T.height)}}i.bindRenderbuffer(i.RENDERBUFFER,null)}function Pe(R,T){if(T&&T.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(i.FRAMEBUFFER,R),!(T.depthTexture&&T.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const Q=n.get(T.depthTexture);Q.__renderTarget=T,(!Q.__webglTexture||T.depthTexture.image.width!==T.width||T.depthTexture.image.height!==T.height)&&(T.depthTexture.image.width=T.width,T.depthTexture.image.height=T.height,T.depthTexture.needsUpdate=!0),J(T.depthTexture,0);const se=Q.__webglTexture,j=Ve(T);if(T.depthTexture.format===Aa)Xe(T)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,se,0,j):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_ATTACHMENT,i.TEXTURE_2D,se,0);else if(T.depthTexture.format===za)Xe(T)?a.framebufferTexture2DMultisampleEXT(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,se,0,j):i.framebufferTexture2D(i.FRAMEBUFFER,i.DEPTH_STENCIL_ATTACHMENT,i.TEXTURE_2D,se,0);else throw new Error("Unknown depthTexture format")}function ze(R){const T=n.get(R),G=R.isWebGLCubeRenderTarget===!0;if(T.__boundDepthTexture!==R.depthTexture){const Q=R.depthTexture;if(T.__depthDisposeCallback&&T.__depthDisposeCallback(),Q){const se=()=>{delete T.__boundDepthTexture,delete T.__depthDisposeCallback,Q.removeEventListener("dispose",se)};Q.addEventListener("dispose",se),T.__depthDisposeCallback=se}T.__boundDepthTexture=Q}if(R.depthTexture&&!T.__autoAllocateDepthBuffer){if(G)throw new Error("target.depthTexture not supported in Cube render targets");Pe(T.__webglFramebuffer,R)}else if(G){T.__webglDepthbuffer=[];for(let Q=0;Q<6;Q++)if(t.bindFramebuffer(i.FRAMEBUFFER,T.__webglFramebuffer[Q]),T.__webglDepthbuffer[Q]===void 0)T.__webglDepthbuffer[Q]=i.createRenderbuffer(),ue(T.__webglDepthbuffer[Q],R,!1);else{const se=R.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,j=T.__webglDepthbuffer[Q];i.bindRenderbuffer(i.RENDERBUFFER,j),i.framebufferRenderbuffer(i.FRAMEBUFFER,se,i.RENDERBUFFER,j)}}else if(t.bindFramebuffer(i.FRAMEBUFFER,T.__webglFramebuffer),T.__webglDepthbuffer===void 0)T.__webglDepthbuffer=i.createRenderbuffer(),ue(T.__webglDepthbuffer,R,!1);else{const Q=R.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,se=T.__webglDepthbuffer;i.bindRenderbuffer(i.RENDERBUFFER,se),i.framebufferRenderbuffer(i.FRAMEBUFFER,Q,i.RENDERBUFFER,se)}t.bindFramebuffer(i.FRAMEBUFFER,null)}function Ze(R,T,G){const Q=n.get(R);T!==void 0&&Ce(Q.__webglFramebuffer,R,R.texture,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,0),G!==void 0&&ze(R)}function wt(R){const T=R.texture,G=n.get(R),Q=n.get(T);R.addEventListener("dispose",A);const se=R.textures,j=R.isWebGLCubeRenderTarget===!0,De=se.length>1;if(De||(Q.__webglTexture===void 0&&(Q.__webglTexture=i.createTexture()),Q.__version=T.version,o.memory.textures++),j){G.__webglFramebuffer=[];for(let ge=0;ge<6;ge++)if(T.mipmaps&&T.mipmaps.length>0){G.__webglFramebuffer[ge]=[];for(let be=0;be<T.mipmaps.length;be++)G.__webglFramebuffer[ge][be]=i.createFramebuffer()}else G.__webglFramebuffer[ge]=i.createFramebuffer()}else{if(T.mipmaps&&T.mipmaps.length>0){G.__webglFramebuffer=[];for(let ge=0;ge<T.mipmaps.length;ge++)G.__webglFramebuffer[ge]=i.createFramebuffer()}else G.__webglFramebuffer=i.createFramebuffer();if(De)for(let ge=0,be=se.length;ge<be;ge++){const dt=n.get(se[ge]);dt.__webglTexture===void 0&&(dt.__webglTexture=i.createTexture(),o.memory.textures++)}if(R.samples>0&&Xe(R)===!1){G.__webglMultisampledFramebuffer=i.createFramebuffer(),G.__webglColorRenderbuffer=[],t.bindFramebuffer(i.FRAMEBUFFER,G.__webglMultisampledFramebuffer);for(let ge=0;ge<se.length;ge++){const be=se[ge];G.__webglColorRenderbuffer[ge]=i.createRenderbuffer(),i.bindRenderbuffer(i.RENDERBUFFER,G.__webglColorRenderbuffer[ge]);const dt=s.convert(be.format,be.colorSpace),ce=s.convert(be.type),Ee=M(be.internalFormat,dt,ce,be.colorSpace,R.isXRRenderTarget===!0),Je=Ve(R);i.renderbufferStorageMultisample(i.RENDERBUFFER,Je,Ee,R.width,R.height),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+ge,i.RENDERBUFFER,G.__webglColorRenderbuffer[ge])}i.bindRenderbuffer(i.RENDERBUFFER,null),R.depthBuffer&&(G.__webglDepthRenderbuffer=i.createRenderbuffer(),ue(G.__webglDepthRenderbuffer,R,!0)),t.bindFramebuffer(i.FRAMEBUFFER,null)}}if(j){t.bindTexture(i.TEXTURE_CUBE_MAP,Q.__webglTexture),Ne(i.TEXTURE_CUBE_MAP,T);for(let ge=0;ge<6;ge++)if(T.mipmaps&&T.mipmaps.length>0)for(let be=0;be<T.mipmaps.length;be++)Ce(G.__webglFramebuffer[ge][be],R,T,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,be);else Ce(G.__webglFramebuffer[ge],R,T,i.COLOR_ATTACHMENT0,i.TEXTURE_CUBE_MAP_POSITIVE_X+ge,0);g(T)&&h(i.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(De){for(let ge=0,be=se.length;ge<be;ge++){const dt=se[ge],ce=n.get(dt);t.bindTexture(i.TEXTURE_2D,ce.__webglTexture),Ne(i.TEXTURE_2D,dt),Ce(G.__webglFramebuffer,R,dt,i.COLOR_ATTACHMENT0+ge,i.TEXTURE_2D,0),g(dt)&&h(i.TEXTURE_2D)}t.unbindTexture()}else{let ge=i.TEXTURE_2D;if((R.isWebGL3DRenderTarget||R.isWebGLArrayRenderTarget)&&(ge=R.isWebGL3DRenderTarget?i.TEXTURE_3D:i.TEXTURE_2D_ARRAY),t.bindTexture(ge,Q.__webglTexture),Ne(ge,T),T.mipmaps&&T.mipmaps.length>0)for(let be=0;be<T.mipmaps.length;be++)Ce(G.__webglFramebuffer[be],R,T,i.COLOR_ATTACHMENT0,ge,be);else Ce(G.__webglFramebuffer,R,T,i.COLOR_ATTACHMENT0,ge,0);g(T)&&h(ge),t.unbindTexture()}R.depthBuffer&&ze(R)}function Oe(R){const T=R.textures;for(let G=0,Q=T.length;G<Q;G++){const se=T[G];if(g(se)){const j=v(R),De=n.get(se).__webglTexture;t.bindTexture(j,De),h(j),t.unbindTexture()}}}const Ht=[],F=[];function Y(R){if(R.samples>0){if(Xe(R)===!1){const T=R.textures,G=R.width,Q=R.height;let se=i.COLOR_BUFFER_BIT;const j=R.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT,De=n.get(R),ge=T.length>1;if(ge)for(let be=0;be<T.length;be++)t.bindFramebuffer(i.FRAMEBUFFER,De.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+be,i.RENDERBUFFER,null),t.bindFramebuffer(i.FRAMEBUFFER,De.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+be,i.TEXTURE_2D,null,0);t.bindFramebuffer(i.READ_FRAMEBUFFER,De.__webglMultisampledFramebuffer),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,De.__webglFramebuffer);for(let be=0;be<T.length;be++){if(R.resolveDepthBuffer&&(R.depthBuffer&&(se|=i.DEPTH_BUFFER_BIT),R.stencilBuffer&&R.resolveStencilBuffer&&(se|=i.STENCIL_BUFFER_BIT)),ge){i.framebufferRenderbuffer(i.READ_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.RENDERBUFFER,De.__webglColorRenderbuffer[be]);const dt=n.get(T[be]).__webglTexture;i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0,i.TEXTURE_2D,dt,0)}i.blitFramebuffer(0,0,G,Q,0,0,G,Q,se,i.NEAREST),l===!0&&(Ht.length=0,F.length=0,Ht.push(i.COLOR_ATTACHMENT0+be),R.depthBuffer&&R.resolveDepthBuffer===!1&&(Ht.push(j),F.push(j),i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,F)),i.invalidateFramebuffer(i.READ_FRAMEBUFFER,Ht))}if(t.bindFramebuffer(i.READ_FRAMEBUFFER,null),t.bindFramebuffer(i.DRAW_FRAMEBUFFER,null),ge)for(let be=0;be<T.length;be++){t.bindFramebuffer(i.FRAMEBUFFER,De.__webglMultisampledFramebuffer),i.framebufferRenderbuffer(i.FRAMEBUFFER,i.COLOR_ATTACHMENT0+be,i.RENDERBUFFER,De.__webglColorRenderbuffer[be]);const dt=n.get(T[be]).__webglTexture;t.bindFramebuffer(i.FRAMEBUFFER,De.__webglFramebuffer),i.framebufferTexture2D(i.DRAW_FRAMEBUFFER,i.COLOR_ATTACHMENT0+be,i.TEXTURE_2D,dt,0)}t.bindFramebuffer(i.DRAW_FRAMEBUFFER,De.__webglMultisampledFramebuffer)}else if(R.depthBuffer&&R.resolveDepthBuffer===!1&&l){const T=R.stencilBuffer?i.DEPTH_STENCIL_ATTACHMENT:i.DEPTH_ATTACHMENT;i.invalidateFramebuffer(i.DRAW_FRAMEBUFFER,[T])}}}function Ve(R){return Math.min(r.maxSamples,R.samples)}function Xe(R){const T=n.get(R);return R.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&T.__useRenderToTexture!==!1}function ee(R){const T=o.render.frame;c.get(R)!==T&&(c.set(R,T),R.update())}function Ct(R,T){const G=R.colorSpace,Q=R.format,se=R.type;return R.isCompressedTexture===!0||R.isVideoTexture===!0||G!==Qa&&G!==Xr&&(vt.getTransfer(G)===Ut?(Q!==Ii||se!==Rr)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",G)),T}function qe(R){return typeof HTMLImageElement<"u"&&R instanceof HTMLImageElement?(u.width=R.naturalWidth||R.width,u.height=R.naturalHeight||R.height):typeof VideoFrame<"u"&&R instanceof VideoFrame?(u.width=R.displayWidth,u.height=R.displayHeight):(u.width=R.width,u.height=R.height),u}this.allocateTextureUnit=D,this.resetTextureUnits=N,this.setTexture2D=J,this.setTexture2DArray=q,this.setTexture3D=oe,this.setTextureCube=X,this.rebindTextures=Ze,this.setupRenderTarget=wt,this.updateRenderTargetMipmap=Oe,this.updateMultisampleRenderTarget=Y,this.setupDepthRenderbuffer=ze,this.setupFrameBufferTexture=Ce,this.useMultisampledRTT=Xe}function Yw(i,e){function t(n,r=Xr){let s;const o=vt.getTransfer(r);if(n===Rr)return i.UNSIGNED_BYTE;if(n===Rh)return i.UNSIGNED_SHORT_4_4_4_4;if(n===Lh)return i.UNSIGNED_SHORT_5_5_5_1;if(n===h_)return i.UNSIGNED_INT_5_9_9_9_REV;if(n===d_)return i.BYTE;if(n===f_)return i.SHORT;if(n===Xo)return i.UNSIGNED_SHORT;if(n===Ch)return i.INT;if(n===Vs)return i.UNSIGNED_INT;if(n===vr)return i.FLOAT;if(n===Tr)return i.HALF_FLOAT;if(n===p_)return i.ALPHA;if(n===m_)return i.RGB;if(n===Ii)return i.RGBA;if(n===g_)return i.LUMINANCE;if(n===__)return i.LUMINANCE_ALPHA;if(n===Aa)return i.DEPTH_COMPONENT;if(n===za)return i.DEPTH_STENCIL;if(n===v_)return i.RED;if(n===Ph)return i.RED_INTEGER;if(n===M_)return i.RG;if(n===Ih)return i.RG_INTEGER;if(n===Dh)return i.RGBA_INTEGER;if(n===$l||n===Zl||n===jl||n===Jl)if(o===Ut)if(s=e.get("WEBGL_compressed_texture_s3tc_srgb"),s!==null){if(n===$l)return s.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Zl)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===jl)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===Jl)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(s=e.get("WEBGL_compressed_texture_s3tc"),s!==null){if(n===$l)return s.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Zl)return s.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===jl)return s.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===Jl)return s.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===df||n===ff||n===hf||n===pf)if(s=e.get("WEBGL_compressed_texture_pvrtc"),s!==null){if(n===df)return s.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===ff)return s.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===hf)return s.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===pf)return s.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===mf||n===gf||n===_f)if(s=e.get("WEBGL_compressed_texture_etc"),s!==null){if(n===mf||n===gf)return o===Ut?s.COMPRESSED_SRGB8_ETC2:s.COMPRESSED_RGB8_ETC2;if(n===_f)return o===Ut?s.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:s.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===vf||n===Mf||n===Sf||n===xf||n===yf||n===Tf||n===bf||n===Ef||n===Af||n===wf||n===Cf||n===Rf||n===Lf||n===Pf)if(s=e.get("WEBGL_compressed_texture_astc"),s!==null){if(n===vf)return o===Ut?s.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:s.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Mf)return o===Ut?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:s.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Sf)return o===Ut?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:s.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===xf)return o===Ut?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:s.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===yf)return o===Ut?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:s.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Tf)return o===Ut?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:s.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===bf)return o===Ut?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:s.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===Ef)return o===Ut?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:s.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===Af)return o===Ut?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:s.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===wf)return o===Ut?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:s.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===Cf)return o===Ut?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:s.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===Rf)return o===Ut?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:s.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===Lf)return o===Ut?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:s.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===Pf)return o===Ut?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:s.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===Ql||n===If||n===Df)if(s=e.get("EXT_texture_compression_bptc"),s!==null){if(n===Ql)return o===Ut?s.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:s.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===If)return s.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Df)return s.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===S_||n===Nf||n===Uf||n===Ff)if(s=e.get("EXT_texture_compression_rgtc"),s!==null){if(n===Ql)return s.COMPRESSED_RED_RGTC1_EXT;if(n===Nf)return s.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Uf)return s.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Ff)return s.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===Ga?i.UNSIGNED_INT_24_8:i[n]!==void 0?i[n]:null}return{convert:t}}class $w extends pi{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}}class Dn extends Gn{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Zw={type:"move"};class td{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Dn,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Dn,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new H,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new H),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Dn,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new H,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new H),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let r=null,s=null,o=null;const a=this._targetRay,l=this._grip,u=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(u&&e.hand){o=!0;for(const m of e.hand.values()){const g=t.getJointPose(m,n),h=this._getHandJoint(u,m);g!==null&&(h.matrix.fromArray(g.transform.matrix),h.matrix.decompose(h.position,h.rotation,h.scale),h.matrixWorldNeedsUpdate=!0,h.jointRadius=g.radius),h.visible=g!==null}const c=u.joints["index-finger-tip"],d=u.joints["thumb-tip"],p=c.position.distanceTo(d.position),f=.02,_=.005;u.inputState.pinching&&p>f+_?(u.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!u.inputState.pinching&&p<=f-_&&(u.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,n),s!==null&&(l.matrix.fromArray(s.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,s.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(s.linearVelocity)):l.hasLinearVelocity=!1,s.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(s.angularVelocity)):l.hasAngularVelocity=!1));a!==null&&(r=t.getPose(e.targetRaySpace,n),r===null&&s!==null&&(r=s),r!==null&&(a.matrix.fromArray(r.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,r.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(r.linearVelocity)):a.hasLinearVelocity=!1,r.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(r.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(Zw)))}return a!==null&&(a.visible=r!==null),l!==null&&(l.visible=s!==null),u!==null&&(u.visible=o!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new Dn;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}const jw=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Jw=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class Qw{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t,n){if(this.texture===null){const r=new Vn,s=e.properties.get(r);s.__webglTexture=t.texture,(t.depthNear!=n.depthNear||t.depthFar!=n.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=r}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new Zn({vertexShader:jw,fragmentShader:Jw,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new je(new Hi(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class eC extends eo{constructor(e,t){super();const n=this;let r=null,s=1,o=null,a="local-floor",l=1,u=null,c=null,d=null,p=null,f=null,_=null;const m=new Qw,g=t.getContextAttributes();let h=null,v=null;const M=[],S=[],P=new tt;let E=null;const A=new pi;A.viewport=new un;const L=new pi;L.viewport=new un;const y=[A,L],x=new $w;let C=null,N=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(Z){let le=M[Z];return le===void 0&&(le=new td,M[Z]=le),le.getTargetRaySpace()},this.getControllerGrip=function(Z){let le=M[Z];return le===void 0&&(le=new td,M[Z]=le),le.getGripSpace()},this.getHand=function(Z){let le=M[Z];return le===void 0&&(le=new td,M[Z]=le),le.getHandSpace()};function D(Z){const le=S.indexOf(Z.inputSource);if(le===-1)return;const Ce=M[le];Ce!==void 0&&(Ce.update(Z.inputSource,Z.frame,u||o),Ce.dispatchEvent({type:Z.type,data:Z.inputSource}))}function I(){r.removeEventListener("select",D),r.removeEventListener("selectstart",D),r.removeEventListener("selectend",D),r.removeEventListener("squeeze",D),r.removeEventListener("squeezestart",D),r.removeEventListener("squeezeend",D),r.removeEventListener("end",I),r.removeEventListener("inputsourceschange",J);for(let Z=0;Z<M.length;Z++){const le=S[Z];le!==null&&(S[Z]=null,M[Z].disconnect(le))}C=null,N=null,m.reset(),e.setRenderTarget(h),f=null,p=null,d=null,r=null,v=null,nt.stop(),n.isPresenting=!1,e.setPixelRatio(E),e.setSize(P.width,P.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(Z){s=Z,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(Z){a=Z,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return u||o},this.setReferenceSpace=function(Z){u=Z},this.getBaseLayer=function(){return p!==null?p:f},this.getBinding=function(){return d},this.getFrame=function(){return _},this.getSession=function(){return r},this.setSession=async function(Z){if(r=Z,r!==null){if(h=e.getRenderTarget(),r.addEventListener("select",D),r.addEventListener("selectstart",D),r.addEventListener("selectend",D),r.addEventListener("squeeze",D),r.addEventListener("squeezestart",D),r.addEventListener("squeezeend",D),r.addEventListener("end",I),r.addEventListener("inputsourceschange",J),g.xrCompatible!==!0&&await t.makeXRCompatible(),E=e.getPixelRatio(),e.getSize(P),r.renderState.layers===void 0){const le={antialias:g.antialias,alpha:!0,depth:g.depth,stencil:g.stencil,framebufferScaleFactor:s};f=new XRWebGLLayer(r,t,le),r.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),v=new Bi(f.framebufferWidth,f.framebufferHeight,{format:Ii,type:Rr,colorSpace:e.outputColorSpace,stencilBuffer:g.stencil})}else{let le=null,Ce=null,ue=null;g.depth&&(ue=g.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,le=g.stencil?za:Aa,Ce=g.stencil?Ga:Vs);const Pe={colorFormat:t.RGBA8,depthFormat:ue,scaleFactor:s};d=new XRWebGLBinding(r,t),p=d.createProjectionLayer(Pe),r.updateRenderState({layers:[p]}),e.setPixelRatio(1),e.setSize(p.textureWidth,p.textureHeight,!1),v=new Bi(p.textureWidth,p.textureHeight,{format:Ii,type:Rr,depthTexture:new U_(p.textureWidth,p.textureHeight,Ce,void 0,void 0,void 0,void 0,void 0,void 0,le),stencilBuffer:g.stencil,colorSpace:e.outputColorSpace,samples:g.antialias?4:0,resolveDepthBuffer:p.ignoreDepthValues===!1})}v.isXRRenderTarget=!0,this.setFoveation(l),u=null,o=await r.requestReferenceSpace(a),nt.setContext(r),nt.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return m.getDepthTexture()};function J(Z){for(let le=0;le<Z.removed.length;le++){const Ce=Z.removed[le],ue=S.indexOf(Ce);ue>=0&&(S[ue]=null,M[ue].disconnect(Ce))}for(let le=0;le<Z.added.length;le++){const Ce=Z.added[le];let ue=S.indexOf(Ce);if(ue===-1){for(let ze=0;ze<M.length;ze++)if(ze>=S.length){S.push(Ce),ue=ze;break}else if(S[ze]===null){S[ze]=Ce,ue=ze;break}if(ue===-1)break}const Pe=M[ue];Pe&&Pe.connect(Ce)}}const q=new H,oe=new H;function X(Z,le,Ce){q.setFromMatrixPosition(le.matrixWorld),oe.setFromMatrixPosition(Ce.matrixWorld);const ue=q.distanceTo(oe),Pe=le.projectionMatrix.elements,ze=Ce.projectionMatrix.elements,Ze=Pe[14]/(Pe[10]-1),wt=Pe[14]/(Pe[10]+1),Oe=(Pe[9]+1)/Pe[5],Ht=(Pe[9]-1)/Pe[5],F=(Pe[8]-1)/Pe[0],Y=(ze[8]+1)/ze[0],Ve=Ze*F,Xe=Ze*Y,ee=ue/(-F+Y),Ct=ee*-F;if(le.matrixWorld.decompose(Z.position,Z.quaternion,Z.scale),Z.translateX(Ct),Z.translateZ(ee),Z.matrixWorld.compose(Z.position,Z.quaternion,Z.scale),Z.matrixWorldInverse.copy(Z.matrixWorld).invert(),Pe[10]===-1)Z.projectionMatrix.copy(le.projectionMatrix),Z.projectionMatrixInverse.copy(le.projectionMatrixInverse);else{const qe=Ze+ee,R=wt+ee,T=Ve-Ct,G=Xe+(ue-Ct),Q=Oe*wt/R*qe,se=Ht*wt/R*qe;Z.projectionMatrix.makePerspective(T,G,Q,se,qe,R),Z.projectionMatrixInverse.copy(Z.projectionMatrix).invert()}}function he(Z,le){le===null?Z.matrixWorld.copy(Z.matrix):Z.matrixWorld.multiplyMatrices(le.matrixWorld,Z.matrix),Z.matrixWorldInverse.copy(Z.matrixWorld).invert()}this.updateCamera=function(Z){if(r===null)return;let le=Z.near,Ce=Z.far;m.texture!==null&&(m.depthNear>0&&(le=m.depthNear),m.depthFar>0&&(Ce=m.depthFar)),x.near=L.near=A.near=le,x.far=L.far=A.far=Ce,(C!==x.near||N!==x.far)&&(r.updateRenderState({depthNear:x.near,depthFar:x.far}),C=x.near,N=x.far),A.layers.mask=Z.layers.mask|2,L.layers.mask=Z.layers.mask|4,x.layers.mask=A.layers.mask|L.layers.mask;const ue=Z.parent,Pe=x.cameras;he(x,ue);for(let ze=0;ze<Pe.length;ze++)he(Pe[ze],ue);Pe.length===2?X(x,A,L):x.projectionMatrix.copy(A.projectionMatrix),pe(Z,x,ue)};function pe(Z,le,Ce){Ce===null?Z.matrix.copy(le.matrixWorld):(Z.matrix.copy(Ce.matrixWorld),Z.matrix.invert(),Z.matrix.multiply(le.matrixWorld)),Z.matrix.decompose(Z.position,Z.quaternion,Z.scale),Z.updateMatrixWorld(!0),Z.projectionMatrix.copy(le.projectionMatrix),Z.projectionMatrixInverse.copy(le.projectionMatrixInverse),Z.isPerspectiveCamera&&(Z.fov=Bf*2*Math.atan(1/Z.projectionMatrix.elements[5]),Z.zoom=1)}this.getCamera=function(){return x},this.getFoveation=function(){if(!(p===null&&f===null))return l},this.setFoveation=function(Z){l=Z,p!==null&&(p.fixedFoveation=Z),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=Z)},this.hasDepthSensing=function(){return m.texture!==null},this.getDepthSensingMesh=function(){return m.getMesh(x)};let Se=null;function Ne(Z,le){if(c=le.getViewerPose(u||o),_=le,c!==null){const Ce=c.views;f!==null&&(e.setRenderTargetFramebuffer(v,f.framebuffer),e.setRenderTarget(v));let ue=!1;Ce.length!==x.cameras.length&&(x.cameras.length=0,ue=!0);for(let ze=0;ze<Ce.length;ze++){const Ze=Ce[ze];let wt=null;if(f!==null)wt=f.getViewport(Ze);else{const Ht=d.getViewSubImage(p,Ze);wt=Ht.viewport,ze===0&&(e.setRenderTargetTextures(v,Ht.colorTexture,p.ignoreDepthValues?void 0:Ht.depthStencilTexture),e.setRenderTarget(v))}let Oe=y[ze];Oe===void 0&&(Oe=new pi,Oe.layers.enable(ze),Oe.viewport=new un,y[ze]=Oe),Oe.matrix.fromArray(Ze.transform.matrix),Oe.matrix.decompose(Oe.position,Oe.quaternion,Oe.scale),Oe.projectionMatrix.fromArray(Ze.projectionMatrix),Oe.projectionMatrixInverse.copy(Oe.projectionMatrix).invert(),Oe.viewport.set(wt.x,wt.y,wt.width,wt.height),ze===0&&(x.matrix.copy(Oe.matrix),x.matrix.decompose(x.position,x.quaternion,x.scale)),ue===!0&&x.cameras.push(Oe)}const Pe=r.enabledFeatures;if(Pe&&Pe.includes("depth-sensing")){const ze=d.getDepthInformation(Ce[0]);ze&&ze.isValid&&ze.texture&&m.init(e,ze,r.renderState)}}for(let Ce=0;Ce<M.length;Ce++){const ue=S[Ce],Pe=M[Ce];ue!==null&&Pe!==void 0&&Pe.update(ue,le,u||o)}Se&&Se(Z,le),le.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:le}),_=null}const nt=new D_;nt.setAnimationLoop(Ne),this.setAnimationLoop=function(Z){Se=Z},this.dispose=function(){}}}const _s=new Lr,tC=new rn;function nC(i,e){function t(g,h){g.matrixAutoUpdate===!0&&g.updateMatrix(),h.value.copy(g.matrix)}function n(g,h){h.color.getRGB(g.fogColor.value,R_(i)),h.isFog?(g.fogNear.value=h.near,g.fogFar.value=h.far):h.isFogExp2&&(g.fogDensity.value=h.density)}function r(g,h,v,M,S){h.isMeshBasicMaterial||h.isMeshLambertMaterial?s(g,h):h.isMeshToonMaterial?(s(g,h),d(g,h)):h.isMeshPhongMaterial?(s(g,h),c(g,h)):h.isMeshStandardMaterial?(s(g,h),p(g,h),h.isMeshPhysicalMaterial&&f(g,h,S)):h.isMeshMatcapMaterial?(s(g,h),_(g,h)):h.isMeshDepthMaterial?s(g,h):h.isMeshDistanceMaterial?(s(g,h),m(g,h)):h.isMeshNormalMaterial?s(g,h):h.isLineBasicMaterial?(o(g,h),h.isLineDashedMaterial&&a(g,h)):h.isPointsMaterial?l(g,h,v,M):h.isSpriteMaterial?u(g,h):h.isShadowMaterial?(g.color.value.copy(h.color),g.opacity.value=h.opacity):h.isShaderMaterial&&(h.uniformsNeedUpdate=!1)}function s(g,h){g.opacity.value=h.opacity,h.color&&g.diffuse.value.copy(h.color),h.emissive&&g.emissive.value.copy(h.emissive).multiplyScalar(h.emissiveIntensity),h.map&&(g.map.value=h.map,t(h.map,g.mapTransform)),h.alphaMap&&(g.alphaMap.value=h.alphaMap,t(h.alphaMap,g.alphaMapTransform)),h.bumpMap&&(g.bumpMap.value=h.bumpMap,t(h.bumpMap,g.bumpMapTransform),g.bumpScale.value=h.bumpScale,h.side===Jn&&(g.bumpScale.value*=-1)),h.normalMap&&(g.normalMap.value=h.normalMap,t(h.normalMap,g.normalMapTransform),g.normalScale.value.copy(h.normalScale),h.side===Jn&&g.normalScale.value.negate()),h.displacementMap&&(g.displacementMap.value=h.displacementMap,t(h.displacementMap,g.displacementMapTransform),g.displacementScale.value=h.displacementScale,g.displacementBias.value=h.displacementBias),h.emissiveMap&&(g.emissiveMap.value=h.emissiveMap,t(h.emissiveMap,g.emissiveMapTransform)),h.specularMap&&(g.specularMap.value=h.specularMap,t(h.specularMap,g.specularMapTransform)),h.alphaTest>0&&(g.alphaTest.value=h.alphaTest);const v=e.get(h),M=v.envMap,S=v.envMapRotation;M&&(g.envMap.value=M,_s.copy(S),_s.x*=-1,_s.y*=-1,_s.z*=-1,M.isCubeTexture&&M.isRenderTargetTexture===!1&&(_s.y*=-1,_s.z*=-1),g.envMapRotation.value.setFromMatrix4(tC.makeRotationFromEuler(_s)),g.flipEnvMap.value=M.isCubeTexture&&M.isRenderTargetTexture===!1?-1:1,g.reflectivity.value=h.reflectivity,g.ior.value=h.ior,g.refractionRatio.value=h.refractionRatio),h.lightMap&&(g.lightMap.value=h.lightMap,g.lightMapIntensity.value=h.lightMapIntensity,t(h.lightMap,g.lightMapTransform)),h.aoMap&&(g.aoMap.value=h.aoMap,g.aoMapIntensity.value=h.aoMapIntensity,t(h.aoMap,g.aoMapTransform))}function o(g,h){g.diffuse.value.copy(h.color),g.opacity.value=h.opacity,h.map&&(g.map.value=h.map,t(h.map,g.mapTransform))}function a(g,h){g.dashSize.value=h.dashSize,g.totalSize.value=h.dashSize+h.gapSize,g.scale.value=h.scale}function l(g,h,v,M){g.diffuse.value.copy(h.color),g.opacity.value=h.opacity,g.size.value=h.size*v,g.scale.value=M*.5,h.map&&(g.map.value=h.map,t(h.map,g.uvTransform)),h.alphaMap&&(g.alphaMap.value=h.alphaMap,t(h.alphaMap,g.alphaMapTransform)),h.alphaTest>0&&(g.alphaTest.value=h.alphaTest)}function u(g,h){g.diffuse.value.copy(h.color),g.opacity.value=h.opacity,g.rotation.value=h.rotation,h.map&&(g.map.value=h.map,t(h.map,g.mapTransform)),h.alphaMap&&(g.alphaMap.value=h.alphaMap,t(h.alphaMap,g.alphaMapTransform)),h.alphaTest>0&&(g.alphaTest.value=h.alphaTest)}function c(g,h){g.specular.value.copy(h.specular),g.shininess.value=Math.max(h.shininess,1e-4)}function d(g,h){h.gradientMap&&(g.gradientMap.value=h.gradientMap)}function p(g,h){g.metalness.value=h.metalness,h.metalnessMap&&(g.metalnessMap.value=h.metalnessMap,t(h.metalnessMap,g.metalnessMapTransform)),g.roughness.value=h.roughness,h.roughnessMap&&(g.roughnessMap.value=h.roughnessMap,t(h.roughnessMap,g.roughnessMapTransform)),h.envMap&&(g.envMapIntensity.value=h.envMapIntensity)}function f(g,h,v){g.ior.value=h.ior,h.sheen>0&&(g.sheenColor.value.copy(h.sheenColor).multiplyScalar(h.sheen),g.sheenRoughness.value=h.sheenRoughness,h.sheenColorMap&&(g.sheenColorMap.value=h.sheenColorMap,t(h.sheenColorMap,g.sheenColorMapTransform)),h.sheenRoughnessMap&&(g.sheenRoughnessMap.value=h.sheenRoughnessMap,t(h.sheenRoughnessMap,g.sheenRoughnessMapTransform))),h.clearcoat>0&&(g.clearcoat.value=h.clearcoat,g.clearcoatRoughness.value=h.clearcoatRoughness,h.clearcoatMap&&(g.clearcoatMap.value=h.clearcoatMap,t(h.clearcoatMap,g.clearcoatMapTransform)),h.clearcoatRoughnessMap&&(g.clearcoatRoughnessMap.value=h.clearcoatRoughnessMap,t(h.clearcoatRoughnessMap,g.clearcoatRoughnessMapTransform)),h.clearcoatNormalMap&&(g.clearcoatNormalMap.value=h.clearcoatNormalMap,t(h.clearcoatNormalMap,g.clearcoatNormalMapTransform),g.clearcoatNormalScale.value.copy(h.clearcoatNormalScale),h.side===Jn&&g.clearcoatNormalScale.value.negate())),h.dispersion>0&&(g.dispersion.value=h.dispersion),h.iridescence>0&&(g.iridescence.value=h.iridescence,g.iridescenceIOR.value=h.iridescenceIOR,g.iridescenceThicknessMinimum.value=h.iridescenceThicknessRange[0],g.iridescenceThicknessMaximum.value=h.iridescenceThicknessRange[1],h.iridescenceMap&&(g.iridescenceMap.value=h.iridescenceMap,t(h.iridescenceMap,g.iridescenceMapTransform)),h.iridescenceThicknessMap&&(g.iridescenceThicknessMap.value=h.iridescenceThicknessMap,t(h.iridescenceThicknessMap,g.iridescenceThicknessMapTransform))),h.transmission>0&&(g.transmission.value=h.transmission,g.transmissionSamplerMap.value=v.texture,g.transmissionSamplerSize.value.set(v.width,v.height),h.transmissionMap&&(g.transmissionMap.value=h.transmissionMap,t(h.transmissionMap,g.transmissionMapTransform)),g.thickness.value=h.thickness,h.thicknessMap&&(g.thicknessMap.value=h.thicknessMap,t(h.thicknessMap,g.thicknessMapTransform)),g.attenuationDistance.value=h.attenuationDistance,g.attenuationColor.value.copy(h.attenuationColor)),h.anisotropy>0&&(g.anisotropyVector.value.set(h.anisotropy*Math.cos(h.anisotropyRotation),h.anisotropy*Math.sin(h.anisotropyRotation)),h.anisotropyMap&&(g.anisotropyMap.value=h.anisotropyMap,t(h.anisotropyMap,g.anisotropyMapTransform))),g.specularIntensity.value=h.specularIntensity,g.specularColor.value.copy(h.specularColor),h.specularColorMap&&(g.specularColorMap.value=h.specularColorMap,t(h.specularColorMap,g.specularColorMapTransform)),h.specularIntensityMap&&(g.specularIntensityMap.value=h.specularIntensityMap,t(h.specularIntensityMap,g.specularIntensityMapTransform))}function _(g,h){h.matcap&&(g.matcap.value=h.matcap)}function m(g,h){const v=e.get(h).light;g.referencePosition.value.setFromMatrixPosition(v.matrixWorld),g.nearDistance.value=v.shadow.camera.near,g.farDistance.value=v.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:r}}function iC(i,e,t,n){let r={},s={},o=[];const a=i.getParameter(i.MAX_UNIFORM_BUFFER_BINDINGS);function l(v,M){const S=M.program;n.uniformBlockBinding(v,S)}function u(v,M){let S=r[v.id];S===void 0&&(_(v),S=c(v),r[v.id]=S,v.addEventListener("dispose",g));const P=M.program;n.updateUBOMapping(v,P);const E=e.render.frame;s[v.id]!==E&&(p(v),s[v.id]=E)}function c(v){const M=d();v.__bindingPointIndex=M;const S=i.createBuffer(),P=v.__size,E=v.usage;return i.bindBuffer(i.UNIFORM_BUFFER,S),i.bufferData(i.UNIFORM_BUFFER,P,E),i.bindBuffer(i.UNIFORM_BUFFER,null),i.bindBufferBase(i.UNIFORM_BUFFER,M,S),S}function d(){for(let v=0;v<a;v++)if(o.indexOf(v)===-1)return o.push(v),v;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function p(v){const M=r[v.id],S=v.uniforms,P=v.__cache;i.bindBuffer(i.UNIFORM_BUFFER,M);for(let E=0,A=S.length;E<A;E++){const L=Array.isArray(S[E])?S[E]:[S[E]];for(let y=0,x=L.length;y<x;y++){const C=L[y];if(f(C,E,y,P)===!0){const N=C.__offset,D=Array.isArray(C.value)?C.value:[C.value];let I=0;for(let J=0;J<D.length;J++){const q=D[J],oe=m(q);typeof q=="number"||typeof q=="boolean"?(C.__data[0]=q,i.bufferSubData(i.UNIFORM_BUFFER,N+I,C.__data)):q.isMatrix3?(C.__data[0]=q.elements[0],C.__data[1]=q.elements[1],C.__data[2]=q.elements[2],C.__data[3]=0,C.__data[4]=q.elements[3],C.__data[5]=q.elements[4],C.__data[6]=q.elements[5],C.__data[7]=0,C.__data[8]=q.elements[6],C.__data[9]=q.elements[7],C.__data[10]=q.elements[8],C.__data[11]=0):(q.toArray(C.__data,I),I+=oe.storage/Float32Array.BYTES_PER_ELEMENT)}i.bufferSubData(i.UNIFORM_BUFFER,N,C.__data)}}}i.bindBuffer(i.UNIFORM_BUFFER,null)}function f(v,M,S,P){const E=v.value,A=M+"_"+S;if(P[A]===void 0)return typeof E=="number"||typeof E=="boolean"?P[A]=E:P[A]=E.clone(),!0;{const L=P[A];if(typeof E=="number"||typeof E=="boolean"){if(L!==E)return P[A]=E,!0}else if(L.equals(E)===!1)return L.copy(E),!0}return!1}function _(v){const M=v.uniforms;let S=0;const P=16;for(let A=0,L=M.length;A<L;A++){const y=Array.isArray(M[A])?M[A]:[M[A]];for(let x=0,C=y.length;x<C;x++){const N=y[x],D=Array.isArray(N.value)?N.value:[N.value];for(let I=0,J=D.length;I<J;I++){const q=D[I],oe=m(q),X=S%P,he=X%oe.boundary,pe=X+he;S+=he,pe!==0&&P-pe<oe.storage&&(S+=P-pe),N.__data=new Float32Array(oe.storage/Float32Array.BYTES_PER_ELEMENT),N.__offset=S,S+=oe.storage}}}const E=S%P;return E>0&&(S+=P-E),v.__size=S,v.__cache={},this}function m(v){const M={boundary:0,storage:0};return typeof v=="number"||typeof v=="boolean"?(M.boundary=4,M.storage=4):v.isVector2?(M.boundary=8,M.storage=8):v.isVector3||v.isColor?(M.boundary=16,M.storage=12):v.isVector4?(M.boundary=16,M.storage=16):v.isMatrix3?(M.boundary=48,M.storage=48):v.isMatrix4?(M.boundary=64,M.storage=64):v.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",v),M}function g(v){const M=v.target;M.removeEventListener("dispose",g);const S=o.indexOf(M.__bindingPointIndex);o.splice(S,1),i.deleteBuffer(r[M.id]),delete r[M.id],delete s[M.id]}function h(){for(const v in r)i.deleteBuffer(r[v]);o=[],r={},s={}}return{bind:l,update:u,dispose:h}}class rC{constructor(e={}){const{canvas:t=qy(),context:n=null,depth:r=!0,stencil:s=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:u=!1,powerPreference:c="default",failIfMajorPerformanceCaveat:d=!1,reverseDepthBuffer:p=!1}=e;this.isWebGLRenderer=!0;let f;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");f=n.getContextAttributes().alpha}else f=o;const _=new Uint32Array(4),m=new Int32Array(4);let g=null,h=null;const v=[],M=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=ni,this.toneMapping=jr,this.toneMappingExposure=1;const S=this;let P=!1,E=0,A=0,L=null,y=-1,x=null;const C=new un,N=new un;let D=null;const I=new pt(0);let J=0,q=t.width,oe=t.height,X=1,he=null,pe=null;const Se=new un(0,0,q,oe),Ne=new un(0,0,q,oe);let nt=!1;const Z=new I_;let le=!1,Ce=!1;const ue=new rn,Pe=new rn,ze=new H,Ze=new un,wt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Oe=!1;function Ht(){return L===null?X:1}let F=n;function Y(b,B){return t.getContext(b,B)}try{const b={alpha:!0,depth:r,stencil:s,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:u,powerPreference:c,failIfMajorPerformanceCaveat:d};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${wh}`),t.addEventListener("webglcontextlost",ne,!1),t.addEventListener("webglcontextrestored",Te,!1),t.addEventListener("webglcontextcreationerror",xe,!1),F===null){const B="webgl2";if(F=Y(B,b),F===null)throw Y(B)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(b){throw console.error("THREE.WebGLRenderer: "+b.message),b}let Ve,Xe,ee,Ct,qe,R,T,G,Q,se,j,De,ge,be,dt,ce,Ee,Je,Qe,Le,ht,lt,Bt,U;function Me(){Ve=new cA(F),Ve.init(),lt=new Yw(F,Ve),Xe=new iA(F,Ve,e,lt),ee=new Kw(F,Ve),Xe.reverseDepthBuffer&&p&&ee.buffers.depth.setReversed(!0),Ct=new fA(F),qe=new Lw,R=new qw(F,Ve,ee,qe,Xe,lt,Ct),T=new sA(S),G=new lA(S),Q=new MT(F),Bt=new tA(F,Q),se=new uA(F,Q,Ct,Bt),j=new pA(F,se,Q,Ct),Qe=new hA(F,Xe,R),ce=new rA(qe),De=new Rw(S,T,G,Ve,Xe,Bt,ce),ge=new nC(S,qe),be=new Iw,dt=new Ow(Ve),Je=new eA(S,T,G,ee,j,f,l),Ee=new zw(S,j,Xe),U=new iC(F,Ct,Xe,ee),Le=new nA(F,Ve,Ct),ht=new dA(F,Ve,Ct),Ct.programs=De.programs,S.capabilities=Xe,S.extensions=Ve,S.properties=qe,S.renderLists=be,S.shadowMap=Ee,S.state=ee,S.info=Ct}Me();const $=new eC(S,F);this.xr=$,this.getContext=function(){return F},this.getContextAttributes=function(){return F.getContextAttributes()},this.forceContextLoss=function(){const b=Ve.get("WEBGL_lose_context");b&&b.loseContext()},this.forceContextRestore=function(){const b=Ve.get("WEBGL_lose_context");b&&b.restoreContext()},this.getPixelRatio=function(){return X},this.setPixelRatio=function(b){b!==void 0&&(X=b,this.setSize(q,oe,!1))},this.getSize=function(b){return b.set(q,oe)},this.setSize=function(b,B,W=!0){if($.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}q=b,oe=B,t.width=Math.floor(b*X),t.height=Math.floor(B*X),W===!0&&(t.style.width=b+"px",t.style.height=B+"px"),this.setViewport(0,0,b,B)},this.getDrawingBufferSize=function(b){return b.set(q*X,oe*X).floor()},this.setDrawingBufferSize=function(b,B,W){q=b,oe=B,X=W,t.width=Math.floor(b*W),t.height=Math.floor(B*W),this.setViewport(0,0,b,B)},this.getCurrentViewport=function(b){return b.copy(C)},this.getViewport=function(b){return b.copy(Se)},this.setViewport=function(b,B,W,K){b.isVector4?Se.set(b.x,b.y,b.z,b.w):Se.set(b,B,W,K),ee.viewport(C.copy(Se).multiplyScalar(X).round())},this.getScissor=function(b){return b.copy(Ne)},this.setScissor=function(b,B,W,K){b.isVector4?Ne.set(b.x,b.y,b.z,b.w):Ne.set(b,B,W,K),ee.scissor(N.copy(Ne).multiplyScalar(X).round())},this.getScissorTest=function(){return nt},this.setScissorTest=function(b){ee.setScissorTest(nt=b)},this.setOpaqueSort=function(b){he=b},this.setTransparentSort=function(b){pe=b},this.getClearColor=function(b){return b.copy(Je.getClearColor())},this.setClearColor=function(){Je.setClearColor.apply(Je,arguments)},this.getClearAlpha=function(){return Je.getClearAlpha()},this.setClearAlpha=function(){Je.setClearAlpha.apply(Je,arguments)},this.clear=function(b=!0,B=!0,W=!0){let K=0;if(b){let O=!1;if(L!==null){const de=L.texture.format;O=de===Dh||de===Ih||de===Ph}if(O){const de=L.texture.type,ye=de===Rr||de===Vs||de===Xo||de===Ga||de===Rh||de===Lh,Ue=Je.getClearColor(),Fe=Je.getClearAlpha(),et=Ue.r,st=Ue.g,Be=Ue.b;ye?(_[0]=et,_[1]=st,_[2]=Be,_[3]=Fe,F.clearBufferuiv(F.COLOR,0,_)):(m[0]=et,m[1]=st,m[2]=Be,m[3]=Fe,F.clearBufferiv(F.COLOR,0,m))}else K|=F.COLOR_BUFFER_BIT}B&&(K|=F.DEPTH_BUFFER_BIT),W&&(K|=F.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),F.clear(K)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",ne,!1),t.removeEventListener("webglcontextrestored",Te,!1),t.removeEventListener("webglcontextcreationerror",xe,!1),be.dispose(),dt.dispose(),qe.dispose(),T.dispose(),G.dispose(),j.dispose(),Bt.dispose(),U.dispose(),De.dispose(),$.dispose(),$.removeEventListener("sessionstart",ep),$.removeEventListener("sessionend",tp),us.stop()};function ne(b){b.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),P=!0}function Te(){console.log("THREE.WebGLRenderer: Context Restored."),P=!1;const b=Ct.autoReset,B=Ee.enabled,W=Ee.autoUpdate,K=Ee.needsUpdate,O=Ee.type;Me(),Ct.autoReset=b,Ee.enabled=B,Ee.autoUpdate=W,Ee.needsUpdate=K,Ee.type=O}function xe(b){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",b.statusMessage)}function rt(b){const B=b.target;B.removeEventListener("dispose",rt),Qt(B)}function Qt(b){Cn(b),qe.remove(b)}function Cn(b){const B=qe.get(b).programs;B!==void 0&&(B.forEach(function(W){De.releaseProgram(W)}),b.isShaderMaterial&&De.releaseShaderCache(b))}this.renderBufferDirect=function(b,B,W,K,O,de){B===null&&(B=wt);const ye=O.isMesh&&O.matrixWorld.determinant()<0,Ue=Kv(b,B,W,K,O);ee.setMaterial(K,ye);let Fe=W.index,et=1;if(K.wireframe===!0){if(Fe=se.getWireframeAttribute(W),Fe===void 0)return;et=2}const st=W.drawRange,Be=W.attributes.position;let St=st.start*et,Ot=(st.start+st.count)*et;de!==null&&(St=Math.max(St,de.start*et),Ot=Math.min(Ot,(de.start+de.count)*et)),Fe!==null?(St=Math.max(St,0),Ot=Math.min(Ot,Fe.count)):Be!=null&&(St=Math.max(St,0),Ot=Math.min(Ot,Be.count));const Vt=Ot-St;if(Vt<0||Vt===1/0)return;Bt.setup(O,K,Ue,W,Fe);let Wn,bt=Le;if(Fe!==null&&(Wn=Q.get(Fe),bt=ht,bt.setIndex(Wn)),O.isMesh)K.wireframe===!0?(ee.setLineWidth(K.wireframeLinewidth*Ht()),bt.setMode(F.LINES)):bt.setMode(F.TRIANGLES);else if(O.isLine){let He=K.linewidth;He===void 0&&(He=1),ee.setLineWidth(He*Ht()),O.isLineSegments?bt.setMode(F.LINES):O.isLineLoop?bt.setMode(F.LINE_LOOP):bt.setMode(F.LINE_STRIP)}else O.isPoints?bt.setMode(F.POINTS):O.isSprite&&bt.setMode(F.TRIANGLES);if(O.isBatchedMesh)if(O._multiDrawInstances!==null)bt.renderMultiDrawInstances(O._multiDrawStarts,O._multiDrawCounts,O._multiDrawCount,O._multiDrawInstances);else if(Ve.get("WEBGL_multi_draw"))bt.renderMultiDraw(O._multiDrawStarts,O._multiDrawCounts,O._multiDrawCount);else{const He=O._multiDrawStarts,sr=O._multiDrawCounts,Et=O._multiDrawCount,bi=Fe?Q.get(Fe).bytesPerElement:1,Zs=qe.get(K).currentProgram.getUniforms();for(let Qn=0;Qn<Et;Qn++)Zs.setValue(F,"_gl_DrawID",Qn),bt.render(He[Qn]/bi,sr[Qn])}else if(O.isInstancedMesh)bt.renderInstances(St,Vt,O.count);else if(W.isInstancedBufferGeometry){const He=W._maxInstanceCount!==void 0?W._maxInstanceCount:1/0,sr=Math.min(W.instanceCount,He);bt.renderInstances(St,Vt,sr)}else bt.render(St,Vt)};function Rt(b,B,W){b.transparent===!0&&b.side===Qi&&b.forceSinglePass===!1?(b.side=Jn,b.needsUpdate=!0,ul(b,B,W),b.side=rs,b.needsUpdate=!0,ul(b,B,W),b.side=Qi):ul(b,B,W)}this.compile=function(b,B,W=null){W===null&&(W=b),h=dt.get(W),h.init(B),M.push(h),W.traverseVisible(function(O){O.isLight&&O.layers.test(B.layers)&&(h.pushLight(O),O.castShadow&&h.pushShadow(O))}),b!==W&&b.traverseVisible(function(O){O.isLight&&O.layers.test(B.layers)&&(h.pushLight(O),O.castShadow&&h.pushShadow(O))}),h.setupLights();const K=new Set;return b.traverse(function(O){if(!(O.isMesh||O.isPoints||O.isLine||O.isSprite))return;const de=O.material;if(de)if(Array.isArray(de))for(let ye=0;ye<de.length;ye++){const Ue=de[ye];Rt(Ue,W,O),K.add(Ue)}else Rt(de,W,O),K.add(de)}),M.pop(),h=null,K},this.compileAsync=function(b,B,W=null){const K=this.compile(b,B,W);return new Promise(O=>{function de(){if(K.forEach(function(ye){qe.get(ye).currentProgram.isReady()&&K.delete(ye)}),K.size===0){O(b);return}setTimeout(de,10)}Ve.get("KHR_parallel_shader_compile")!==null?de():setTimeout(de,10)})};let Ti=null;function rr(b){Ti&&Ti(b)}function ep(){us.stop()}function tp(){us.start()}const us=new D_;us.setAnimationLoop(rr),typeof self<"u"&&us.setContext(self),this.setAnimationLoop=function(b){Ti=b,$.setAnimationLoop(b),b===null?us.stop():us.start()},$.addEventListener("sessionstart",ep),$.addEventListener("sessionend",tp),this.render=function(b,B){if(B!==void 0&&B.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(P===!0)return;if(b.matrixWorldAutoUpdate===!0&&b.updateMatrixWorld(),B.parent===null&&B.matrixWorldAutoUpdate===!0&&B.updateMatrixWorld(),$.enabled===!0&&$.isPresenting===!0&&($.cameraAutoUpdate===!0&&$.updateCamera(B),B=$.getCamera()),b.isScene===!0&&b.onBeforeRender(S,b,B,L),h=dt.get(b,M.length),h.init(B),M.push(h),Pe.multiplyMatrices(B.projectionMatrix,B.matrixWorldInverse),Z.setFromProjectionMatrix(Pe),Ce=this.localClippingEnabled,le=ce.init(this.clippingPlanes,Ce),g=be.get(b,v.length),g.init(),v.push(g),$.enabled===!0&&$.isPresenting===!0){const de=S.xr.getDepthSensingMesh();de!==null&&pu(de,B,-1/0,S.sortObjects)}pu(b,B,0,S.sortObjects),g.finish(),S.sortObjects===!0&&g.sort(he,pe),Oe=$.enabled===!1||$.isPresenting===!1||$.hasDepthSensing()===!1,Oe&&Je.addToRenderList(g,b),this.info.render.frame++,le===!0&&ce.beginShadows();const W=h.state.shadowsArray;Ee.render(W,b,B),le===!0&&ce.endShadows(),this.info.autoReset===!0&&this.info.reset();const K=g.opaque,O=g.transmissive;if(h.setupLights(),B.isArrayCamera){const de=B.cameras;if(O.length>0)for(let ye=0,Ue=de.length;ye<Ue;ye++){const Fe=de[ye];ip(K,O,b,Fe)}Oe&&Je.render(b);for(let ye=0,Ue=de.length;ye<Ue;ye++){const Fe=de[ye];np(g,b,Fe,Fe.viewport)}}else O.length>0&&ip(K,O,b,B),Oe&&Je.render(b),np(g,b,B);L!==null&&(R.updateMultisampleRenderTarget(L),R.updateRenderTargetMipmap(L)),b.isScene===!0&&b.onAfterRender(S,b,B),Bt.resetDefaultState(),y=-1,x=null,M.pop(),M.length>0?(h=M[M.length-1],le===!0&&ce.setGlobalState(S.clippingPlanes,h.state.camera)):h=null,v.pop(),v.length>0?g=v[v.length-1]:g=null};function pu(b,B,W,K){if(b.visible===!1)return;if(b.layers.test(B.layers)){if(b.isGroup)W=b.renderOrder;else if(b.isLOD)b.autoUpdate===!0&&b.update(B);else if(b.isLight)h.pushLight(b),b.castShadow&&h.pushShadow(b);else if(b.isSprite){if(!b.frustumCulled||Z.intersectsSprite(b)){K&&Ze.setFromMatrixPosition(b.matrixWorld).applyMatrix4(Pe);const ye=j.update(b),Ue=b.material;Ue.visible&&g.push(b,ye,Ue,W,Ze.z,null)}}else if((b.isMesh||b.isLine||b.isPoints)&&(!b.frustumCulled||Z.intersectsObject(b))){const ye=j.update(b),Ue=b.material;if(K&&(b.boundingSphere!==void 0?(b.boundingSphere===null&&b.computeBoundingSphere(),Ze.copy(b.boundingSphere.center)):(ye.boundingSphere===null&&ye.computeBoundingSphere(),Ze.copy(ye.boundingSphere.center)),Ze.applyMatrix4(b.matrixWorld).applyMatrix4(Pe)),Array.isArray(Ue)){const Fe=ye.groups;for(let et=0,st=Fe.length;et<st;et++){const Be=Fe[et],St=Ue[Be.materialIndex];St&&St.visible&&g.push(b,ye,St,W,Ze.z,Be)}}else Ue.visible&&g.push(b,ye,Ue,W,Ze.z,null)}}const de=b.children;for(let ye=0,Ue=de.length;ye<Ue;ye++)pu(de[ye],B,W,K)}function np(b,B,W,K){const O=b.opaque,de=b.transmissive,ye=b.transparent;h.setupLightsView(W),le===!0&&ce.setGlobalState(S.clippingPlanes,W),K&&ee.viewport(C.copy(K)),O.length>0&&cl(O,B,W),de.length>0&&cl(de,B,W),ye.length>0&&cl(ye,B,W),ee.buffers.depth.setTest(!0),ee.buffers.depth.setMask(!0),ee.buffers.color.setMask(!0),ee.setPolygonOffset(!1)}function ip(b,B,W,K){if((W.isScene===!0?W.overrideMaterial:null)!==null)return;h.state.transmissionRenderTarget[K.id]===void 0&&(h.state.transmissionRenderTarget[K.id]=new Bi(1,1,{generateMipmaps:!0,type:Ve.has("EXT_color_buffer_half_float")||Ve.has("EXT_color_buffer_float")?Tr:Rr,minFilter:Cs,samples:4,stencilBuffer:s,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:vt.workingColorSpace}));const de=h.state.transmissionRenderTarget[K.id],ye=K.viewport||C;de.setSize(ye.z,ye.w);const Ue=S.getRenderTarget();S.setRenderTarget(de),S.getClearColor(I),J=S.getClearAlpha(),J<1&&S.setClearColor(16777215,.5),S.clear(),Oe&&Je.render(W);const Fe=S.toneMapping;S.toneMapping=jr;const et=K.viewport;if(K.viewport!==void 0&&(K.viewport=void 0),h.setupLightsView(K),le===!0&&ce.setGlobalState(S.clippingPlanes,K),cl(b,W,K),R.updateMultisampleRenderTarget(de),R.updateRenderTargetMipmap(de),Ve.has("WEBGL_multisampled_render_to_texture")===!1){let st=!1;for(let Be=0,St=B.length;Be<St;Be++){const Ot=B[Be],Vt=Ot.object,Wn=Ot.geometry,bt=Ot.material,He=Ot.group;if(bt.side===Qi&&Vt.layers.test(K.layers)){const sr=bt.side;bt.side=Jn,bt.needsUpdate=!0,rp(Vt,W,K,Wn,bt,He),bt.side=sr,bt.needsUpdate=!0,st=!0}}st===!0&&(R.updateMultisampleRenderTarget(de),R.updateRenderTargetMipmap(de))}S.setRenderTarget(Ue),S.setClearColor(I,J),et!==void 0&&(K.viewport=et),S.toneMapping=Fe}function cl(b,B,W){const K=B.isScene===!0?B.overrideMaterial:null;for(let O=0,de=b.length;O<de;O++){const ye=b[O],Ue=ye.object,Fe=ye.geometry,et=K===null?ye.material:K,st=ye.group;Ue.layers.test(W.layers)&&rp(Ue,B,W,Fe,et,st)}}function rp(b,B,W,K,O,de){b.onBeforeRender(S,B,W,K,O,de),b.modelViewMatrix.multiplyMatrices(W.matrixWorldInverse,b.matrixWorld),b.normalMatrix.getNormalMatrix(b.modelViewMatrix),O.onBeforeRender(S,B,W,K,b,de),O.transparent===!0&&O.side===Qi&&O.forceSinglePass===!1?(O.side=Jn,O.needsUpdate=!0,S.renderBufferDirect(W,B,K,O,b,de),O.side=rs,O.needsUpdate=!0,S.renderBufferDirect(W,B,K,O,b,de),O.side=Qi):S.renderBufferDirect(W,B,K,O,b,de),b.onAfterRender(S,B,W,K,O,de)}function ul(b,B,W){B.isScene!==!0&&(B=wt);const K=qe.get(b),O=h.state.lights,de=h.state.shadowsArray,ye=O.state.version,Ue=De.getParameters(b,O.state,de,B,W),Fe=De.getProgramCacheKey(Ue);let et=K.programs;K.environment=b.isMeshStandardMaterial?B.environment:null,K.fog=B.fog,K.envMap=(b.isMeshStandardMaterial?G:T).get(b.envMap||K.environment),K.envMapRotation=K.environment!==null&&b.envMap===null?B.environmentRotation:b.envMapRotation,et===void 0&&(b.addEventListener("dispose",rt),et=new Map,K.programs=et);let st=et.get(Fe);if(st!==void 0){if(K.currentProgram===st&&K.lightsStateVersion===ye)return ap(b,Ue),st}else Ue.uniforms=De.getUniforms(b),b.onBeforeCompile(Ue,S),st=De.acquireProgram(Ue,Fe),et.set(Fe,st),K.uniforms=Ue.uniforms;const Be=K.uniforms;return(!b.isShaderMaterial&&!b.isRawShaderMaterial||b.clipping===!0)&&(Be.clippingPlanes=ce.uniform),ap(b,Ue),K.needsLights=qv(b),K.lightsStateVersion=ye,K.needsLights&&(Be.ambientLightColor.value=O.state.ambient,Be.lightProbe.value=O.state.probe,Be.directionalLights.value=O.state.directional,Be.directionalLightShadows.value=O.state.directionalShadow,Be.spotLights.value=O.state.spot,Be.spotLightShadows.value=O.state.spotShadow,Be.rectAreaLights.value=O.state.rectArea,Be.ltc_1.value=O.state.rectAreaLTC1,Be.ltc_2.value=O.state.rectAreaLTC2,Be.pointLights.value=O.state.point,Be.pointLightShadows.value=O.state.pointShadow,Be.hemisphereLights.value=O.state.hemi,Be.directionalShadowMap.value=O.state.directionalShadowMap,Be.directionalShadowMatrix.value=O.state.directionalShadowMatrix,Be.spotShadowMap.value=O.state.spotShadowMap,Be.spotLightMatrix.value=O.state.spotLightMatrix,Be.spotLightMap.value=O.state.spotLightMap,Be.pointShadowMap.value=O.state.pointShadowMap,Be.pointShadowMatrix.value=O.state.pointShadowMatrix),K.currentProgram=st,K.uniformsList=null,st}function sp(b){if(b.uniformsList===null){const B=b.currentProgram.getUniforms();b.uniformsList=tc.seqWithValue(B.seq,b.uniforms)}return b.uniformsList}function ap(b,B){const W=qe.get(b);W.outputColorSpace=B.outputColorSpace,W.batching=B.batching,W.batchingColor=B.batchingColor,W.instancing=B.instancing,W.instancingColor=B.instancingColor,W.instancingMorph=B.instancingMorph,W.skinning=B.skinning,W.morphTargets=B.morphTargets,W.morphNormals=B.morphNormals,W.morphColors=B.morphColors,W.morphTargetsCount=B.morphTargetsCount,W.numClippingPlanes=B.numClippingPlanes,W.numIntersection=B.numClipIntersection,W.vertexAlphas=B.vertexAlphas,W.vertexTangents=B.vertexTangents,W.toneMapping=B.toneMapping}function Kv(b,B,W,K,O){B.isScene!==!0&&(B=wt),R.resetTextureUnits();const de=B.fog,ye=K.isMeshStandardMaterial?B.environment:null,Ue=L===null?S.outputColorSpace:L.isXRRenderTarget===!0?L.texture.colorSpace:Qa,Fe=(K.isMeshStandardMaterial?G:T).get(K.envMap||ye),et=K.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,st=!!W.attributes.tangent&&(!!K.normalMap||K.anisotropy>0),Be=!!W.morphAttributes.position,St=!!W.morphAttributes.normal,Ot=!!W.morphAttributes.color;let Vt=jr;K.toneMapped&&(L===null||L.isXRRenderTarget===!0)&&(Vt=S.toneMapping);const Wn=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,bt=Wn!==void 0?Wn.length:0,He=qe.get(K),sr=h.state.lights;if(le===!0&&(Ce===!0||b!==x)){const ci=b===x&&K.id===y;ce.setState(K,b,ci)}let Et=!1;K.version===He.__version?(He.needsLights&&He.lightsStateVersion!==sr.state.version||He.outputColorSpace!==Ue||O.isBatchedMesh&&He.batching===!1||!O.isBatchedMesh&&He.batching===!0||O.isBatchedMesh&&He.batchingColor===!0&&O.colorTexture===null||O.isBatchedMesh&&He.batchingColor===!1&&O.colorTexture!==null||O.isInstancedMesh&&He.instancing===!1||!O.isInstancedMesh&&He.instancing===!0||O.isSkinnedMesh&&He.skinning===!1||!O.isSkinnedMesh&&He.skinning===!0||O.isInstancedMesh&&He.instancingColor===!0&&O.instanceColor===null||O.isInstancedMesh&&He.instancingColor===!1&&O.instanceColor!==null||O.isInstancedMesh&&He.instancingMorph===!0&&O.morphTexture===null||O.isInstancedMesh&&He.instancingMorph===!1&&O.morphTexture!==null||He.envMap!==Fe||K.fog===!0&&He.fog!==de||He.numClippingPlanes!==void 0&&(He.numClippingPlanes!==ce.numPlanes||He.numIntersection!==ce.numIntersection)||He.vertexAlphas!==et||He.vertexTangents!==st||He.morphTargets!==Be||He.morphNormals!==St||He.morphColors!==Ot||He.toneMapping!==Vt||He.morphTargetsCount!==bt)&&(Et=!0):(Et=!0,He.__version=K.version);let bi=He.currentProgram;Et===!0&&(bi=ul(K,B,O));let Zs=!1,Qn=!1,io=!1;const Gt=bi.getUniforms(),Wi=He.uniforms;if(ee.useProgram(bi.program)&&(Zs=!0,Qn=!0,io=!0),K.id!==y&&(y=K.id,Qn=!0),Zs||x!==b){ee.buffers.depth.getReversed()?(ue.copy(b.projectionMatrix),$y(ue),Zy(ue),Gt.setValue(F,"projectionMatrix",ue)):Gt.setValue(F,"projectionMatrix",b.projectionMatrix),Gt.setValue(F,"viewMatrix",b.matrixWorldInverse);const Pr=Gt.map.cameraPosition;Pr!==void 0&&Pr.setValue(F,ze.setFromMatrixPosition(b.matrixWorld)),Xe.logarithmicDepthBuffer&&Gt.setValue(F,"logDepthBufFC",2/(Math.log(b.far+1)/Math.LN2)),(K.isMeshPhongMaterial||K.isMeshToonMaterial||K.isMeshLambertMaterial||K.isMeshBasicMaterial||K.isMeshStandardMaterial||K.isShaderMaterial)&&Gt.setValue(F,"isOrthographic",b.isOrthographicCamera===!0),x!==b&&(x=b,Qn=!0,io=!0)}if(O.isSkinnedMesh){Gt.setOptional(F,O,"bindMatrix"),Gt.setOptional(F,O,"bindMatrixInverse");const ci=O.skeleton;ci&&(ci.boneTexture===null&&ci.computeBoneTexture(),Gt.setValue(F,"boneTexture",ci.boneTexture,R))}O.isBatchedMesh&&(Gt.setOptional(F,O,"batchingTexture"),Gt.setValue(F,"batchingTexture",O._matricesTexture,R),Gt.setOptional(F,O,"batchingIdTexture"),Gt.setValue(F,"batchingIdTexture",O._indirectTexture,R),Gt.setOptional(F,O,"batchingColorTexture"),O._colorsTexture!==null&&Gt.setValue(F,"batchingColorTexture",O._colorsTexture,R));const ro=W.morphAttributes;if((ro.position!==void 0||ro.normal!==void 0||ro.color!==void 0)&&Qe.update(O,W,bi),(Qn||He.receiveShadow!==O.receiveShadow)&&(He.receiveShadow=O.receiveShadow,Gt.setValue(F,"receiveShadow",O.receiveShadow)),K.isMeshGouraudMaterial&&K.envMap!==null&&(Wi.envMap.value=Fe,Wi.flipEnvMap.value=Fe.isCubeTexture&&Fe.isRenderTargetTexture===!1?-1:1),K.isMeshStandardMaterial&&K.envMap===null&&B.environment!==null&&(Wi.envMapIntensity.value=B.environmentIntensity),Qn&&(Gt.setValue(F,"toneMappingExposure",S.toneMappingExposure),He.needsLights&&Xv(Wi,io),de&&K.fog===!0&&ge.refreshFogUniforms(Wi,de),ge.refreshMaterialUniforms(Wi,K,X,oe,h.state.transmissionRenderTarget[b.id]),tc.upload(F,sp(He),Wi,R)),K.isShaderMaterial&&K.uniformsNeedUpdate===!0&&(tc.upload(F,sp(He),Wi,R),K.uniformsNeedUpdate=!1),K.isSpriteMaterial&&Gt.setValue(F,"center",O.center),Gt.setValue(F,"modelViewMatrix",O.modelViewMatrix),Gt.setValue(F,"normalMatrix",O.normalMatrix),Gt.setValue(F,"modelMatrix",O.matrixWorld),K.isShaderMaterial||K.isRawShaderMaterial){const ci=K.uniformsGroups;for(let Pr=0,Ir=ci.length;Pr<Ir;Pr++){const op=ci[Pr];U.update(op,bi),U.bind(op,bi)}}return bi}function Xv(b,B){b.ambientLightColor.needsUpdate=B,b.lightProbe.needsUpdate=B,b.directionalLights.needsUpdate=B,b.directionalLightShadows.needsUpdate=B,b.pointLights.needsUpdate=B,b.pointLightShadows.needsUpdate=B,b.spotLights.needsUpdate=B,b.spotLightShadows.needsUpdate=B,b.rectAreaLights.needsUpdate=B,b.hemisphereLights.needsUpdate=B}function qv(b){return b.isMeshLambertMaterial||b.isMeshToonMaterial||b.isMeshPhongMaterial||b.isMeshStandardMaterial||b.isShadowMaterial||b.isShaderMaterial&&b.lights===!0}this.getActiveCubeFace=function(){return E},this.getActiveMipmapLevel=function(){return A},this.getRenderTarget=function(){return L},this.setRenderTargetTextures=function(b,B,W){qe.get(b.texture).__webglTexture=B,qe.get(b.depthTexture).__webglTexture=W;const K=qe.get(b);K.__hasExternalTextures=!0,K.__autoAllocateDepthBuffer=W===void 0,K.__autoAllocateDepthBuffer||Ve.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),K.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(b,B){const W=qe.get(b);W.__webglFramebuffer=B,W.__useDefaultFramebuffer=B===void 0},this.setRenderTarget=function(b,B=0,W=0){L=b,E=B,A=W;let K=!0,O=null,de=!1,ye=!1;if(b){const Fe=qe.get(b);if(Fe.__useDefaultFramebuffer!==void 0)ee.bindFramebuffer(F.FRAMEBUFFER,null),K=!1;else if(Fe.__webglFramebuffer===void 0)R.setupRenderTarget(b);else if(Fe.__hasExternalTextures)R.rebindTextures(b,qe.get(b.texture).__webglTexture,qe.get(b.depthTexture).__webglTexture);else if(b.depthBuffer){const Be=b.depthTexture;if(Fe.__boundDepthTexture!==Be){if(Be!==null&&qe.has(Be)&&(b.width!==Be.image.width||b.height!==Be.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");R.setupDepthRenderbuffer(b)}}const et=b.texture;(et.isData3DTexture||et.isDataArrayTexture||et.isCompressedArrayTexture)&&(ye=!0);const st=qe.get(b).__webglFramebuffer;b.isWebGLCubeRenderTarget?(Array.isArray(st[B])?O=st[B][W]:O=st[B],de=!0):b.samples>0&&R.useMultisampledRTT(b)===!1?O=qe.get(b).__webglMultisampledFramebuffer:Array.isArray(st)?O=st[W]:O=st,C.copy(b.viewport),N.copy(b.scissor),D=b.scissorTest}else C.copy(Se).multiplyScalar(X).floor(),N.copy(Ne).multiplyScalar(X).floor(),D=nt;if(ee.bindFramebuffer(F.FRAMEBUFFER,O)&&K&&ee.drawBuffers(b,O),ee.viewport(C),ee.scissor(N),ee.setScissorTest(D),de){const Fe=qe.get(b.texture);F.framebufferTexture2D(F.FRAMEBUFFER,F.COLOR_ATTACHMENT0,F.TEXTURE_CUBE_MAP_POSITIVE_X+B,Fe.__webglTexture,W)}else if(ye){const Fe=qe.get(b.texture),et=B||0;F.framebufferTextureLayer(F.FRAMEBUFFER,F.COLOR_ATTACHMENT0,Fe.__webglTexture,W||0,et)}y=-1},this.readRenderTargetPixels=function(b,B,W,K,O,de,ye){if(!(b&&b.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Ue=qe.get(b).__webglFramebuffer;if(b.isWebGLCubeRenderTarget&&ye!==void 0&&(Ue=Ue[ye]),Ue){ee.bindFramebuffer(F.FRAMEBUFFER,Ue);try{const Fe=b.texture,et=Fe.format,st=Fe.type;if(!Xe.textureFormatReadable(et)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!Xe.textureTypeReadable(st)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}B>=0&&B<=b.width-K&&W>=0&&W<=b.height-O&&F.readPixels(B,W,K,O,lt.convert(et),lt.convert(st),de)}finally{const Fe=L!==null?qe.get(L).__webglFramebuffer:null;ee.bindFramebuffer(F.FRAMEBUFFER,Fe)}}},this.readRenderTargetPixelsAsync=async function(b,B,W,K,O,de,ye){if(!(b&&b.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Ue=qe.get(b).__webglFramebuffer;if(b.isWebGLCubeRenderTarget&&ye!==void 0&&(Ue=Ue[ye]),Ue){const Fe=b.texture,et=Fe.format,st=Fe.type;if(!Xe.textureFormatReadable(et))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!Xe.textureTypeReadable(st))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(B>=0&&B<=b.width-K&&W>=0&&W<=b.height-O){ee.bindFramebuffer(F.FRAMEBUFFER,Ue);const Be=F.createBuffer();F.bindBuffer(F.PIXEL_PACK_BUFFER,Be),F.bufferData(F.PIXEL_PACK_BUFFER,de.byteLength,F.STREAM_READ),F.readPixels(B,W,K,O,lt.convert(et),lt.convert(st),0);const St=L!==null?qe.get(L).__webglFramebuffer:null;ee.bindFramebuffer(F.FRAMEBUFFER,St);const Ot=F.fenceSync(F.SYNC_GPU_COMMANDS_COMPLETE,0);return F.flush(),await Yy(F,Ot,4),F.bindBuffer(F.PIXEL_PACK_BUFFER,Be),F.getBufferSubData(F.PIXEL_PACK_BUFFER,0,de),F.deleteBuffer(Be),F.deleteSync(Ot),de}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(b,B=null,W=0){b.isTexture!==!0&&(So("WebGLRenderer: copyFramebufferToTexture function signature has changed."),B=arguments[0]||null,b=arguments[1]);const K=Math.pow(2,-W),O=Math.floor(b.image.width*K),de=Math.floor(b.image.height*K),ye=B!==null?B.x:0,Ue=B!==null?B.y:0;R.setTexture2D(b,0),F.copyTexSubImage2D(F.TEXTURE_2D,W,0,0,ye,Ue,O,de),ee.unbindTexture()},this.copyTextureToTexture=function(b,B,W=null,K=null,O=0){b.isTexture!==!0&&(So("WebGLRenderer: copyTextureToTexture function signature has changed."),K=arguments[0]||null,b=arguments[1],B=arguments[2],O=arguments[3]||0,W=null);let de,ye,Ue,Fe,et,st,Be,St,Ot;const Vt=b.isCompressedTexture?b.mipmaps[O]:b.image;W!==null?(de=W.max.x-W.min.x,ye=W.max.y-W.min.y,Ue=W.isBox3?W.max.z-W.min.z:1,Fe=W.min.x,et=W.min.y,st=W.isBox3?W.min.z:0):(de=Vt.width,ye=Vt.height,Ue=Vt.depth||1,Fe=0,et=0,st=0),K!==null?(Be=K.x,St=K.y,Ot=K.z):(Be=0,St=0,Ot=0);const Wn=lt.convert(B.format),bt=lt.convert(B.type);let He;B.isData3DTexture?(R.setTexture3D(B,0),He=F.TEXTURE_3D):B.isDataArrayTexture||B.isCompressedArrayTexture?(R.setTexture2DArray(B,0),He=F.TEXTURE_2D_ARRAY):(R.setTexture2D(B,0),He=F.TEXTURE_2D),F.pixelStorei(F.UNPACK_FLIP_Y_WEBGL,B.flipY),F.pixelStorei(F.UNPACK_PREMULTIPLY_ALPHA_WEBGL,B.premultiplyAlpha),F.pixelStorei(F.UNPACK_ALIGNMENT,B.unpackAlignment);const sr=F.getParameter(F.UNPACK_ROW_LENGTH),Et=F.getParameter(F.UNPACK_IMAGE_HEIGHT),bi=F.getParameter(F.UNPACK_SKIP_PIXELS),Zs=F.getParameter(F.UNPACK_SKIP_ROWS),Qn=F.getParameter(F.UNPACK_SKIP_IMAGES);F.pixelStorei(F.UNPACK_ROW_LENGTH,Vt.width),F.pixelStorei(F.UNPACK_IMAGE_HEIGHT,Vt.height),F.pixelStorei(F.UNPACK_SKIP_PIXELS,Fe),F.pixelStorei(F.UNPACK_SKIP_ROWS,et),F.pixelStorei(F.UNPACK_SKIP_IMAGES,st);const io=b.isDataArrayTexture||b.isData3DTexture,Gt=B.isDataArrayTexture||B.isData3DTexture;if(b.isRenderTargetTexture||b.isDepthTexture){const Wi=qe.get(b),ro=qe.get(B),ci=qe.get(Wi.__renderTarget),Pr=qe.get(ro.__renderTarget);ee.bindFramebuffer(F.READ_FRAMEBUFFER,ci.__webglFramebuffer),ee.bindFramebuffer(F.DRAW_FRAMEBUFFER,Pr.__webglFramebuffer);for(let Ir=0;Ir<Ue;Ir++)io&&F.framebufferTextureLayer(F.READ_FRAMEBUFFER,F.COLOR_ATTACHMENT0,qe.get(b).__webglTexture,O,st+Ir),b.isDepthTexture?(Gt&&F.framebufferTextureLayer(F.DRAW_FRAMEBUFFER,F.COLOR_ATTACHMENT0,qe.get(B).__webglTexture,O,Ot+Ir),F.blitFramebuffer(Fe,et,de,ye,Be,St,de,ye,F.DEPTH_BUFFER_BIT,F.NEAREST)):Gt?F.copyTexSubImage3D(He,O,Be,St,Ot+Ir,Fe,et,de,ye):F.copyTexSubImage2D(He,O,Be,St,Ot+Ir,Fe,et,de,ye);ee.bindFramebuffer(F.READ_FRAMEBUFFER,null),ee.bindFramebuffer(F.DRAW_FRAMEBUFFER,null)}else Gt?b.isDataTexture||b.isData3DTexture?F.texSubImage3D(He,O,Be,St,Ot,de,ye,Ue,Wn,bt,Vt.data):B.isCompressedArrayTexture?F.compressedTexSubImage3D(He,O,Be,St,Ot,de,ye,Ue,Wn,Vt.data):F.texSubImage3D(He,O,Be,St,Ot,de,ye,Ue,Wn,bt,Vt):b.isDataTexture?F.texSubImage2D(F.TEXTURE_2D,O,Be,St,de,ye,Wn,bt,Vt.data):b.isCompressedTexture?F.compressedTexSubImage2D(F.TEXTURE_2D,O,Be,St,Vt.width,Vt.height,Wn,Vt.data):F.texSubImage2D(F.TEXTURE_2D,O,Be,St,de,ye,Wn,bt,Vt);F.pixelStorei(F.UNPACK_ROW_LENGTH,sr),F.pixelStorei(F.UNPACK_IMAGE_HEIGHT,Et),F.pixelStorei(F.UNPACK_SKIP_PIXELS,bi),F.pixelStorei(F.UNPACK_SKIP_ROWS,Zs),F.pixelStorei(F.UNPACK_SKIP_IMAGES,Qn),O===0&&B.generateMipmaps&&F.generateMipmap(He),ee.unbindTexture()},this.copyTextureToTexture3D=function(b,B,W=null,K=null,O=0){return b.isTexture!==!0&&(So("WebGLRenderer: copyTextureToTexture3D function signature has changed."),W=arguments[0]||null,K=arguments[1]||null,b=arguments[2],B=arguments[3],O=arguments[4]||0),So('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(b,B,W,K,O)},this.initRenderTarget=function(b){qe.get(b).__webglFramebuffer===void 0&&R.setupRenderTarget(b)},this.initTexture=function(b){b.isCubeTexture?R.setTextureCube(b,0):b.isData3DTexture?R.setTexture3D(b,0):b.isDataArrayTexture||b.isCompressedArrayTexture?R.setTexture2DArray(b,0):R.setTexture2D(b,0),ee.unbindTexture()},this.resetState=function(){E=0,A=0,L=null,ee.reset(),Bt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Mr}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorspace=vt._getDrawingBufferColorSpace(e),t.unpackColorSpace=vt._getUnpackColorSpace()}}class sC extends Gn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Lr,this.environmentIntensity=1,this.environmentRotation=new Lr,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}class H_ extends to{static get type(){return"LineBasicMaterial"}constructor(e){super(),this.isLineBasicMaterial=!0,this.color=new pt(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const Ac=new H,wc=new H,Gm=new rn,fo=new Nh,Dl=new rl,nd=new H,zm=new H;class Cc extends Gn{constructor(e=new sn,t=new H_){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[0];for(let r=1,s=t.count;r<s;r++)Ac.fromBufferAttribute(t,r-1),wc.fromBufferAttribute(t,r),n[r]=n[r-1],n[r]+=Ac.distanceTo(wc);e.setAttribute("lineDistance",new At(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){const n=this.geometry,r=this.matrixWorld,s=e.params.Line.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Dl.copy(n.boundingSphere),Dl.applyMatrix4(r),Dl.radius+=s,e.ray.intersectsSphere(Dl)===!1)return;Gm.copy(r).invert(),fo.copy(e.ray).applyMatrix4(Gm);const a=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,u=this.isLineSegments?2:1,c=n.index,p=n.attributes.position;if(c!==null){const f=Math.max(0,o.start),_=Math.min(c.count,o.start+o.count);for(let m=f,g=_-1;m<g;m+=u){const h=c.getX(m),v=c.getX(m+1),M=Nl(this,e,fo,l,h,v);M&&t.push(M)}if(this.isLineLoop){const m=c.getX(_-1),g=c.getX(f),h=Nl(this,e,fo,l,m,g);h&&t.push(h)}}else{const f=Math.max(0,o.start),_=Math.min(p.count,o.start+o.count);for(let m=f,g=_-1;m<g;m+=u){const h=Nl(this,e,fo,l,m,m+1);h&&t.push(h)}if(this.isLineLoop){const m=Nl(this,e,fo,l,_-1,f);m&&t.push(m)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const r=t[n[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,o=r.length;s<o;s++){const a=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=s}}}}}function Nl(i,e,t,n,r,s){const o=i.geometry.attributes.position;if(Ac.fromBufferAttribute(o,r),wc.fromBufferAttribute(o,s),t.distanceSqToSegment(Ac,wc,nd,zm)>n)return;nd.applyMatrix4(i.matrixWorld);const l=e.ray.origin.distanceTo(nd);if(!(l<e.near||l>e.far))return{distance:l,point:zm.clone().applyMatrix4(i.matrixWorld),index:r,face:null,faceIndex:null,barycoord:null,object:i}}const Wm=new H,Km=new H;class Rc extends Cc{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[];for(let r=0,s=t.count;r<s;r+=2)Wm.fromBufferAttribute(t,r),Km.fromBufferAttribute(t,r+1),n[r]=r===0?0:n[r-1],n[r+1]=n[r]+Wm.distanceTo(Km);e.setAttribute("lineDistance",new At(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class V_ extends Cc{constructor(e,t){super(e,t),this.isLineLoop=!0,this.type="LineLoop"}}class ou extends to{static get type(){return"PointsMaterial"}constructor(e){super(),this.isPointsMaterial=!0,this.color=new pt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const Xm=new rn,kf=new Nh,Ul=new rl,Fl=new H;class G_ extends Gn{constructor(e=new sn,t=new ou){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){const n=this.geometry,r=this.matrixWorld,s=e.params.Points.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Ul.copy(n.boundingSphere),Ul.applyMatrix4(r),Ul.radius+=s,e.ray.intersectsSphere(Ul)===!1)return;Xm.copy(r).invert(),kf.copy(e.ray).applyMatrix4(Xm);const a=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,u=n.index,d=n.attributes.position;if(u!==null){const p=Math.max(0,o.start),f=Math.min(u.count,o.start+o.count);for(let _=p,m=f;_<m;_++){const g=u.getX(_);Fl.fromBufferAttribute(d,g),qm(Fl,g,l,r,e,t,this)}}else{const p=Math.max(0,o.start),f=Math.min(d.count,o.start+o.count);for(let _=p,m=f;_<m;_++)Fl.fromBufferAttribute(d,_),qm(Fl,_,l,r,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const r=t[n[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,o=r.length;s<o;s++){const a=r[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=s}}}}}function qm(i,e,t,n,r,s,o){const a=kf.distanceSqToPoint(i);if(a<t){const l=new H;kf.closestPointToPoint(i,l),l.applyMatrix4(n);const u=r.ray.origin.distanceTo(l);if(u<r.near||u>r.far)return;s.push({distance:u,distanceToRay:Math.sqrt(a),point:l,index:e,face:null,faceIndex:null,barycoord:null,object:o})}}class Gs extends sn{constructor(e=1,t=32,n=0,r=Math.PI*2){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:n,thetaLength:r},t=Math.max(3,t);const s=[],o=[],a=[],l=[],u=new H,c=new tt;o.push(0,0,0),a.push(0,0,1),l.push(.5,.5);for(let d=0,p=3;d<=t;d++,p+=3){const f=n+d/t*r;u.x=e*Math.cos(f),u.y=e*Math.sin(f),o.push(u.x,u.y,u.z),a.push(0,0,1),c.x=(o[p]/e+1)/2,c.y=(o[p+1]/e+1)/2,l.push(c.x,c.y)}for(let d=1;d<=t;d++)s.push(d,d+1,0);this.setIndex(s),this.setAttribute("position",new At(o,3)),this.setAttribute("normal",new At(a,3)),this.setAttribute("uv",new At(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Gs(e.radius,e.segments,e.thetaStart,e.thetaLength)}}class Fh extends sn{constructor(e=[],t=[],n=1,r=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:n,detail:r};const s=[],o=[];a(r),u(n),c(),this.setAttribute("position",new At(s,3)),this.setAttribute("normal",new At(s.slice(),3)),this.setAttribute("uv",new At(o,2)),r===0?this.computeVertexNormals():this.normalizeNormals();function a(v){const M=new H,S=new H,P=new H;for(let E=0;E<t.length;E+=3)f(t[E+0],M),f(t[E+1],S),f(t[E+2],P),l(M,S,P,v)}function l(v,M,S,P){const E=P+1,A=[];for(let L=0;L<=E;L++){A[L]=[];const y=v.clone().lerp(S,L/E),x=M.clone().lerp(S,L/E),C=E-L;for(let N=0;N<=C;N++)N===0&&L===E?A[L][N]=y:A[L][N]=y.clone().lerp(x,N/C)}for(let L=0;L<E;L++)for(let y=0;y<2*(E-L)-1;y++){const x=Math.floor(y/2);y%2===0?(p(A[L][x+1]),p(A[L+1][x]),p(A[L][x])):(p(A[L][x+1]),p(A[L+1][x+1]),p(A[L+1][x]))}}function u(v){const M=new H;for(let S=0;S<s.length;S+=3)M.x=s[S+0],M.y=s[S+1],M.z=s[S+2],M.normalize().multiplyScalar(v),s[S+0]=M.x,s[S+1]=M.y,s[S+2]=M.z}function c(){const v=new H;for(let M=0;M<s.length;M+=3){v.x=s[M+0],v.y=s[M+1],v.z=s[M+2];const S=g(v)/2/Math.PI+.5,P=h(v)/Math.PI+.5;o.push(S,1-P)}_(),d()}function d(){for(let v=0;v<o.length;v+=6){const M=o[v+0],S=o[v+2],P=o[v+4],E=Math.max(M,S,P),A=Math.min(M,S,P);E>.9&&A<.1&&(M<.2&&(o[v+0]+=1),S<.2&&(o[v+2]+=1),P<.2&&(o[v+4]+=1))}}function p(v){s.push(v.x,v.y,v.z)}function f(v,M){const S=v*3;M.x=e[S+0],M.y=e[S+1],M.z=e[S+2]}function _(){const v=new H,M=new H,S=new H,P=new H,E=new tt,A=new tt,L=new tt;for(let y=0,x=0;y<s.length;y+=9,x+=6){v.set(s[y+0],s[y+1],s[y+2]),M.set(s[y+3],s[y+4],s[y+5]),S.set(s[y+6],s[y+7],s[y+8]),E.set(o[x+0],o[x+1]),A.set(o[x+2],o[x+3]),L.set(o[x+4],o[x+5]),P.copy(v).add(M).add(S).divideScalar(3);const C=g(P);m(E,x+0,v,C),m(A,x+2,M,C),m(L,x+4,S,C)}}function m(v,M,S,P){P<0&&v.x===1&&(o[M]=v.x-1),S.x===0&&S.z===0&&(o[M]=P/2/Math.PI+.5)}function g(v){return Math.atan2(v.z,-v.x)}function h(v){return Math.atan2(-v.y,Math.sqrt(v.x*v.x+v.z*v.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Fh(e.vertices,e.indices,e.radius,e.details)}}const Bl=new H,Ol=new H,id=new H,kl=new mi;class Lc extends sn{constructor(e=null,t=1){if(super(),this.type="EdgesGeometry",this.parameters={geometry:e,thresholdAngle:t},e!==null){const r=Math.pow(10,4),s=Math.cos(ec*t),o=e.getIndex(),a=e.getAttribute("position"),l=o?o.count:a.count,u=[0,0,0],c=["a","b","c"],d=new Array(3),p={},f=[];for(let _=0;_<l;_+=3){o?(u[0]=o.getX(_),u[1]=o.getX(_+1),u[2]=o.getX(_+2)):(u[0]=_,u[1]=_+1,u[2]=_+2);const{a:m,b:g,c:h}=kl;if(m.fromBufferAttribute(a,u[0]),g.fromBufferAttribute(a,u[1]),h.fromBufferAttribute(a,u[2]),kl.getNormal(id),d[0]=`${Math.round(m.x*r)},${Math.round(m.y*r)},${Math.round(m.z*r)}`,d[1]=`${Math.round(g.x*r)},${Math.round(g.y*r)},${Math.round(g.z*r)}`,d[2]=`${Math.round(h.x*r)},${Math.round(h.y*r)},${Math.round(h.z*r)}`,!(d[0]===d[1]||d[1]===d[2]||d[2]===d[0]))for(let v=0;v<3;v++){const M=(v+1)%3,S=d[v],P=d[M],E=kl[c[v]],A=kl[c[M]],L=`${S}_${P}`,y=`${P}_${S}`;y in p&&p[y]?(id.dot(p[y].normal)<=s&&(f.push(E.x,E.y,E.z),f.push(A.x,A.y,A.z)),p[y]=null):L in p||(p[L]={index0:u[v],index1:u[M],normal:id.clone()})}}for(const _ in p)if(p[_]){const{index0:m,index1:g}=p[_];Bl.fromBufferAttribute(a,m),Ol.fromBufferAttribute(a,g),f.push(Bl.x,Bl.y,Bl.z),f.push(Ol.x,Ol.y,Ol.z)}this.setAttribute("position",new At(f,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}}class lu extends Fh{constructor(e=1,t=0){const n=(1+Math.sqrt(5))/2,r=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1],s=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(r,s,e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new lu(e.radius,e.detail)}}class Zt extends sn{constructor(e=.5,t=1,n=32,r=1,s=0,o=Math.PI*2){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:n,phiSegments:r,thetaStart:s,thetaLength:o},n=Math.max(3,n),r=Math.max(1,r);const a=[],l=[],u=[],c=[];let d=e;const p=(t-e)/r,f=new H,_=new tt;for(let m=0;m<=r;m++){for(let g=0;g<=n;g++){const h=s+g/n*o;f.x=d*Math.cos(h),f.y=d*Math.sin(h),l.push(f.x,f.y,f.z),u.push(0,0,1),_.x=(f.x/t+1)/2,_.y=(f.y/t+1)/2,c.push(_.x,_.y)}d+=p}for(let m=0;m<r;m++){const g=m*(n+1);for(let h=0;h<n;h++){const v=h+g,M=v,S=v+n+1,P=v+n+2,E=v+1;a.push(M,S,E),a.push(S,P,E)}}this.setIndex(a),this.setAttribute("position",new At(l,3)),this.setAttribute("normal",new At(u,3)),this.setAttribute("uv",new At(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Zt(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}}const Ym={enabled:!1,files:{},add:function(i,e){this.enabled!==!1&&(this.files[i]=e)},get:function(i){if(this.enabled!==!1)return this.files[i]},remove:function(i){delete this.files[i]},clear:function(){this.files={}}};class aC{constructor(e,t,n){const r=this;let s=!1,o=0,a=0,l;const u=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this.itemStart=function(c){a++,s===!1&&r.onStart!==void 0&&r.onStart(c,o,a),s=!0},this.itemEnd=function(c){o++,r.onProgress!==void 0&&r.onProgress(c,o,a),o===a&&(s=!1,r.onLoad!==void 0&&r.onLoad())},this.itemError=function(c){r.onError!==void 0&&r.onError(c)},this.resolveURL=function(c){return l?l(c):c},this.setURLModifier=function(c){return l=c,this},this.addHandler=function(c,d){return u.push(c,d),this},this.removeHandler=function(c){const d=u.indexOf(c);return d!==-1&&u.splice(d,2),this},this.getHandler=function(c){for(let d=0,p=u.length;d<p;d+=2){const f=u[d],_=u[d+1];if(f.global&&(f.lastIndex=0),f.test(c))return _}return null}}}const oC=new aC;class Bh{constructor(e){this.manager=e!==void 0?e:oC,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){const n=this;return new Promise(function(r,s){n.load(e,r,t,s)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}}Bh.DEFAULT_MATERIAL_NAME="__DEFAULT";class lC extends Bh{constructor(e){super(e)}load(e,t,n,r){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const s=this,o=Ym.get(e);if(o!==void 0)return s.manager.itemStart(e),setTimeout(function(){t&&t(o),s.manager.itemEnd(e)},0),o;const a=qo("img");function l(){c(),Ym.add(e,this),t&&t(this),s.manager.itemEnd(e)}function u(d){c(),r&&r(d),s.manager.itemError(e),s.manager.itemEnd(e)}function c(){a.removeEventListener("load",l,!1),a.removeEventListener("error",u,!1)}return a.addEventListener("load",l,!1),a.addEventListener("error",u,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(a.crossOrigin=this.crossOrigin),s.manager.itemStart(e),a.src=e,a}}class z_ extends Bh{constructor(e){super(e)}load(e,t,n,r){const s=new Vn,o=new lC(this.manager);return o.setCrossOrigin(this.crossOrigin),o.setPath(this.path),o.load(e,function(a){s.image=a,s.needsUpdate=!0,t!==void 0&&t(s)},n,r),s}}class cC{constructor(e=!0){this.autoStart=e,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=$m(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let e=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){const t=$m();e=(t-this.oldTime)/1e3,this.oldTime=t,this.elapsedTime+=e}return e}}function $m(){return performance.now()}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:wh}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=wh);const cu=new Int32Array([63231,16722902,8191802,16757504]),W_=new Int32Array([0,3898367,16726876]);function Wt(i){return i.Team>0?w(i.Team,W_)|0:w(w(i.Id,Hn),cu)|0}const K_=240,uC=96,dC=24,fC=8,hC=2,rd=6,Ca=11758591,Yo=13929727,pC=.3,mC=.45,gC=.7,_C=.45,vC=2.2,MC=5;let Ka=Tt(!1),$o=Tt(!0);function Ra(){return(Ge()+100)/Math.tan(20*3.141592653589793/180)}function yo(){return Ra()*.75}const Kt=Jc(),Pc=[1536,1024],Hf=[530,450],SC=[[217,40],[790,46],[12,452],[502,481],[984,474]];function xC(i){return i.Team>0?i.Team-1|0:w(w(i.Id,Hn),new Int32Array([0,1,3,4]))|0}function Mt(i){return i.rotateX(-3.141592653589793/2)}function xt(i,e){return new xi({blending:Hs,color:i,opacity:e,transparent:!0})}function Jr(i,e){return new H_({blending:Hs,color:i,opacity:e,transparent:!0})}class yC extends os{constructor(e,t,n,r,s,o){super(),this.PX=e,this.PZ=t,this.VX=n,this.VZ=r,this.Age=s,this.MaxAge=o}}class TC extends os{constructor(e,t,n,r,s,o,a,l,u,c,d,p,f,_,m){super(),this.Shield=e,this.Vent=t,this.Root=n,this.Body=r,this.Flame=s,this.Retro=o,this.Coil=a,this.Laser=l,this.Tether=u,this.Bubble=c,this.Warn=d,this.Mark=p,this.Trail=f,this.History=_,this.Particles=m}}const X_=48;class bC extends os{constructor(e,t,n,r){super(),this.Points=e,this.Vel=t,this.Decay=n,this.Life=r}}class EC extends os{constructor(e,t,n,r,s,o,a){super(),this.Obj=e,this.Spin=t,this.Span=n,this.Pos=r,this.Vel=s,this.Puff=o,this.Life=a}}class AC extends os{constructor(e,t,n,r){super(),this.Obj=e,this.Grow=t,this.Span=n,this.Life=r}}class wC extends os{constructor(e,t,n,r,s,o,a,l,u,c,d,p,f,_,m,g,h,v,M,S,P,E,A,L,y,x,C,N,D,I,J,q,oe,X,he,pe,Se,Ne,nt,Z,le,Ce,ue,Pe,ze,Ze,wt,Oe){super(),this.Scene=e,this.Camera=t,this.Renderer=n,this.Composer=r,this.Bloom=s,this.Ships=o,this.Pads=a,this.Rocks=l,this.Road=u,this.Marks=c,this.Layout=d|0,this.Bullets=p,this.Mines=f,this.Boulders=_,this.Gates=m,this.Walls=g,this.Turrets=h,this.Bubbles=v,this.Hole=M,this.Horizon=S,this.Halo=P,this.Crates=E,this.Panels=A,this.Tags=L,this.Names=y,this.Spawns=x,this.Intro=C,this.Border=N,this.Frame=D,this.Size=I,this.Clock=J,this.Feed=q,this.Banner=oe,this.Vignette=X,this.Bursts=he,this.Shards=pe,this.Flashes=Se,this.Hp=Ne,this.Shake=nt,this.Smoke=Z,this.Puff=le,this.Spike=Ce,this.Jolt=ue,this.Tint=Pe,this.TintHex=ze,this.KillCd=Ze,this.Cam=wt,this.CamH=Oe}}class CC{constructor(e=!1){this._id=0,this._cancelled=e,this._listeners=new Map}get isCancelled(){return this._cancelled}cancel(){if(!this._cancelled){this._cancelled=!0;for(const[,e]of this._listeners)e()}}addListener(e){const t=this._id;return this._listeners.set(this._id++,e),t}removeListener(e){return this._listeners.delete(e)}register(e,t){const n=this,r=this.addListener(t==null?e:()=>e(t));return{Dispose(){n.removeListener(r)}}}Dispose(){}}class q_ extends vS{constructor(e){super(e??"The operation was canceled")}}class Oh{static get maxTrampolineCallCount(){return 2e3}constructor(){this.callCount=0,this.completed=!1}incrementAndCheck(){return this.callCount++>Oh.maxTrampolineCallCount}hijack(e){this.callCount=0,setTimeout(e,0)}}function Rs(i){return e=>{if(e.cancelToken.isCancelled)e.onCancel(new q_);else if(e.trampoline.incrementAndCheck())e.trampoline.hijack(()=>{try{i(e)}catch(t){if(e.trampoline.completed)throw t;e.onError(_c(t))}});else try{i(e)}catch(t){if(e.trampoline.completed)throw t;e.onError(_c(t))}}}function RC(i,e){return Rs(t=>{i({onSuccess:n=>{let r;try{r=e(n)}catch(s){t.onError(_c(s));return}r(t)},onError:t.onError,onCancel:t.onCancel,cancelToken:t.cancelToken,trampoline:t.trampoline})})}function LC(i){return Rs(e=>e.onSuccess(i))}class PC{Bind(e,t){return RC(e,t)}Combine(e,t){return this.Bind(e,()=>t)}Delay(e){return Rs(t=>e()(t))}For(e,t){const n=e[Symbol.iterator]();let r=n.next();return this.While(()=>!r.done,this.Delay(()=>{const s=t(r.value);return r=n.next(),s}))}Return(e){return LC(e)}ReturnFrom(e){return e}TryFinally(e,t){return Rs(n=>{e({onSuccess:r=>{t(),n.onSuccess(r)},onError:r=>{t(),n.onError(r)},onCancel:r=>{t(),n.onCancel(r)},cancelToken:n.cancelToken,trampoline:n.trampoline})})}TryWith(e,t){return Rs(n=>{e({onSuccess:n.onSuccess,onCancel:n.onCancel,cancelToken:n.cancelToken,trampoline:n.trampoline,onError:r=>{let s;try{s=t(r)}catch(o){n.onError(_c(o));return}s(n)}})})}Using(e,t){return this.TryFinally(t(e),()=>e.Dispose())}While(e,t){return e()?this.Bind(t,()=>this.While(e,t)):this.Return(void 0)}Zero(){return Rs(e=>e.onSuccess(void 0))}}const Bn=new PC;function Vf(i){}function kh(i){return DC(e=>i.then(e[0]).catch(t=>(t instanceof q_?e[2]:e[1])(t)))}const IC=new CC;function DC(i){return Rs(e=>i([e.onSuccess,e.onError,e.onCancel]))}function NC(i,e){return UC(i,Vf,function(t){throw t},Vf)}function Hh(i,e){return NC(i)}function UC(i,e,t,n,r){const s=new Oh,o=a=>l=>(s.completed=!0,a(l));i({onSuccess:o(e||Vf),onError:o(t),onCancel:o(n),cancelToken:IC,trampoline:s})}let Ft=an(),va=an(),nc=an(),Gf=an(),Ma=an(),pa=an(),Y_=!1,zf=!1,$_=!1;function Z_(){return Y_?!0:$_}const FC=.32,Vh=Jc(),j_="nda-audio";let Xa=[1,1];const La=document.createElement("audio");function sl(){const i=Z_();La.volume=.35*w(1,Xa),La.muted=i?!0:zf,Ft!=null&&(va.gain.value=i?0:FC*w(0,Xa))}function BC(i){Y_=i,sl()}function Zm(i){$_=i,sl()}function Ic(i){return w(i,Xa)}function J_(i,e){ve(Xa,i,ES(10*fe(0,$e(1,e)))/10),window.localStorage.setItem(j_,JSON.stringify(Xa)),sl()}const OC=window.location.pathname.indexOf("/play/")>=0?"../":"./",jm=["battle1","battle2","battle3"];let Dc=!0;function Wf(){const i=Dc?"menu":w(Vh.Next1(jm.length),jm);La.src=ie(te("%smusic/%s.mp3"))(OC)(i),La.loop=Dc,La.play()}function kC(){Ft=new(window.AudioContext||window.webkitAudioContext),va=Ft.createGain(),sl(),va.connect(Ft.destination);const i=Ft.createDelay(1);i.delayTime.value=.135;const e=Ft.createGain();e.gain.value=.36;const t=Ft.createBiquadFilter();t.type="lowpass",t.frequency.value=2400,i.connect(t),t.connect(e),e.connect(i),i.connect(va),nc=Ft.createGain(),nc.gain.value=.22,nc.connect(i);const n=~~(Ft.sampleRate*.5)|0;Gf=Ft.createBuffer(1,n,Ft.sampleRate);const r=Gf.getChannelData(0);for(let o=0;o<=n-1;o++)ve(r,o,Vh.NextDouble()*2-1);pa=Ft.createBiquadFilter(),pa.type="lowpass",pa.frequency.value=300,Ma=Ft.createGain(),Ma.gain.value=0,pa.connect(Ma),Ma.connect(va);const s=mt([["sawtooth",55],["square",82.5]]);try{for(;s["System.Collections.IEnumerator.MoveNext"]();){const o=s["System.Collections.Generic.IEnumerator`1.get_Current"](),a=Ft.createOscillator();a.type=o[0],a.frequency.value=o[1],a.connect(pa),a.start(Ft.currentTime)}}finally{yt(s)}}function HC(){return Ft==null?!0:Ft.state==="suspended"}function Zo(){return Ft==null?(kC(),La.onended=(i=>{Wf()}),Wf()):Ft.state==="suspended"&&Ft.resume(),!Z_()}function Q_(i){i!==Dc&&(Dc=i,Ft!=null&&Wf())}function al(){return Ft.currentTime}function ev(i,e,t){const n=Ft.createGain(),r=al();n.gain.setValueAtTime(1e-4,r),n.gain.exponentialRampToValueAtTime(fe(2e-4,e),r+.005),n.gain.exponentialRampToValueAtTime(1e-4,r+t);const s=Ft.createStereoPanner();return s.pan.value=fe(-.9,$e(.9,i)),n.connect(s),s.connect(va),s.connect(nc),n}function ft(i,e,t,n,r,s){const o=Ft.createOscillator();o.type=i;const a=al();o.frequency.setValueAtTime(t,a),o.frequency.exponentialRampToValueAtTime(fe(20,n),a+r),o.connect(ev(e,s,r)),o.start(a),o.stop(a+r+.03)}function yi(i,e,t,n,r,s){const o=Ft.createBufferSource();o.buffer=Gf;const a=Ft.createBiquadFilter();a.type=i;const l=al();a.frequency.setValueAtTime(t,l),a.frequency.exponentialRampToValueAtTime(fe(60,t*.3),l+n),a.Q.value=s,o.connect(a),a.connect(ev(e,r,n)),o.start(l),o.stop(l+n+.03)}function wn(i){return i.X/Ge()}function VC(){return .94+Vh.NextDouble()*.12}const $i=class $i extends Ks{constructor(e,t){super(),this.tag=e,this.fields=t}cases(){return["Tick","Go","Win","Alert"]}};pn($i,"Tick",new $i(0,[])),pn($i,"Go",new $i(1,[])),pn($i,"Win",new $i(2,[])),pn($i,"Alert",new $i(3,[]));let jo=$i;function tv(i){if(Zo())switch(i.tag){case 1:{ft("square",0,660,660,.1,.55),ft("square",0,1320,1320,.3,.4);break}case 2:{ft("square",-.2,523,523,.12,.4),ft("square",.2,784,784,.14,.4),ft("sawtooth",0,1046,1046,.6,.35);break}case 3:{ft("square",0,1174,1174,.08,.34),ft("square",0,1568,1568,.18,.3);break}default:ft("square",0,880,880,.09,.5)}}function GC(i){const e=wn(i);ft("square",e,940*VC(),130,.085,.24),yi("bandpass",e,2600,.05,.12,1)}function zC(i){const e=wn(i);yi("bandpass",e,1900,.13,.4,1.4),ft("square",e,320,90,.11,.3)}function WC(i){const e=wn(i);yi("lowpass",e,700,.3,.55,.8),ft("sawtooth",e,150,45,.28,.35)}function Jm(i){const e=wn(i);ft("sine",e,196,88,.55,.3),ft("sine",e,203,91,.55,.22),yi("highpass",e,3200,.09,.2,1)}function Qm(i,e){const t=wn(i);ft("square",t,660,660,.07,.28),ft("square",t,990,990,.12,.26),e&&ft("square",t,1320,1320,.22,.26)}function KC(i){const e=wn(i);ft("sine",e,440,440,.1,.3),ft("sine",e,660,660,.22,.28),ft("sine",e,880,880,.34,.2)}function XC(i){const e=wn(i);ft("square",e,523,523,.07,.26),ft("square",e,784,784,.12,.26),ft("square",e,1046,1046,.24,.24),yi("highpass",e,4200,.18,.14,1)}function qC(i){ft("sawtooth",wn(i),180,1500,fe(.2,ns()),.2)}function YC(i){const e=wn(i);ft("sawtooth",e,2400,150,.4,.5),ft("square",e,1200,90,.3,.3),yi("bandpass",e,3e3,.3,.4,.7)}function e0(i){const e=wn(i);ft("square",e,150,110,.06,.22),yi("highpass",e,2600,.05,.12,1)}function t0(i){const e=wn(i);ft("square",e,1046,1046,.07,.3),ft("square",e,1318,1318,.14,.28)}function n0(i){const e=wn(i);yi("lowpass",e,1400,.5,.6,.9),ft("sawtooth",e,320,40,.42,.4)}function $C(i){const e=wn(i);yi("bandpass",e,500,.34,.45,2.2),ft("sine",e,90,300,.3,.3)}function ZC(i){const e=wn(i);yi("highpass",e,2500,.22,.4,1),ft("square",e,1800,200,.18,.25)}function jC(i){const e=wn(i);ft("sine",e,220,660,.3,.3),ft("triangle",e,110,330,.3,.2)}function i0(i){const e=wn(i);ft("square",e,420,70,.42,.32),yi("lowpass",e,1800,.35,.3,.8)}function JC(i){const e=wn(i);yi("lowpass",e,1100,.75,.7,.9),ft("sawtooth",e,220,32,.6,.45),ft("square",e,110,24,.45,.3)}function nv(i){if(Zo()){let e=0,t=0;const n=mt(i);try{for(;n["System.Collections.IEnumerator.MoveNext"]();){const r=n["System.Collections.Generic.IEnumerator`1.get_Current"]();switch(r.tag){case 0:{zC(r.fields[0]);break}case 3:break;case 5:{WC(r.fields[0]);break}case 6:{t<2&&(t=t+1|0,Jm(r.fields[0]));break}case 7:{t<2&&(t=t+1|0,i0(r.fields[0]));break}case 8:{Qm(r.fields[0],r.fields[1]);break}case 9:{KC(r.fields[0]);break}case 10:{XC(r.fields[0]);break}case 11:{qC(r.fields[0]);break}case 12:{YC(r.fields[0]);break}case 13:{e0(r.fields[0]);break}case 14:{t0(r.fields[0]);break}case 15:{n0(r.fields[0]);break}case 16:{$C(r.fields[0]);break}case 17:{i0(r.fields[0]);break}case 18:{ZC(r.fields[0]);break}case 19:{jC(r.fields[0]);break}case 20:{Jm(r.fields[0]);break}case 21:{t0(r.fields[0]);break}case 22:{Qm(r.fields[0],!1);break}case 23:{n0(r.fields[0]);break}case 24:{e0(r.fields[0].Pos);break}case 1:{JC(r.fields[0]);break}case 2:break;case 25:break;default:e<2&&(e=e+1|0,GC(r.fields[0]))}}}finally{yt(n)}}}function iv(i){if(Zo()){const e=i.Ships.filter(s=>s.Alive?s.Thrusting>0:!1),t=MS(s=>s.Thrusting>1?TS():bS(),e,{GetZero:()=>0,Add:(s,o)=>s+o}),n=fh((s,o)=>fe(s,ke(o.Vel)),0,e),r=al()+.05;Ma.gain.linearRampToValueAtTime($e(SS(),t),r),pa.frequency.linearRampToValueAtTime(xS()+n/vh()*yS(),r)}}function QC(){Ft!=null&&Ma.gain.linearRampToValueAtTime(0,al()+.08)}function eR(){const i=mt(["keydown","pointerdown","gamepadconnected"]);try{for(;i["System.Collections.IEnumerator.MoveNext"]();){const t=i["System.Collections.Generic.IEnumerator`1.get_Current"]();window.addEventListener(t,n=>{Zo()})}}finally{yt(i)}window.addEventListener("keydown",t=>{t.key==="m"&&(zf=!zf,sl())}),window.addEventListener("visibilitychange",t=>{document.hidden||Zo()});const e=window.localStorage.getItem(j_);e===an()||(Xa=JSON.parse(e))}const Gh="nda-tweaks",rv="nda-pads",zh="nda-binds",sv="nda-arena",av="nda-catchup",ov="nda-screenfx",lv="nda-reduceflash",r0=gt(i=>i[1](),Ui,Float64Array),tR=$c(window.location.search,["?","&"]).some(e=>e==="dev"?!0:e.startsWith("dev="));let si=Tt(0),Kf=Tt(!0),cv=Tt(i=>{});function uv(){return si()===Mi.length?k.Random:w(is(),k.Arenas)}function Wh(){return ki(kt(0,1,Mi.length-1)).filter(e=>kg(e)===ot())}function s0(){if(si()===Mi.length){const i=Wh();el(w(Jc().Next1(i.length),i))}}function dv(){si()<Mi.length&&kg(si())!==ot()&&(si(w(0,Wh())),el(si()))}const zc=class zc extends Ks{constructor(e,t){super(),this.tag=e,this.fields=t}cases(){return["Header","Slot","Swap","Level","Tune","Action","Arena","Note","Bind"]}};pn(zc,"Arena",new zc(6,[]));let Nt=zc;function nR(){const i={};for(let e=0;e<=Ui.length-1;e++){const t=w(e,Ui);i[t[0]]=t[1]()}window.localStorage.setItem(Gh,JSON.stringify(i))}function iR(){const i=window.localStorage.getItem(Gh);if(i!==an()){const e=JSON.parse(i);for(let t=0;t<=Ui.length-1;t++){const n=w(t,Ui),r=e[n[0]];r!=null&&n[2](r)}}}function Kh(){const i={};i.keyboard=er();let e=mt(Sh);try{for(;e["System.Collections.IEnumerator.MoveNext"]();){const t=e["System.Collections.Generic.IEnumerator`1.get_Current"]();i[Ps(t[0])]=t[1]}}finally{yt(e)}window.localStorage.setItem(rv,JSON.stringify(i))}function rR(){const i=window.localStorage.getItem(rv);if(i!==an()){const e=JSON.parse(i);for(let t=0;t<=3;t++){const n=e[Ps(t)];n!=null&&Sh.set(t,new Wd(bg,n.Swap,n.Absolute!==!1))}}}function a0(i,e){Sh.set(i,e(Kd(i))),Kh()}function fv(){const i={};for(let e=0;e<=Fs.length-1;e++){const t=w(e,Fs);i[Eg(t)]=vc(t)}window.localStorage.setItem(zh,JSON.stringify(i))}function sR(){const i=window.localStorage.getItem(zh);if(i!==an()){const e=JSON.parse(i);if(e!=null)for(let t=0;t<=Fs.length-1;t++){const n=w(t,Fs),r=e[Eg(n)];if(r!=null&&Array.isArray(r)){const s=DS(r.filter(o=>o!=null?o!=="":!1),{Equals:(o,a)=>o===a,GetHashCode:o=>wg(o)|0});s.length>0&&Mc(n,s)}}}}let gi;function hv(){return gi!=null}function aR(){gi=void 0}function oR(i){let e;switch(gi!=null&&Sc(gi[0])===Sc(i)?(e=0,gi[0]):e=1,e){case 0:return k.BindPress;default:return Ag(i)}}function lR(i){if(gi!=null){const e=gi[1],t=gi[0];if(gi=void 0,i!=="Escape"&&!NS(i,t)){const n=vc(t);Mc(t,e?yg(i,n,{Equals:(r,s)=>r===s,GetHashCode:r=>wg(r)|0})?n:uh(n,[i]):[i]);for(let r=0;r<=Fs.length-1;r++){const s=w(r,Fs);if(Sc(s)!==Sc(t)){const o=vc(s),a=o.filter(l=>l!==i);a.length>0&&a.length!==o.length&&Mc(s,a)}}fv()}}}function cR(i){const e=vc(i);e.length>1&&(Mc(i,wS(e,0,e.length-1)),fv())}function uR(){gi=void 0,BS(),window.localStorage.removeItem(zh)}function dR(i){const e=AS();return Dt(We(()=>Lt(_t(new Nt(0,[k.Controllers])),We(()=>Lt(_t(new Nt(1,[k.Keyboard,()=>er()|0,t=>{er(t),Kh()}])),We(()=>Lt(e.length===0?_t(new Nt(7,[k.NoPads])):_r(),We(()=>Lt(gn(t=>{let n;const r=t.index|0;return Lt(_t(new Nt(1,[(n=w(0,$c(t.id,["("],void 0,0)).trim(),ie(te("%d · %s"))(r)(n)),()=>Kd(r).Slot|0,s=>{a0(r,o=>new Wd(s,o.Swap,o.Absolute))}])),We(()=>_t(new Nt(2,[k.SwapSticks,()=>Kd(r).Swap,s=>{a0(r,o=>new Wd(o.Slot,s,o.Absolute))}]))))},e),We(()=>Lt(_t(new Nt(0,[k.Bindings])),We(()=>Lt(_t(new Nt(7,[US()])),We(()=>Lt(_t(new Nt(7,[k.BindTaken])),We(()=>Lt(xn(t=>new Nt(8,[t]),Fs),We(()=>Lt(_t(new Nt(5,[k.ResetKeys,()=>{uR()}])),We(()=>Lt(i?_r():Lt(_t(new Nt(0,[k.Arena])),We(()=>Lt(_t(Nt.Arena),We(()=>_t(new Nt(2,[k.CatchUp,gc,t=>{gc(t),window.localStorage.setItem(av,Ci(t))}])))))),We(()=>Lt(_t(new Nt(0,[k.Video])),We(()=>Lt(_t(new Nt(2,[k.ReduceFlash,Ka,t=>{Ka(t),window.localStorage.setItem(lv,Ci(t))}])),We(()=>Lt(_t(new Nt(2,[k.ScreenShake,$o,t=>{$o(t),window.localStorage.setItem(ov,Ci(t))}])),We(()=>Lt(_t(new Nt(0,[k.Audio])),We(()=>Lt(_t(new Nt(3,[k.Music,1])),We(()=>Lt(_t(new Nt(3,[k.Sounds,0])),We(()=>Lt(tR&&!i?Lt(_t(new Nt(0,[k.Tuning])),We(()=>Lt(xn(t=>new Nt(4,[t]),kt(0,1,Ui.length-1)),We(()=>Lt(_t(new Nt(5,[k.Save,()=>{const t={};for(let n=0;n<=Ui.length-1;n++){const r=w(n,Ui);t[r[0]]=r[1]()}window.fetch("/__tweaks",{method:"POST",body:JSON.stringify(t)})}])),We(()=>_t(new Nt(5,[k.Reset,()=>{window.localStorage.removeItem(Gh),window.location.reload()}])))))))):_r(),We(()=>Kf()?Lt(_t(new Nt(0,[k.CrazyGames])),We(()=>_t(new Nt(5,[k.SignIn,()=>{Hh(Bn.Delay(()=>Bn.Bind(kh(FS()),t=>{const n=t;return n!=null&&n.username!=null&&cv()(n.username),Bn.Zero()})))}])))):_r()))))))))))))))))))))))))))))))))))))}function Xh(i){switch(i.tag){case 0:case 7:return!1;default:return!0}}function fR(i){let e,t,n;switch(i.tag){case 7:{e=0,t=i.fields[0];break}case 5:{e=0,t=i.fields[0];break}case 1:{e=1,n=i.fields[0];break}case 2:{e=1,n=i.fields[0];break}case 3:{e=1,n=i.fields[0];break}case 6:{e=2;break}case 8:{e=3;break}case 4:{e=4;break}default:e=0,t=i.fields[0]}switch(e){case 0:return t;case 1:return n;case 2:return k.Arena;case 3:return CS(i.fields[0]);default:return w(i.fields[0],Ui)[0]}}function hR(i){switch(i.tag){case 1:{const e=i.fields[1];return e()===bg?k.Auto:k.Player(e())}case 2:return i.fields[1]()?k.On:k.Off;case 3:{const e=i.fields[1]|0;if(Ic(e)===0)return k.Off;{const t=Ic(e)*100;return ie(te("%.0f%%"))(t)}}case 6:return uv();case 8:return oR(i.fields[0]);case 4:{const e=w(i.fields[0],Ui)[1]();return ie(te("%.3g"))(e)}default:return""}}function Nc(i,e){switch(i.tag){case 1:{i.fields[2]((i.fields[1]()+1+e+5)%5-1);break}case 2:{i.fields[2](!i.fields[1]());break}case 3:{const t=i.fields[1]|0;J_(t,Ic(t)+e*.1);break}case 6:{const t=uh(Wh(),new Int32Array([Mi.length]),Int32Array),n=xr(ja(r=>si()===r,t),0)|0;si(w((n+e+t.length)%t.length,t)),si()<Mi.length&&el(si()),window.localStorage.setItem(sv,Ps(si()));break}case 8:{const t=i.fields[0];e>0?gi=[t,!0]:cR(t);break}case 4:{const t=i.fields[0]|0,n=w(t,Ui),r=w(t,r0)/20;n[2](fe(0,$e(w(t,r0)*3,n[1]()+e*r))),nR();break}}}function pR(i){switch(i.tag){case 5:{i.fields[1]();break}case 8:{gi=[i.fields[0],!1];break}case 2:case 6:{Nc(i,1);break}case 3:{const e=i.fields[1]|0;J_(e,Ic(e)===0?1:0);break}}}function mR(){let i,e;iR(),rR(),sR(),RS(hv),LS(r=>{lR(r)});const t=window.localStorage.getItem(sv);if(t!==an()){let r,s=0;r=[PS(t,511,!1,32,new Wc(()=>s|0,a=>{s=a|0})),s];let o;switch(r[0]?(i=r[1]|0,i>=0&&i<Mi.length?o=0:r[1]===Mi.length?o=1:o=2):o=2,o){case 0:{const a=r[1]|0;si(a),el(a);break}case 1:{si(r[1]);break}}}dv(),gc(window.localStorage.getItem(av)!=="false");const n=window.localStorage.getItem(ov)==="false";$o(!n),Ka((e=window.localStorage.getItem(lv),e===an()?n:e==="true")),IS(()=>{Kh()})}function gR(i){return i&&i.__esModule&&Object.prototype.hasOwnProperty.call(i,"default")?i.default:i}var da={},sd,o0;function _R(){return o0||(o0=1,sd=function(){return typeof Promise=="function"&&Promise.prototype&&Promise.prototype.then}),sd}var ad={},Hr={},l0;function qs(){if(l0)return Hr;l0=1;let i;const e=[0,26,44,70,100,134,172,196,242,292,346,404,466,532,581,655,733,815,901,991,1085,1156,1258,1364,1474,1588,1706,1828,1921,2051,2185,2323,2465,2611,2761,2876,3034,3196,3362,3532,3706];return Hr.getSymbolSize=function(n){if(!n)throw new Error('"version" cannot be null or undefined');if(n<1||n>40)throw new Error('"version" should be in range from 1 to 40');return n*4+17},Hr.getSymbolTotalCodewords=function(n){return e[n]},Hr.getBCHDigit=function(t){let n=0;for(;t!==0;)n++,t>>>=1;return n},Hr.setToSJISFunction=function(n){if(typeof n!="function")throw new Error('"toSJISFunc" is not a valid function.');i=n},Hr.isKanjiModeEnabled=function(){return typeof i<"u"},Hr.toSJIS=function(n){return i(n)},Hr}var od={},c0;function qh(){return c0||(c0=1,(function(i){i.L={bit:1},i.M={bit:0},i.Q={bit:3},i.H={bit:2};function e(t){if(typeof t!="string")throw new Error("Param is not a string");switch(t.toLowerCase()){case"l":case"low":return i.L;case"m":case"medium":return i.M;case"q":case"quartile":return i.Q;case"h":case"high":return i.H;default:throw new Error("Unknown EC Level: "+t)}}i.isValid=function(n){return n&&typeof n.bit<"u"&&n.bit>=0&&n.bit<4},i.from=function(n,r){if(i.isValid(n))return n;try{return e(n)}catch{return r}}})(od)),od}var ld,u0;function vR(){if(u0)return ld;u0=1;function i(){this.buffer=[],this.length=0}return i.prototype={get:function(e){const t=Math.floor(e/8);return(this.buffer[t]>>>7-e%8&1)===1},put:function(e,t){for(let n=0;n<t;n++)this.putBit((e>>>t-n-1&1)===1)},getLengthInBits:function(){return this.length},putBit:function(e){const t=Math.floor(this.length/8);this.buffer.length<=t&&this.buffer.push(0),e&&(this.buffer[t]|=128>>>this.length%8),this.length++}},ld=i,ld}var cd,d0;function MR(){if(d0)return cd;d0=1;function i(e){if(!e||e<1)throw new Error("BitMatrix size must be defined and greater than 0");this.size=e,this.data=new Uint8Array(e*e),this.reservedBit=new Uint8Array(e*e)}return i.prototype.set=function(e,t,n,r){const s=e*this.size+t;this.data[s]=n,r&&(this.reservedBit[s]=!0)},i.prototype.get=function(e,t){return this.data[e*this.size+t]},i.prototype.xor=function(e,t,n){this.data[e*this.size+t]^=n},i.prototype.isReserved=function(e,t){return this.reservedBit[e*this.size+t]},cd=i,cd}var ud={},f0;function SR(){return f0||(f0=1,(function(i){const e=qs().getSymbolSize;i.getRowColCoords=function(n){if(n===1)return[];const r=Math.floor(n/7)+2,s=e(n),o=s===145?26:Math.ceil((s-13)/(2*r-2))*2,a=[s-7];for(let l=1;l<r-1;l++)a[l]=a[l-1]-o;return a.push(6),a.reverse()},i.getPositions=function(n){const r=[],s=i.getRowColCoords(n),o=s.length;for(let a=0;a<o;a++)for(let l=0;l<o;l++)a===0&&l===0||a===0&&l===o-1||a===o-1&&l===0||r.push([s[a],s[l]]);return r}})(ud)),ud}var dd={},h0;function xR(){if(h0)return dd;h0=1;const i=qs().getSymbolSize,e=7;return dd.getPositions=function(n){const r=i(n);return[[0,0],[r-e,0],[0,r-e]]},dd}var fd={},p0;function yR(){return p0||(p0=1,(function(i){i.Patterns={PATTERN000:0,PATTERN001:1,PATTERN010:2,PATTERN011:3,PATTERN100:4,PATTERN101:5,PATTERN110:6,PATTERN111:7};const e={N1:3,N2:3,N3:40,N4:10};i.isValid=function(r){return r!=null&&r!==""&&!isNaN(r)&&r>=0&&r<=7},i.from=function(r){return i.isValid(r)?parseInt(r,10):void 0},i.getPenaltyN1=function(r){const s=r.size;let o=0,a=0,l=0,u=null,c=null;for(let d=0;d<s;d++){a=l=0,u=c=null;for(let p=0;p<s;p++){let f=r.get(d,p);f===u?a++:(a>=5&&(o+=e.N1+(a-5)),u=f,a=1),f=r.get(p,d),f===c?l++:(l>=5&&(o+=e.N1+(l-5)),c=f,l=1)}a>=5&&(o+=e.N1+(a-5)),l>=5&&(o+=e.N1+(l-5))}return o},i.getPenaltyN2=function(r){const s=r.size;let o=0;for(let a=0;a<s-1;a++)for(let l=0;l<s-1;l++){const u=r.get(a,l)+r.get(a,l+1)+r.get(a+1,l)+r.get(a+1,l+1);(u===4||u===0)&&o++}return o*e.N2},i.getPenaltyN3=function(r){const s=r.size;let o=0,a=0,l=0;for(let u=0;u<s;u++){a=l=0;for(let c=0;c<s;c++)a=a<<1&2047|r.get(u,c),c>=10&&(a===1488||a===93)&&o++,l=l<<1&2047|r.get(c,u),c>=10&&(l===1488||l===93)&&o++}return o*e.N3},i.getPenaltyN4=function(r){let s=0;const o=r.data.length;for(let l=0;l<o;l++)s+=r.data[l];return Math.abs(Math.ceil(s*100/o/5)-10)*e.N4};function t(n,r,s){switch(n){case i.Patterns.PATTERN000:return(r+s)%2===0;case i.Patterns.PATTERN001:return r%2===0;case i.Patterns.PATTERN010:return s%3===0;case i.Patterns.PATTERN011:return(r+s)%3===0;case i.Patterns.PATTERN100:return(Math.floor(r/2)+Math.floor(s/3))%2===0;case i.Patterns.PATTERN101:return r*s%2+r*s%3===0;case i.Patterns.PATTERN110:return(r*s%2+r*s%3)%2===0;case i.Patterns.PATTERN111:return(r*s%3+(r+s)%2)%2===0;default:throw new Error("bad maskPattern:"+n)}}i.applyMask=function(r,s){const o=s.size;for(let a=0;a<o;a++)for(let l=0;l<o;l++)s.isReserved(l,a)||s.xor(l,a,t(r,l,a))},i.getBestMask=function(r,s){const o=Object.keys(i.Patterns).length;let a=0,l=1/0;for(let u=0;u<o;u++){s(u),i.applyMask(u,r);const c=i.getPenaltyN1(r)+i.getPenaltyN2(r)+i.getPenaltyN3(r)+i.getPenaltyN4(r);i.applyMask(u,r),c<l&&(l=c,a=u)}return a}})(fd)),fd}var Hl={},m0;function pv(){if(m0)return Hl;m0=1;const i=qh(),e=[1,1,1,1,1,1,1,1,1,1,2,2,1,2,2,4,1,2,4,4,2,4,4,4,2,4,6,5,2,4,6,6,2,5,8,8,4,5,8,8,4,5,8,11,4,8,10,11,4,9,12,16,4,9,16,16,6,10,12,18,6,10,17,16,6,11,16,19,6,13,18,21,7,14,21,25,8,16,20,25,8,17,23,25,9,17,23,34,9,18,25,30,10,20,27,32,12,21,29,35,12,23,34,37,12,25,34,40,13,26,35,42,14,28,38,45,15,29,40,48,16,31,43,51,17,33,45,54,18,35,48,57,19,37,51,60,19,38,53,63,20,40,56,66,21,43,59,70,22,45,62,74,24,47,65,77,25,49,68,81],t=[7,10,13,17,10,16,22,28,15,26,36,44,20,36,52,64,26,48,72,88,36,64,96,112,40,72,108,130,48,88,132,156,60,110,160,192,72,130,192,224,80,150,224,264,96,176,260,308,104,198,288,352,120,216,320,384,132,240,360,432,144,280,408,480,168,308,448,532,180,338,504,588,196,364,546,650,224,416,600,700,224,442,644,750,252,476,690,816,270,504,750,900,300,560,810,960,312,588,870,1050,336,644,952,1110,360,700,1020,1200,390,728,1050,1260,420,784,1140,1350,450,812,1200,1440,480,868,1290,1530,510,924,1350,1620,540,980,1440,1710,570,1036,1530,1800,570,1064,1590,1890,600,1120,1680,1980,630,1204,1770,2100,660,1260,1860,2220,720,1316,1950,2310,750,1372,2040,2430];return Hl.getBlocksCount=function(r,s){switch(s){case i.L:return e[(r-1)*4+0];case i.M:return e[(r-1)*4+1];case i.Q:return e[(r-1)*4+2];case i.H:return e[(r-1)*4+3];default:return}},Hl.getTotalCodewordsCount=function(r,s){switch(s){case i.L:return t[(r-1)*4+0];case i.M:return t[(r-1)*4+1];case i.Q:return t[(r-1)*4+2];case i.H:return t[(r-1)*4+3];default:return}},Hl}var hd={},ho={},g0;function TR(){if(g0)return ho;g0=1;const i=new Uint8Array(512),e=new Uint8Array(256);return(function(){let n=1;for(let r=0;r<255;r++)i[r]=n,e[n]=r,n<<=1,n&256&&(n^=285);for(let r=255;r<512;r++)i[r]=i[r-255]})(),ho.log=function(n){if(n<1)throw new Error("log("+n+")");return e[n]},ho.exp=function(n){return i[n]},ho.mul=function(n,r){return n===0||r===0?0:i[e[n]+e[r]]},ho}var _0;function bR(){return _0||(_0=1,(function(i){const e=TR();i.mul=function(n,r){const s=new Uint8Array(n.length+r.length-1);for(let o=0;o<n.length;o++)for(let a=0;a<r.length;a++)s[o+a]^=e.mul(n[o],r[a]);return s},i.mod=function(n,r){let s=new Uint8Array(n);for(;s.length-r.length>=0;){const o=s[0];for(let l=0;l<r.length;l++)s[l]^=e.mul(r[l],o);let a=0;for(;a<s.length&&s[a]===0;)a++;s=s.slice(a)}return s},i.generateECPolynomial=function(n){let r=new Uint8Array([1]);for(let s=0;s<n;s++)r=i.mul(r,new Uint8Array([1,e.exp(s)]));return r}})(hd)),hd}var pd,v0;function ER(){if(v0)return pd;v0=1;const i=bR();function e(t){this.genPoly=void 0,this.degree=t,this.degree&&this.initialize(this.degree)}return e.prototype.initialize=function(n){this.degree=n,this.genPoly=i.generateECPolynomial(this.degree)},e.prototype.encode=function(n){if(!this.genPoly)throw new Error("Encoder not initialized");const r=new Uint8Array(n.length+this.degree);r.set(n);const s=i.mod(r,this.genPoly),o=this.degree-s.length;if(o>0){const a=new Uint8Array(this.degree);return a.set(s,o),a}return s},pd=e,pd}var md={},gd={},_d={},M0;function mv(){return M0||(M0=1,_d.isValid=function(e){return!isNaN(e)&&e>=1&&e<=40}),_d}var qi={},S0;function gv(){if(S0)return qi;S0=1;const i="[0-9]+",e="[A-Z $%*+\\-./:]+";let t="(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";t=t.replace(/u/g,"\\u");const n="(?:(?![A-Z0-9 $%*+\\-./:]|"+t+`)(?:.|[\r
]))+`;qi.KANJI=new RegExp(t,"g"),qi.BYTE_KANJI=new RegExp("[^A-Z0-9 $%*+\\-./:]+","g"),qi.BYTE=new RegExp(n,"g"),qi.NUMERIC=new RegExp(i,"g"),qi.ALPHANUMERIC=new RegExp(e,"g");const r=new RegExp("^"+t+"$"),s=new RegExp("^"+i+"$"),o=new RegExp("^[A-Z0-9 $%*+\\-./:]+$");return qi.testKanji=function(l){return r.test(l)},qi.testNumeric=function(l){return s.test(l)},qi.testAlphanumeric=function(l){return o.test(l)},qi}var x0;function Ys(){return x0||(x0=1,(function(i){const e=mv(),t=gv();i.NUMERIC={id:"Numeric",bit:1,ccBits:[10,12,14]},i.ALPHANUMERIC={id:"Alphanumeric",bit:2,ccBits:[9,11,13]},i.BYTE={id:"Byte",bit:4,ccBits:[8,16,16]},i.KANJI={id:"Kanji",bit:8,ccBits:[8,10,12]},i.MIXED={bit:-1},i.getCharCountIndicator=function(s,o){if(!s.ccBits)throw new Error("Invalid mode: "+s);if(!e.isValid(o))throw new Error("Invalid version: "+o);return o>=1&&o<10?s.ccBits[0]:o<27?s.ccBits[1]:s.ccBits[2]},i.getBestModeForData=function(s){return t.testNumeric(s)?i.NUMERIC:t.testAlphanumeric(s)?i.ALPHANUMERIC:t.testKanji(s)?i.KANJI:i.BYTE},i.toString=function(s){if(s&&s.id)return s.id;throw new Error("Invalid mode")},i.isValid=function(s){return s&&s.bit&&s.ccBits};function n(r){if(typeof r!="string")throw new Error("Param is not a string");switch(r.toLowerCase()){case"numeric":return i.NUMERIC;case"alphanumeric":return i.ALPHANUMERIC;case"kanji":return i.KANJI;case"byte":return i.BYTE;default:throw new Error("Unknown mode: "+r)}}i.from=function(s,o){if(i.isValid(s))return s;try{return n(s)}catch{return o}}})(gd)),gd}var y0;function AR(){return y0||(y0=1,(function(i){const e=qs(),t=pv(),n=qh(),r=Ys(),s=mv(),o=7973,a=e.getBCHDigit(o);function l(p,f,_){for(let m=1;m<=40;m++)if(f<=i.getCapacity(m,_,p))return m}function u(p,f){return r.getCharCountIndicator(p,f)+4}function c(p,f){let _=0;return p.forEach(function(m){const g=u(m.mode,f);_+=g+m.getBitsLength()}),_}function d(p,f){for(let _=1;_<=40;_++)if(c(p,_)<=i.getCapacity(_,f,r.MIXED))return _}i.from=function(f,_){return s.isValid(f)?parseInt(f,10):_},i.getCapacity=function(f,_,m){if(!s.isValid(f))throw new Error("Invalid QR Code version");typeof m>"u"&&(m=r.BYTE);const g=e.getSymbolTotalCodewords(f),h=t.getTotalCodewordsCount(f,_),v=(g-h)*8;if(m===r.MIXED)return v;const M=v-u(m,f);switch(m){case r.NUMERIC:return Math.floor(M/10*3);case r.ALPHANUMERIC:return Math.floor(M/11*2);case r.KANJI:return Math.floor(M/13);case r.BYTE:default:return Math.floor(M/8)}},i.getBestVersionForData=function(f,_){let m;const g=n.from(_,n.M);if(Array.isArray(f)){if(f.length>1)return d(f,g);if(f.length===0)return 1;m=f[0]}else m=f;return l(m.mode,m.getLength(),g)},i.getEncodedBits=function(f){if(!s.isValid(f)||f<7)throw new Error("Invalid QR Code version");let _=f<<12;for(;e.getBCHDigit(_)-a>=0;)_^=o<<e.getBCHDigit(_)-a;return f<<12|_}})(md)),md}var vd={},T0;function wR(){if(T0)return vd;T0=1;const i=qs(),e=1335,t=21522,n=i.getBCHDigit(e);return vd.getEncodedBits=function(s,o){const a=s.bit<<3|o;let l=a<<10;for(;i.getBCHDigit(l)-n>=0;)l^=e<<i.getBCHDigit(l)-n;return(a<<10|l)^t},vd}var Md={},Sd,b0;function CR(){if(b0)return Sd;b0=1;const i=Ys();function e(t){this.mode=i.NUMERIC,this.data=t.toString()}return e.getBitsLength=function(n){return 10*Math.floor(n/3)+(n%3?n%3*3+1:0)},e.prototype.getLength=function(){return this.data.length},e.prototype.getBitsLength=function(){return e.getBitsLength(this.data.length)},e.prototype.write=function(n){let r,s,o;for(r=0;r+3<=this.data.length;r+=3)s=this.data.substr(r,3),o=parseInt(s,10),n.put(o,10);const a=this.data.length-r;a>0&&(s=this.data.substr(r),o=parseInt(s,10),n.put(o,a*3+1))},Sd=e,Sd}var xd,E0;function RR(){if(E0)return xd;E0=1;const i=Ys(),e=["0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"," ","$","%","*","+","-",".","/",":"];function t(n){this.mode=i.ALPHANUMERIC,this.data=n}return t.getBitsLength=function(r){return 11*Math.floor(r/2)+6*(r%2)},t.prototype.getLength=function(){return this.data.length},t.prototype.getBitsLength=function(){return t.getBitsLength(this.data.length)},t.prototype.write=function(r){let s;for(s=0;s+2<=this.data.length;s+=2){let o=e.indexOf(this.data[s])*45;o+=e.indexOf(this.data[s+1]),r.put(o,11)}this.data.length%2&&r.put(e.indexOf(this.data[s]),6)},xd=t,xd}var yd,A0;function LR(){if(A0)return yd;A0=1;const i=Ys();function e(t){this.mode=i.BYTE,typeof t=="string"?this.data=new TextEncoder().encode(t):this.data=new Uint8Array(t)}return e.getBitsLength=function(n){return n*8},e.prototype.getLength=function(){return this.data.length},e.prototype.getBitsLength=function(){return e.getBitsLength(this.data.length)},e.prototype.write=function(t){for(let n=0,r=this.data.length;n<r;n++)t.put(this.data[n],8)},yd=e,yd}var Td,w0;function PR(){if(w0)return Td;w0=1;const i=Ys(),e=qs();function t(n){this.mode=i.KANJI,this.data=n}return t.getBitsLength=function(r){return r*13},t.prototype.getLength=function(){return this.data.length},t.prototype.getBitsLength=function(){return t.getBitsLength(this.data.length)},t.prototype.write=function(n){let r;for(r=0;r<this.data.length;r++){let s=e.toSJIS(this.data[r]);if(s>=33088&&s<=40956)s-=33088;else if(s>=57408&&s<=60351)s-=49472;else throw new Error("Invalid SJIS character: "+this.data[r]+`
Make sure your charset is UTF-8`);s=(s>>>8&255)*192+(s&255),n.put(s,13)}},Td=t,Td}var bd={exports:{}},C0;function IR(){return C0||(C0=1,(function(i){var e={single_source_shortest_paths:function(t,n,r){var s={},o={};o[n]=0;var a=e.PriorityQueue.make();a.push(n,0);for(var l,u,c,d,p,f,_,m,g;!a.empty();){l=a.pop(),u=l.value,d=l.cost,p=t[u]||{};for(c in p)p.hasOwnProperty(c)&&(f=p[c],_=d+f,m=o[c],g=typeof o[c]>"u",(g||m>_)&&(o[c]=_,a.push(c,_),s[c]=u))}if(typeof r<"u"&&typeof o[r]>"u"){var h=["Could not find a path from ",n," to ",r,"."].join("");throw new Error(h)}return s},extract_shortest_path_from_predecessor_list:function(t,n){for(var r=[],s=n;s;)r.push(s),t[s],s=t[s];return r.reverse(),r},find_path:function(t,n,r){var s=e.single_source_shortest_paths(t,n,r);return e.extract_shortest_path_from_predecessor_list(s,r)},PriorityQueue:{make:function(t){var n=e.PriorityQueue,r={},s;t=t||{};for(s in n)n.hasOwnProperty(s)&&(r[s]=n[s]);return r.queue=[],r.sorter=t.sorter||n.default_sorter,r},default_sorter:function(t,n){return t.cost-n.cost},push:function(t,n){var r={value:t,cost:n};this.queue.push(r),this.queue.sort(this.sorter)},pop:function(){return this.queue.shift()},empty:function(){return this.queue.length===0}}};i.exports=e})(bd)),bd.exports}var R0;function DR(){return R0||(R0=1,(function(i){const e=Ys(),t=CR(),n=RR(),r=LR(),s=PR(),o=gv(),a=qs(),l=IR();function u(h){return unescape(encodeURIComponent(h)).length}function c(h,v,M){const S=[];let P;for(;(P=h.exec(M))!==null;)S.push({data:P[0],index:P.index,mode:v,length:P[0].length});return S}function d(h){const v=c(o.NUMERIC,e.NUMERIC,h),M=c(o.ALPHANUMERIC,e.ALPHANUMERIC,h);let S,P;return a.isKanjiModeEnabled()?(S=c(o.BYTE,e.BYTE,h),P=c(o.KANJI,e.KANJI,h)):(S=c(o.BYTE_KANJI,e.BYTE,h),P=[]),v.concat(M,S,P).sort(function(A,L){return A.index-L.index}).map(function(A){return{data:A.data,mode:A.mode,length:A.length}})}function p(h,v){switch(v){case e.NUMERIC:return t.getBitsLength(h);case e.ALPHANUMERIC:return n.getBitsLength(h);case e.KANJI:return s.getBitsLength(h);case e.BYTE:return r.getBitsLength(h)}}function f(h){return h.reduce(function(v,M){const S=v.length-1>=0?v[v.length-1]:null;return S&&S.mode===M.mode?(v[v.length-1].data+=M.data,v):(v.push(M),v)},[])}function _(h){const v=[];for(let M=0;M<h.length;M++){const S=h[M];switch(S.mode){case e.NUMERIC:v.push([S,{data:S.data,mode:e.ALPHANUMERIC,length:S.length},{data:S.data,mode:e.BYTE,length:S.length}]);break;case e.ALPHANUMERIC:v.push([S,{data:S.data,mode:e.BYTE,length:S.length}]);break;case e.KANJI:v.push([S,{data:S.data,mode:e.BYTE,length:u(S.data)}]);break;case e.BYTE:v.push([{data:S.data,mode:e.BYTE,length:u(S.data)}])}}return v}function m(h,v){const M={},S={start:{}};let P=["start"];for(let E=0;E<h.length;E++){const A=h[E],L=[];for(let y=0;y<A.length;y++){const x=A[y],C=""+E+y;L.push(C),M[C]={node:x,lastCount:0},S[C]={};for(let N=0;N<P.length;N++){const D=P[N];M[D]&&M[D].node.mode===x.mode?(S[D][C]=p(M[D].lastCount+x.length,x.mode)-p(M[D].lastCount,x.mode),M[D].lastCount+=x.length):(M[D]&&(M[D].lastCount=x.length),S[D][C]=p(x.length,x.mode)+4+e.getCharCountIndicator(x.mode,v))}}P=L}for(let E=0;E<P.length;E++)S[P[E]].end=0;return{map:S,table:M}}function g(h,v){let M;const S=e.getBestModeForData(h);if(M=e.from(v,S),M!==e.BYTE&&M.bit<S.bit)throw new Error('"'+h+'" cannot be encoded with mode '+e.toString(M)+`.
 Suggested mode is: `+e.toString(S));switch(M===e.KANJI&&!a.isKanjiModeEnabled()&&(M=e.BYTE),M){case e.NUMERIC:return new t(h);case e.ALPHANUMERIC:return new n(h);case e.KANJI:return new s(h);case e.BYTE:return new r(h)}}i.fromArray=function(v){return v.reduce(function(M,S){return typeof S=="string"?M.push(g(S,null)):S.data&&M.push(g(S.data,S.mode)),M},[])},i.fromString=function(v,M){const S=d(v,a.isKanjiModeEnabled()),P=_(S),E=m(P,M),A=l.find_path(E.map,"start","end"),L=[];for(let y=1;y<A.length-1;y++)L.push(E.table[A[y]].node);return i.fromArray(f(L))},i.rawSplit=function(v){return i.fromArray(d(v,a.isKanjiModeEnabled()))}})(Md)),Md}var L0;function NR(){if(L0)return ad;L0=1;const i=qs(),e=qh(),t=vR(),n=MR(),r=SR(),s=xR(),o=yR(),a=pv(),l=ER(),u=AR(),c=wR(),d=Ys(),p=DR();function f(E,A){const L=E.size,y=s.getPositions(A);for(let x=0;x<y.length;x++){const C=y[x][0],N=y[x][1];for(let D=-1;D<=7;D++)if(!(C+D<=-1||L<=C+D))for(let I=-1;I<=7;I++)N+I<=-1||L<=N+I||(D>=0&&D<=6&&(I===0||I===6)||I>=0&&I<=6&&(D===0||D===6)||D>=2&&D<=4&&I>=2&&I<=4?E.set(C+D,N+I,!0,!0):E.set(C+D,N+I,!1,!0))}}function _(E){const A=E.size;for(let L=8;L<A-8;L++){const y=L%2===0;E.set(L,6,y,!0),E.set(6,L,y,!0)}}function m(E,A){const L=r.getPositions(A);for(let y=0;y<L.length;y++){const x=L[y][0],C=L[y][1];for(let N=-2;N<=2;N++)for(let D=-2;D<=2;D++)N===-2||N===2||D===-2||D===2||N===0&&D===0?E.set(x+N,C+D,!0,!0):E.set(x+N,C+D,!1,!0)}}function g(E,A){const L=E.size,y=u.getEncodedBits(A);let x,C,N;for(let D=0;D<18;D++)x=Math.floor(D/3),C=D%3+L-8-3,N=(y>>D&1)===1,E.set(x,C,N,!0),E.set(C,x,N,!0)}function h(E,A,L){const y=E.size,x=c.getEncodedBits(A,L);let C,N;for(C=0;C<15;C++)N=(x>>C&1)===1,C<6?E.set(C,8,N,!0):C<8?E.set(C+1,8,N,!0):E.set(y-15+C,8,N,!0),C<8?E.set(8,y-C-1,N,!0):C<9?E.set(8,15-C-1+1,N,!0):E.set(8,15-C-1,N,!0);E.set(y-8,8,1,!0)}function v(E,A){const L=E.size;let y=-1,x=L-1,C=7,N=0;for(let D=L-1;D>0;D-=2)for(D===6&&D--;;){for(let I=0;I<2;I++)if(!E.isReserved(x,D-I)){let J=!1;N<A.length&&(J=(A[N]>>>C&1)===1),E.set(x,D-I,J),C--,C===-1&&(N++,C=7)}if(x+=y,x<0||L<=x){x-=y,y=-y;break}}}function M(E,A,L){const y=new t;L.forEach(function(I){y.put(I.mode.bit,4),y.put(I.getLength(),d.getCharCountIndicator(I.mode,E)),I.write(y)});const x=i.getSymbolTotalCodewords(E),C=a.getTotalCodewordsCount(E,A),N=(x-C)*8;for(y.getLengthInBits()+4<=N&&y.put(0,4);y.getLengthInBits()%8!==0;)y.putBit(0);const D=(N-y.getLengthInBits())/8;for(let I=0;I<D;I++)y.put(I%2?17:236,8);return S(y,E,A)}function S(E,A,L){const y=i.getSymbolTotalCodewords(A),x=a.getTotalCodewordsCount(A,L),C=y-x,N=a.getBlocksCount(A,L),D=y%N,I=N-D,J=Math.floor(y/N),q=Math.floor(C/N),oe=q+1,X=J-q,he=new l(X);let pe=0;const Se=new Array(N),Ne=new Array(N);let nt=0;const Z=new Uint8Array(E.buffer);for(let ze=0;ze<N;ze++){const Ze=ze<I?q:oe;Se[ze]=Z.slice(pe,pe+Ze),Ne[ze]=he.encode(Se[ze]),pe+=Ze,nt=Math.max(nt,Ze)}const le=new Uint8Array(y);let Ce=0,ue,Pe;for(ue=0;ue<nt;ue++)for(Pe=0;Pe<N;Pe++)ue<Se[Pe].length&&(le[Ce++]=Se[Pe][ue]);for(ue=0;ue<X;ue++)for(Pe=0;Pe<N;Pe++)le[Ce++]=Ne[Pe][ue];return le}function P(E,A,L,y){let x;if(Array.isArray(E))x=p.fromArray(E);else if(typeof E=="string"){let J=A;if(!J){const q=p.rawSplit(E);J=u.getBestVersionForData(q,L)}x=p.fromString(E,J||40)}else throw new Error("Invalid data");const C=u.getBestVersionForData(x,L);if(!C)throw new Error("The amount of data is too big to be stored in a QR Code");if(!A)A=C;else if(A<C)throw new Error(`
The chosen QR Code version cannot contain this amount of data.
Minimum version required to store current data is: `+C+`.
`);const N=M(A,L,x),D=i.getSymbolSize(A),I=new n(D);return f(I,A),_(I),m(I,A),h(I,L,0),A>=7&&g(I,A),v(I,N),isNaN(y)&&(y=o.getBestMask(I,h.bind(null,I,L))),o.applyMask(y,I),h(I,L,y),{modules:I,version:A,errorCorrectionLevel:L,maskPattern:y,segments:x}}return ad.create=function(A,L){if(typeof A>"u"||A==="")throw new Error("No input text");let y=e.M,x,C;return typeof L<"u"&&(y=e.from(L.errorCorrectionLevel,e.M),x=u.from(L.version),C=o.from(L.maskPattern),L.toSJISFunc&&i.setToSJISFunction(L.toSJISFunc)),P(A,x,y,C)},ad}var Ed={},Ad={},P0;function _v(){return P0||(P0=1,(function(i){function e(t){if(typeof t=="number"&&(t=t.toString()),typeof t!="string")throw new Error("Color should be defined as hex string");let n=t.slice().replace("#","").split("");if(n.length<3||n.length===5||n.length>8)throw new Error("Invalid hex color: "+t);(n.length===3||n.length===4)&&(n=Array.prototype.concat.apply([],n.map(function(s){return[s,s]}))),n.length===6&&n.push("F","F");const r=parseInt(n.join(""),16);return{r:r>>24&255,g:r>>16&255,b:r>>8&255,a:r&255,hex:"#"+n.slice(0,6).join("")}}i.getOptions=function(n){n||(n={}),n.color||(n.color={});const r=typeof n.margin>"u"||n.margin===null||n.margin<0?4:n.margin,s=n.width&&n.width>=21?n.width:void 0,o=n.scale||4;return{width:s,scale:s?4:o,margin:r,color:{dark:e(n.color.dark||"#000000ff"),light:e(n.color.light||"#ffffffff")},type:n.type,rendererOpts:n.rendererOpts||{}}},i.getScale=function(n,r){return r.width&&r.width>=n+r.margin*2?r.width/(n+r.margin*2):r.scale},i.getImageWidth=function(n,r){const s=i.getScale(n,r);return Math.floor((n+r.margin*2)*s)},i.qrToImageData=function(n,r,s){const o=r.modules.size,a=r.modules.data,l=i.getScale(o,s),u=Math.floor((o+s.margin*2)*l),c=s.margin*l,d=[s.color.light,s.color.dark];for(let p=0;p<u;p++)for(let f=0;f<u;f++){let _=(p*u+f)*4,m=s.color.light;if(p>=c&&f>=c&&p<u-c&&f<u-c){const g=Math.floor((p-c)/l),h=Math.floor((f-c)/l);m=d[a[g*o+h]?1:0]}n[_++]=m.r,n[_++]=m.g,n[_++]=m.b,n[_]=m.a}}})(Ad)),Ad}var I0;function UR(){return I0||(I0=1,(function(i){const e=_v();function t(r,s,o){r.clearRect(0,0,s.width,s.height),s.style||(s.style={}),s.height=o,s.width=o,s.style.height=o+"px",s.style.width=o+"px"}function n(){try{return document.createElement("canvas")}catch{throw new Error("You need to specify a canvas element")}}i.render=function(s,o,a){let l=a,u=o;typeof l>"u"&&(!o||!o.getContext)&&(l=o,o=void 0),o||(u=n()),l=e.getOptions(l);const c=e.getImageWidth(s.modules.size,l),d=u.getContext("2d"),p=d.createImageData(c,c);return e.qrToImageData(p.data,s,l),t(d,u,c),d.putImageData(p,0,0),u},i.renderToDataURL=function(s,o,a){let l=a;typeof l>"u"&&(!o||!o.getContext)&&(l=o,o=void 0),l||(l={});const u=i.render(s,o,l),c=l.type||"image/png",d=l.rendererOpts||{};return u.toDataURL(c,d.quality)}})(Ed)),Ed}var wd={},D0;function FR(){if(D0)return wd;D0=1;const i=_v();function e(r,s){const o=r.a/255,a=s+'="'+r.hex+'"';return o<1?a+" "+s+'-opacity="'+o.toFixed(2).slice(1)+'"':a}function t(r,s,o){let a=r+s;return typeof o<"u"&&(a+=" "+o),a}function n(r,s,o){let a="",l=0,u=!1,c=0;for(let d=0;d<r.length;d++){const p=Math.floor(d%s),f=Math.floor(d/s);!p&&!u&&(u=!0),r[d]?(c++,d>0&&p>0&&r[d-1]||(a+=u?t("M",p+o,.5+f+o):t("m",l,0),l=0,u=!1),p+1<s&&r[d+1]||(a+=t("h",c),c=0)):l++}return a}return wd.render=function(s,o,a){const l=i.getOptions(o),u=s.modules.size,c=s.modules.data,d=u+l.margin*2,p=l.color.light.a?"<path "+e(l.color.light,"fill")+' d="M0 0h'+d+"v"+d+'H0z"/>':"",f="<path "+e(l.color.dark,"stroke")+' d="'+n(c,u,l.margin)+'"/>',_='viewBox="0 0 '+d+" "+d+'"',g='<svg xmlns="http://www.w3.org/2000/svg" '+(l.width?'width="'+l.width+'" height="'+l.width+'" ':"")+_+' shape-rendering="crispEdges">'+p+f+`</svg>
`;return typeof a=="function"&&a(null,g),g},wd}var N0;function BR(){if(N0)return da;N0=1;const i=_R(),e=NR(),t=UR(),n=FR();function r(s,o,a,l,u){const c=[].slice.call(arguments,1),d=c.length,p=typeof c[d-1]=="function";if(!p&&!i())throw new Error("Callback required as last argument");if(p){if(d<2)throw new Error("Too few arguments provided");d===2?(u=a,a=o,o=l=void 0):d===3&&(o.getContext&&typeof u>"u"?(u=l,l=void 0):(u=l,l=a,a=o,o=void 0))}else{if(d<1)throw new Error("Too few arguments provided");return d===1?(a=o,o=l=void 0):d===2&&!o.getContext&&(l=a,a=o,o=void 0),new Promise(function(f,_){try{const m=e.create(a,l);f(s(m,o,l))}catch(m){_(m)}})}try{const f=e.create(a,l);u(null,s(f,o,l))}catch(f){u(f)}}return da.create=e.create,da.toCanvas=r.bind(null,t.render),da.toDataURL=r.bind(null,t.renderToDataURL),da.toString=r.bind(null,function(s,o,a){return n.render(s,a)}),da}var OR=BR();const kR=gR(OR);function HR(i){const{size:e,data:t}=kR.create(i,{errorCorrectionLevel:"M"}).modules;let n="";for(let r=0;r<e;r++)for(let s=0;s<e;s++)t[r*e+s]&&(n+=`<circle cx="${s+.5}" cy="${r+.5}" r="0.42"/>`);return`<svg viewBox="0 0 ${e} ${e}" fill="currentColor">${n}</svg>`}const zr=class zr extends Ks{constructor(e,t){super(),this.tag=e,this.fields=t}cases(){return["Lobby","Options","Pause","Result"]}};pn(zr,"Lobby",new zr(0,[])),pn(zr,"Options",new zr(1,[])),pn(zr,"Pause",new zr(2,[]));let dn=zr;const qn=class qn extends Ks{constructor(e,t){super(),this.tag=e,this.fields=t}cases(){return["Resume","Rematch","Restart","Quit","Configure","Cancel"]}};pn(qn,"Resume",new qn(0,[])),pn(qn,"Rematch",new qn(1,[])),pn(qn,"Restart",new qn(2,[])),pn(qn,"Quit",new qn(3,[])),pn(qn,"Configure",new qn(4,[])),pn(qn,"Cancel",new qn(5,[]));let ii=qn;const ut=new Set([]),hn=new Int32Array(4),Sr=new Int32Array(4),_i=Nn(new Array(4),0,4,"");let qa=Tt(0),Ya=Tt(0),Er=Tt(0),Qr=Tt(new Int32Array(0)),es=Tt(Nn(new Int32Array(3),0,3,0)),Uc=Tt(!1);function Xf(){return lx(cx(),"yyyy-MM-dd")}function Cd(){try{const i=so("nda-high-score"),e=so("nda-matches-played"),t=so("nda-xp"),n=so("nda-daily"),r=so("nda-ad-seen"),s=c=>c==null||c===""?0:yh(c,511,!1,32)|0;qa(s(i)),Ya(s(e)),Er(s(t)),Uc(r==="1");const o=gp(Xf(),n??"");Qr(o[1]),es(o[2]);const a=qa()|0,l=Ya()|0,u=Er()|0;zo(te("Loaded progress: high score %d, matches %d, xp %d"))(a)(l)(u)}catch(i){const e=gp(Xf(),"");Qr(e[1]),es(e[2]);const t=i.message;zo(te("Failed to load progress: %s"))(t)}}function VR(){if(!Uc()){Uc(!0);try{vo("nda-ad-seen","1")}catch(i){const e=i.message;zo(te("Failed to save ad-seen: %s"))(e)}}}function vv(){try{vo("nda-high-score",Ps(qa())),vo("nda-matches-played",Ps(Ya())),vo("nda-xp",Ps(Er())),vo("nda-daily",ox(Xf(),Qr(),es()));const i=qa()|0,e=Ya()|0,t=Er()|0;zo(te("Saved progress: high score %d, matches %d, xp %d"))(i)(e)(t)}catch(i){const e=i.message;zo(te("Failed to save progress: %s"))(e)}}function GR(){QS(()=>w(0,_i)),cv(i=>{ve(_i,0,i)}),Cd(),Hh(Bn.Delay(()=>Bn.Bind(kh(ex()),i=>{const e=i;return Kf(e==null),e!=null&&e.username!=null&&(ve(_i,0,e.username),Cd()),Bn.Zero()}))),tx(i=>{i!=null&&i.username!=null&&(ve(_i,0,i.username),Kf(!1),Cd())})}let nn=Tt(dn.Lobby),Yh=Tt(""),uu=!0,ji=0,pr;const qr=Nn(new Int32Array(4),0,4,5),$n=Nn(new Array(4),0,4,!1),Oi=Nn(new Array(4),0,4,!1),Vi=Nn(new Array(4),0,4,"");let vi=!1,Ar=!1,Is=!1,wr=-1;function zR(){return Ar}function WR(){return Is}let Ri=Re(),ri=0,ma=0,qf=dn.Lobby,ic=0;const zs=new Set([]),zi=document.getElementById("menu"),KR=["#00f6ff","#ff2bd6","#b6ff3b","#ffb347"],XR=["","#3b7bff","#ff3b5c"],Vl=11;let Ts="",Yf="",$f=!1;function $h(i){return i===Yf?!1:(Yf=i,zi.innerHTML=i,!0)}function qR(){Yf=""}Ts===""&&Os()!==""&&(Ts=Os());function as(){return uu}function zt(i,e,t){const n=i+e;return t?Fa(n,zs):(zs.delete(n),!1)}function Rd(i,e,t){const n=i+e,r=Date.now();return t?Fa(n,zs)?(ic=r+340,!0):r>=ic?(ic=r+90,!0):!1:(zs.delete(n),!1)}function Mv(){const i=mt(Ye(Dt(We(()=>xn(e=>e.Key,li()))),Dt(We(()=>xn(e=>ie(te("s%d"))(e),kt(0,1,3))))));try{for(;i["System.Collections.IEnumerator.MoveNext"]();){const e=i["System.Collections.Generic.IEnumerator`1.get_Current"](),t=mt(["fire","start","back","up","down","left","right"]);try{for(;t["System.Collections.IEnumerator.MoveNext"]();)Fa(e+t["System.Collections.Generic.IEnumerator`1.get_Current"](),zs)}finally{yt(t)}}}finally{yt(i)}ic=Date.now()+340}function ol(i){nn(i),ji=0,pr=void 0,uu=!0,Mv(),zi.className=i.tag===0||i.tag===1?"":"play"}function Sv(){ol(dn.Lobby),jc()}function xv(){ol(dn.Pause),jc()}function U0(i){ol(new dn(3,[i])),jc()}function Zh(){uu=!1,Mv(),zi.className="hidden"}function Zf(){const i=nn(),e=pr;return e!=null?Ke([[k.No,ii.Cancel],[k.Yes,e]]):i.tag===2?Ke([[k.Resume,ii.Resume],[k.Settings,ii.Configure],[k.Restart,ii.Restart],[k.Quit,ii.Quit]]):Ke([[k.Rematch,ii.Rematch],[k.Quit,ii.Quit]])}function YR(i){return w(i,["",k.Blue,k.Red])}function yv(i,e){return xc(t=>t!==i?w(t,Hn)===e:!1,ut)}function $R(i,e){let t;const n=Xs(s=>s===w(i,Hn)?!0:!yv(i,s),Dt(kt(0,1,3))),r=Cg((t=w(i,Hn)|0,s=>t===s),n)|0;Hn[i]=Wr((r+e+Go(n))%Go(n),n)|0}const $a="bot";function Gi(i){return ut.has(i)?w(i,Vi)===$a:!1}function ZR(){return Ar?!1:!xc(Gi,ut)}function jR(){ot(Is),dv();for(let e=0;e<=3;e++)Gi(e)||ve($n,e,!1);Nn(Sr,0,4,0);const i=Dt(xh(ut,{Compare:(e,t)=>fn(e,t)|0}));vi?mp((e,t)=>{ve(hn,t,1+e%2|0)},i):(Nn(hn,0,4,0),mp((e,t)=>{Hn[t]=e|0},i))}function $s(i,e){if(i!==$a&&GS(i,e),Nn(Sr,0,4,0),ve(Vi,e,i),Fa(e,ut),ve($n,e,!1),ve(Oi,e,!1),ve(hn,e,0),vi){const t=n=>XS(Ig(r=>w(r,hn)===n,ut))|0;ve(hn,e,(t(1)<=t(2)?1:2)|0)}else Hn[e]=zS(t=>!yv(e,t),Dt(kt(0,1,3)))|0;if(i===$a)ve(_i,e,k.Bot),ve($n,e,!0);else{const t=Zc(n=>n.Key===i,li());if(t!=null){const n=t;n.Name!==""&&ve(_i,e,n.Name)}}}$s("kb",0);$s($a,1);function JR(){const i=Bs(e=>!ut.has(e),Dt(kt(0,1,3)));if(i==null){const e=ki(ut);for(let t=0;t<=e.length-1;t++){const n=w(t,e)|0;Gi(n)&&(ut.delete(n),ve($n,n,!1),ve(hn,n,0))}}else $s($a,i)}function QR(){let i;const e=li();for(let t=0;t<=e.length-1;t++){const n=w(t,e),r=n.Slot>=0&&ut.has(n.Slot)&&w(n.Slot,Vi)===n.Key,s=zt(n.Key,"start",n.Input.Start)?!0:zt(n.Key,"fire",n.Input.Fire);if(!r&&s&&i==null){const o=Yi(Bs(a=>!ut.has(a),Dt(kt(0,1,3))),Bs(a=>Gi(a)?a!==ai():!1,Dt(kt(0,1,3))));if(o!=null){const a=o|0,l=Gi(a);$s(n.Key,a),ve($n,a,!0),Fa(ie(te("s%dstart"))(a),zs),Fa(ie(te("s%dfire"))(a),zs),i=[a,l]}}}return i}function e2(){const i=Bs(e=>!ut.has(e),Dt(kt(0,1,3)));if(i==null)return-1;{const e=i|0;return $s($a,e),e|0}}function jh(i){ut.delete(i),Nn(Sr,0,4,0),ve($n,i,!1),ve(Oi,i,!1),ve(hn,i,0)}function t2(){return qS(i=>w(i,$n),ut)}function Tv(){return xc(i=>w(i,hn)===1,ut)?xc(i=>w(i,hn)===2,ut):!1}function rc(){return Ar?ut.size>=1:ut.size>=2&&t2()?vi?Tv():!0:!1}function n2(){return Ar?k.Practice:Is?k.Race:vi?k.Teams:k.Ffa}function i2(){return Ar?k.ModePractice:Is?k.ModeRace(~~lc()):vi?k.ModeTeams:k.ModeFfa}function bv(i){return vi?k.Team(YR(w(i,hn))):w(w(i,Hn),k.Colors)}function Ev(i){const e=(w(i,hn)>0?w(i,hn)-1:w(w(i,Hn),new Int32Array([0,1,3,4])))|0,t=w(i,hn)|0;return ie(te('<i class="ship k%d t%d"></i>'))(e)(t)}function Fc(i){return w(i,hn)>0?w(w(i,hn),XR):w(w(i,Hn),KR)}function Po(i){return Gi(i)?k.Bot:w(i,_i)===""?k.Player(i):w(i,_i)}function r2(i){wr=i|0}function s2(){return uu?nn().tag===0?"lobby":"menu":"play"}function a2(i){const e=Bs(t=>ut.has(t)?w(t,Vi)===i:!1,Dt(kt(0,1,3)));if(e==null)return an();{const t=e|0;return{slot:t,name:Po(t),color:Fc(t),ship:Ev(t),pick:bv(t),ready:w(t,$n)}}}function Av(){if(Ts===""&&Os()!==""&&(Ts=Os()),Ts==="")return"";{const i=$f?" open":"",e=HR(Ts),t=Ts;return ie(te('<details class="legend qr"%s data-qr="0"><summary><div class="lt">%s</div><div class="big">%s<div class="url">%s</div></div></summary></details>'))(i)(k.ScanToJoin)(e)(t)}}function wv(){return Xd()===""?"":w(0,$c(window.location.href,["?"],void 0,0))+"?room="+Xd()}function o2(){return wv(),""}const l2='<svg viewBox="0 0 100 100" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linejoin="round"><path d="M50 8 L86 29 L86 71 L50 92 L14 71 L14 29 Z"/><path d="M50 34 L50 66 M34 50 L66 50" stroke-width="4"/></svg>';function Cv(i){switch(i){case"kb":return'<svg viewBox="0 0 24 16" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="1" y="1" width="22" height="14" rx="2"/><path d="M4 5h2M8 5h2M12 5h2M16 5h4M4 8h2M8 8h2M12 8h2M16 8h4M6 11h12" stroke-linecap="round"/></svg>';case"pad":return'<svg viewBox="0 0 24 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"><path d="M6 4h12a4 4 0 0 1 4 4.6l-.9 4.4a2 2 0 0 1-3.5.8L15 11H9l-2.6 2.8a2 2 0 0 1-3.5-.8L2 8.6A4 4 0 0 1 6 4Z"/><path d="M6.5 7v3M5 8.5h3" stroke-linecap="round"/><circle cx="18" cy="7" r=".9" fill="currentColor" stroke="none"/><circle cx="16" cy="9" r=".9" fill="currentColor" stroke="none"/></svg>';default:return'<svg viewBox="0 0 14 20" fill="none" stroke="currentColor" stroke-width="1.4"><rect x="1" y="1" width="12" height="18" rx="2"/><path d="M6 16h2" stroke-linecap="round"/></svg>'}}function Ld(i,e,t){const n=cn("",ln(s=>{const o=cn("",ln(a=>ie(te("<i>%s</i>"))(a),s[0]));return ie(te('<div class="key"><div class="caps">%s</div><span>%s</span></div>'))(o)(s[1])},t)),r=Cv(i);return ie(te('<div class="legend %s"><div class="lt">%s<b>%s</b></div><div class="keys">%s</div></div>'))(i)(r)(e)(n)}function Rv(i,e){let t,n;const r=cn("",(t=$c(i,[" / "],void 0,0),gt((n=ie(te("<i>%s</i>")),n),t)));return ie(te('<div class="key"><div class="caps">%s</div><span>%s</span></div>'))(r)(e)}function c2(){if(Qr().length!==3)return"";{const i=YS(Er())|0,e=Mu(i+1)-Mu(i)|0,t=Er()-Mu(i)|0,n=cn("",ls((a,l)=>{const u=$S(l)|0,c=ZS(l,w(a,es())),d=c?" done":"",p=k.DailyTask(jS(l),u);let f;if(c)f=k.DailyDone;else{const _=$e(w(a,es()),u)|0;f=ie(te("%d/%d"))(_)(u)}return ie(te('<div class="task%s"><span>%s</span><b>%s</b></div>'))(d)(p)(f)},Qr())),r=k.PilotLv(i),s=~~(100*t/fe(1,e))|0,o=k.PilotNext(JS(Er()));return ie(te('<div class="pilot"><div class="lv"><b>%s</b><i style="width:%d%%"></i><span>%s</span></div><div class="daily"><em>%s</em>%s</div></div>'))(r)(s)(o)(k.Daily)(n)}}function Jh(i){let e,t,n,r,s,o,a,l;const u=cn("",Dt(We(()=>xn(m=>{let g,h;const v=ut.has(m),M=Zc(x=>v?x.Key===w(m,Vi):!1,i),S=Gi(m)?k.Bot:xr((g=M,g!=null?(h=g,h.Key==="kb"?k.Keyboard:h.Name):void 0),k.PressToJoin),P=Fc(m);let E;if(!v)E="";else if(w(m,$n)){const x=Th(w(m,Sr),"★");E=ie(te('<div class="foot">%s %s</div>'))(k.Ready)(x)}else{const x=bv(m);E=ie(te('<div class="foot pick"><span data-dir="-1">&#9664;</span> %s <span data-dir="1">&#9654;</span></div>'))(x)}const A=(v?" in":"")+(v&&w(m,Oi)?" away":"");let L;if(m===wr){const x=Po(m);L=ie(te('<input class="rename" data-slot="%d" maxlength="16" placeholder="%s" value="%s">'))(m)(k.RenamePrompt)(x)}else{const x=v?Po(m):k.Player(m);L=ie(te("<b>%s</b>"))(x)}const y=v?Ev(m):l2;return ie(te('<div class="slot%s" data-slot="%d" style="color:%s">%s<div class="art">%s</div><div class="dev">%s</div>%s</div>'))(A)(m)(P)(L)(y)(S)(E)},kt(0,1,3))))),c=cn("",(e=i2(),ln((t=ie(te("<span>%s</span>")),t),e))),d=rc(),p=cn("",Rg((m,g)=>{const h=cn("",xn(P=>{const E=Fc(P),A=Po(P);return ie(te('<i style="color:%s">%s</i>'))(E)(A)},xh(Ig(P=>w(P,Oi)?w(P,qr)===m:!1,ut),{Compare:(P,E)=>fn(P,E)|0}))),v=h!=="",M=(v?" sel":"")+(g[2]?"":" dim")+(m===5&&d?" go":""),S=v?h:"";return ie(te('<div class="item%s" data-pick="%d"><em>%s</em><b>%s</b><div class="who">%s</div></div>'))(M)(m)(g[0])(g[1])(S)},Ke([[k.ModeLabel,n2(),!0],[k.Arena,uv(),!0],[k.Mutator,w(Na(),k.Mutators),!0],["",ut.size<4?k.AddBot:k.ClearBots,!0],["",k.Settings,!0],[WS(),d?k.Start:k.Ready,d]]))),f=cn("",ln(m=>Rv(m[0],m[1]),Ke([[Lg(),k.Join+" / "+k.Ready],["&#9664; / &#9654;",vi?k.TeamLabel:k.ColorLabel],["&#9650;",k.RenameLabel],["&#9660;",k.RowLabel],[Pg(),k.Leave]]))),_=HC()?k.SoundHint:d?"":ut.size<1?k.NeedOne:ut.size<2&&!Ar?k.NeedPlayers:vi&&!Tv()?k.NeedTwo:k.NeedReady;if($h((n=c2(),r=Ld("kb",k.Keyboard,KS()),s=Ld("pad",k.Gamepad,k.PadLegend),o=Ld("phone",k.Phone,k.PhoneLegend),a=Av(),l=o2(),ie(te('<div class="lobby"><div class="title"><h1>%s</h1><div class="sub">%s</div></div><div class="modebar">%s</div><div class="slots">%s</div><div class="hints">%s</div><div class="buttons">%s</div><div class="notebar"><span class="note">%s</span>%s</div><div class="legends">%s%s%s%s%s</div></div>'))(k.TitleMain)(k.TitleSub)(c)(u)(f)(p)(_)(n)(r)(s)(o)(a)(l)))&&wr>=0){const m=zi.querySelector("input.rename");if(!it(m,an())){const g=m;g.focus(),g.select()}}}function u2(i,e){let t=mt(ut);try{for(;t["System.Collections.IEnumerator.MoveNext"]();){const r=t["System.Collections.Generic.IEnumerator`1.get_Current"]()|0;(r===i||e>0&&w(r,hn)===e)&&ve(Sr,r,w(r,Sr)+1|0)}}finally{yt(t)}const n=w(i,Sr)>=nx;return n&&(Nn(Sr,0,4,0),Ya(Ya()+1),vv()),n}function d2(i,e,t,n){if(Qr().length===3){const r=new ix(i,e,t,n,ZR()),s=Si(es());es(Sn(3,o=>rx(w(o,Qr()),w(o,s),r)|0,Int32Array)),Er(Er()+sx(r)+ax(Qr(),s,es())),r.Clean&&e>qa()&&qa(e),vv()}}function f2(){return cn("",xn(i=>{const e=Fc(i),t=Po(i),n=Th(w(i,Sr),"★");return ie(te('<i style="color:%s">%s %s</i>'))(e)(t)(n)},xh(ut,{Compare:(i,e)=>fn(i,e)|0})))}function h2(i){let e,t,n;const r=cn("",Rg((o,a)=>{const l=o===ji?" sel":"";return ie(te('<div class="item%s" data-i="%d"><b>%s</b></div>'))(l)(o)(a[0])},Zf())),s=cn("",ln(o=>Rv(o[0],o[1]),nn().tag===2?pp():Ye(pp(),Ke([[Lg(),k.Join],[Pg(),k.Leave]]))));$h((e=f2(),t=Yh(),n=it(nn(),dn.Pause)?Av():"",ie(te('<div class="lobby"><div class="title"><h1>%s</h1></div><div class="tally">%s</div><div class="stats">%s</div><div class="buttons col">%s</div><div class="hints">%s</div>%s</div>'))(i)(e)(t)(r)(s)(n)))}function p2(){let i,e,t;const n=Go(Ri)|0;ri<ma?ma=ri|0:ri>=ma+Vl&&(ma=ri-Vl+1|0);const r=ma|0,s=cn("",ln(o=>{const a=o[0]|0,l=o[1],u=l.tag===0?"row hdr":l.tag===7?"row note":a===ri?"row sel":"row",c=fR(l),d=hR(l);return ie(te('<div class="%s" data-i="%d"><span>%s</span><b data-dir="1">%s</b></div>'))(u)(a)(c)(d)},Xs(o=>{const a=o[0]|0;return a>=r?a<r+Vl:!1},HS(Ri))));$h((i=r>0?k.MoreUp:"",e=r+Vl<n?k.More+`
`:"",t=VS(),ie(te('<h1>%s</h1><div class="cue">%s</div><div class="rows">%s</div><div class="hint">%s%s</div>'))(k.Settings)(i)(s)(e)(t)))}let Bc=!1;function m2(){return Bc}function Lv(i){Bc=i,qf=nn(),Ri=dR(i),ri=Cg(Xh,Ri)|0,ma=0,ol(dn.Options)}function Pv(){Lv(!1)}function g2(){Lv(!0)}function Iv(i){const e=ki(ut);for(let t=0;t<=e.length-1;t++){const n=w(t,e)|0;!Gi(n)&&!i.some(r=>r.Key===w(n,Vi)?r.Slot===n:!1)&&jh(n)}}function _2(){if(wr>=0)return!1;{const i=li();Iv(i);for(let n=0;n<=i.length-1;n++){const r=w(n,i);r.Slot>=0&&ut.has(r.Slot)&&w(r.Slot,Vi)===r.Key&&r.Name!==""&&!Gi(r.Slot)&&ve(_i,r.Slot,r.Name)}let e=!1,t=!1;for(let n=0;n<=i.length-1;n++){const r=w(n,i),s=r.Slot>=0&&ut.has(r.Slot)&&w(r.Slot,Vi)===r.Key,o=zt(r.Key,"fire",r.Input.Fire?!0:r.Input.Boost),a=zt(r.Key,"start",r.Input.Start),l=zt(r.Key,"back",r.Input.Back),u=zt(r.Key,"up",r.Input.Thrust),c=zt(r.Key,"down",r.Input.Reverse),d=r.Input.Turn+r.Input.Strafe,p=zt(r.Key,"right",d>.5),f=zt(r.Key,"left",d<-.5);if(s)if(w(r.Slot,Oi)){if(f&&ve(qr,r.Slot,(w(r.Slot,qr)+5)%6|0),p&&ve(qr,r.Slot,(w(r.Slot,qr)+1)%6|0),u||l)ve(Oi,r.Slot,!1);else if(a&&rc())e=!0;else if(o||a)switch(w(r.Slot,qr)|0){case 0:{Is?Is=!1:Ar?(Ar=!1,Is=!0):vi?(vi=!1,Ar=!0):vi=!0,jR();break}case 1:{Nc(Nt.Arena,1);break}case 2:{Na((Na()+1)%OS);break}case 3:{JR();break}case 4:{t=!0;break}default:rc()?e=!0:ve($n,r.Slot,!0)}}else(f||p)&&!w(r.Slot,$n)&&(vi?ve(hn,r.Slot,3-w(r.Slot,hn)|0):$R(r.Slot,p?1:-1)),c?ve(Oi,r.Slot,!0):u?r2(r.Slot):l?w(r.Slot,$n)?ve($n,r.Slot,!1):jh(r.Slot):a&&rc()?e=!0:(o||a)&&ve($n,r.Slot,!0);else if(o||a){const _=r.Slot>=0&&!ut.has(r.Slot)?r.Slot:Bs(m=>!ut.has(m),Dt(kt(0,1,3)));_!=null&&$s(r.Key,_)}}return t?(Pv(),!1):(Jh(li()),e&&(kS(),Zh()),e)}}function v2(){const i=Go(Ri)|0,e=n=>{let r=ri,s=0,o=!0;for(;o&&s<i;)r=(r+n+i)%i|0,s=s+1|0,Xh(Wr(r,Ri))&&(o=!1);ri=r|0};let t=!1;if(hv()){const n=li();for(let r=0;r<=n.length-1;r++){const s=w(r,n);s.Key!=="kb"&&(zt(s.Key,"back",s.Input.Back)||zt(s.Key,"start",s.Input.Start))&&aR()}}else{const n=Wr(ri,Ri).tag===8,r=(o,a,l)=>n?zt(o,a,l):Rd(o,a,l),s=li();for(let o=0;o<=s.length-1;o++){const a=w(o,s),l=a.Input,u=a.Key;Rd(u,"up",l.Thrust)&&e(-1),Rd(u,"down",l.Reverse)&&e(1);const c=l.Turn+l.Strafe;r(u,"left",c<-.5)&&Nc(Wr(ri,Ri),-1),r(u,"right",c>.5)&&Nc(Wr(ri,Ri),1),zt(u,"fire",l.Fire?!0:l.Boost)&&pR(Wr(ri,Ri));const d=zt(u,"back",l.Back),p=zt(u,"start",l.Start);(d||p)&&(t=!0)}}p2(),t&&(Bc?(Bc=!1,Zh()):(it(qf,dn.Lobby)&&Iv(li()),ol(qf)))}function F0(i,e){const t=Go(Zf())|0,n=er()|0,r=it(nn(),dn.Pause)&&n>=0&&ut.has(n)&&w(n,Vi)==="kb";let s;if(Ja((l,u)=>{const c=ie(te("s%d"))(l);zt(c,"up",u.Thrust)&&(ji=(ji+t-1)%t|0),zt(c,"down",u.Reverse)&&(ji=(ji+1)%t|0);const d=zt(c,"fire",u.Fire?!0:u.Boost),p=zt(c,"start",u.Start);if(d||p){const f=Wr(ji,Zf())[1];r&&l!==n&&(f.tag===2||f.tag===3)||(s=f)}zt(c,"back",u.Back)&&(pr!=null?s=ii.Cancel:it(nn(),dn.Pause)?s=ii.Resume:(jh(l),ut.size<2&&(s=ii.Quit)))},e),!it(nn(),dn.Pause)){const l=li();for(let u=0;u<=l.length-1;u++){const c=w(u,l);if(!(c.Slot>=0&&ut.has(c.Slot)&&w(c.Slot,Vi)===c.Key)&&zt(c.Key,"fire",c.Input.Fire?!0:c.Input.Boost)){const d=Bs(p=>!ut.has(p),Dt(kt(0,1,3)));d!=null&&$s(c.Key,d)}}}h2(i);let o,a;if(s!=null)switch(s.tag){case 4:{o=0;break}case 5:{o=1;break}case 2:{pr==null&&it(nn(),dn.Pause)?(o=2,a=s):o=3;break}case 3:{pr==null&&it(nn(),dn.Pause)?(o=2,a=s):o=3;break}default:o=3}else o=3;switch(o){case 0:{Pv();return}case 1:{pr=void 0,ji=0;return}case 2:{pr=a,ji=0;return}default:return s==null?void 0:(pr=void 0,Zh(),s)}}function Dv(i){if(nn().tag===1){v2();return}else return nn().tag===2?F0(pr!=null?k.Sure:k.Paused,i):nn().tag===3?F0(nn().fields[0],i):_2()?ii.Rematch:void 0}function Li(i,e){let t;const n=i.target.closest(ie(te("[data-%s]"))(e));if(n!=null)return t=n,yh(t.getAttribute("data-"+e),511,!1,32)}function nr(){return er()|0}function bs(){return nr()>=0&&ut.has(nr())?w(nr(),Vi)==="kb":!1}function Oc(i){Ss(i<0?"ArrowLeft":"ArrowRight")}function kc(i){nn().tag===1?Xh(Wr(i,Ri))&&(ri=i|0):ji=i|0}zi.addEventListener("contextmenu",i=>{i.preventDefault()});zi.addEventListener("pointerup",i=>{Dg()});function Nv(i){if(wr>=0){const e=i.target.value;ve(_i,wr,e.trim()),wr=-1,Jh(li())}}zi.addEventListener("keydown",i=>{if(wr>=0)switch(i.stopPropagation(),i.key){case"Enter":{i.preventDefault(),Nv(i);break}case"Escape":{i.preventDefault(),wr=-1,Jh(li());break}}});zi.addEventListener("focusout",i=>{Nv(i)});zi.addEventListener("wheel",i=>{let e;const t=i.deltaY>0,n=Li(i,"dir"),r=Li(i,"slot"),s=Li(i,"i");let o,a;switch(n!=null?r==null?s!=null?(o=1,a=s):it(nn(),dn.Lobby)?o=3:o=2:(e=r|0,bs()&&e===nr()?o=0:it(nn(),dn.Lobby)?o=3:o=2):it(nn(),dn.Lobby)?o=3:o=2,o){case 0:{Oc(t?-1:1);break}case 1:{kc(a),Oc(t?-1:1);break}case 2:{Ss(t?"ArrowDown":"ArrowUp");break}}Dg()});zi.addEventListener("pointermove",i=>{const e=Li(i,"i"),t=Li(i,"pick");let n,r,s;switch(e!=null?(n=0,r=e):t!=null&&bs()&&w(nr(),Oi)?(n=1,s=t):n=2,n){case 0:{kc(r);break}case 1:{ve(qr,nr(),s|0);break}}});zi.addEventListener("pointerdown",i=>{if(i.button===2)Ss("Escape");else if(Li(i,"qr")!=null)$f=!$f;else if(Li(i,"copy")!=null)window.navigator.clipboard.writeText(wv());else{const e=Li(i,"dir"),t=Li(i,"slot"),n=Li(i,"pick"),r=Li(i,"i");let s,o,a,l,u,c,d,p,f;switch(e!=null?t==null?r!=null?(s=1,l=e,u=r):n!=null&&bs()?(s=4,p=n):s=6:(s=0,o=e,a=t):t!=null?bs()?t===nr()?(s=3,d=t):n!=null&&bs()?(s=4,p=n):r!=null?(s=5,f=r):s=6:(s=2,c=t):n!=null&&bs()?(s=4,p=n):r!=null?(s=5,f=r):s=6,s){case 0:{bs()&&a===nr()&&Oc(o);break}case 1:{kc(u),Oc(l);break}case 2:{ut.has(c)||er(c),Ss("Space");break}case 3:{w(d,Oi)?ve(Oi,d,!1):Ss("Space");break}case 4:{ve(Oi,nr(),!0),ve(qr,nr(),p|0),Ss("Space");break}case 5:{kc(f),Ss("Space");break}}}});function M2(i){return i*i*(3-2*i)}function S2(i,e,t){i.Intro=i.Intro-t;let n;if(ot()&&yn().length>0){const r=$e(8,yn().length)|0;n=Sn(r+1,s=>w(~~(s*yn().length/r)%yn().length,yn()))}else n=gt(r=>n_(r.Id),e.Ships.filter(r=>r.Active));if(n.length>0){const r=fe(1,n.length-1)|0,s=fe(0,$e(r-.001,(1-i.Intro/yc)/.8*r)),o=~~s|0,a=w(o,n),l=w($e(o+1,n.length-1),n),u=a;i.Cam=Ae(u,re(ae(l,u),M2(s-o)))}i.CamH=yo()*.5}function x2(i,e,t){const n=e.Ships.filter(y=>y.Alive);let r;if(n.length===0)r=[V(-Ge(),-Ge()),V(Ge(),Ge())];else{const y=gt(C=>C.Pos.X,n,Float64Array),x=gt(C=>C.Pos.Y,n,Float64Array);r=[V(Fo(y,{Compare:(C,N)=>fn(C,N)|0}),Fo(x,{Compare:(C,N)=>fn(C,N)|0})),V(_p(y,{Compare:(C,N)=>fn(C,N)|0}),_p(x,{Compare:(C,N)=>fn(C,N)|0}))]}const s=r[0],o=r[1],a=re(Ae(s,o),.5),l=Math.tan(20*3.141592653589793/180),u=((o.Y-s.Y)/2+220)/l,c=((o.X-s.X)/2+220)/(l*i.Camera.aspect);let d;d=e.Ships.filter(y=>y.Active&&y.Stocks>0?y.Finish===0:!1).length;let f;const _=fe(ot()?yo()*ux:d<=dx?yo()*fx:yo(),fe(c,u));f=$e(Ra(),_);const m=$e(1,(Ra()-f)/(Ra()-yo())),g=y=>1-Math.exp(-y*t);let h;const v=e.Phase;let M,S;switch(v.tag===1&&v.fields[0]!=null?(M=0,S=v.fields[0]):M=1,M){case 0:{h=[w(S,e.Ships).Pos,hx,g(7),g(1.6)];break}default:h=[re(a,m),f,g(4),g(4)]}i.Intro>yc*.2?S2(i,e,t):(i.Intro=fe(0,i.Intro-t),i.Cam=Ae(i.Cam,re(ae(h[0],i.Cam),h[2])),i.CamH=i.CamH+(h[1]-i.CamH)*h[3]),i.Jolt=$o()?fe(0,i.Jolt-t*3):0;const P=i.Jolt*i.Jolt*i.CamH*.02,E=(Kt.NextDouble()-.5)*P,A=(Kt.NextDouble()-.5)*P,L=E;i.Camera.position.set(i.Cam.X+L,i.CamH,i.Cam.Y+i.CamH*.3+A),i.Camera.lookAt(i.Cam.X+L,0,i.Cam.Y+A)}function Uv(){const i=window.innerWidth,e=window.innerHeight;return e>0?i/e:16/9}function y2(i){const e=window.innerWidth,t=window.innerHeight;i.Camera.aspect=Uv(),i.Camera.updateProjectionMatrix(),i.Renderer.setSize(e,t),i.Composer.setSize(e,t)}const Fv={name:"CopyShader",uniforms:{tDiffuse:{value:null},opacity:{value:1}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;
			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform float opacity;

		uniform sampler2D tDiffuse;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );
			gl_FragColor = opacity * texel;


		}`};class ll{constructor(){this.isPass=!0,this.enabled=!0,this.needsSwap=!0,this.clear=!1,this.renderToScreen=!1}setSize(){}render(){console.error("THREE.Pass: .render() must be implemented in derived pass.")}dispose(){}}const T2=new N_(-1,1,1,-1,0,1);class b2 extends sn{constructor(){super(),this.setAttribute("position",new At([-1,3,0,-1,-1,0,3,-1,0],3)),this.setAttribute("uv",new At([0,2,0,0,2,0],2))}}const E2=new b2;class Bv{constructor(e){this._mesh=new je(E2,e)}dispose(){this._mesh.geometry.dispose()}render(e){e.render(this._mesh,T2)}get material(){return this._mesh.material}set material(e){this._mesh.material=e}}class A2 extends ll{constructor(e,t){super(),this.textureID=t!==void 0?t:"tDiffuse",e instanceof Zn?(this.uniforms=e.uniforms,this.material=e):e&&(this.uniforms=Ec.clone(e.uniforms),this.material=new Zn({name:e.name!==void 0?e.name:"unspecified",defines:Object.assign({},e.defines),uniforms:this.uniforms,vertexShader:e.vertexShader,fragmentShader:e.fragmentShader})),this.fsQuad=new Bv(this.material)}render(e,t,n){this.uniforms[this.textureID]&&(this.uniforms[this.textureID].value=n.texture),this.fsQuad.material=this.material,this.renderToScreen?(e.setRenderTarget(null),this.fsQuad.render(e)):(e.setRenderTarget(t),this.clear&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),this.fsQuad.render(e))}dispose(){this.material.dispose(),this.fsQuad.dispose()}}class B0 extends ll{constructor(e,t){super(),this.scene=e,this.camera=t,this.clear=!0,this.needsSwap=!1,this.inverse=!1}render(e,t,n){const r=e.getContext(),s=e.state;s.buffers.color.setMask(!1),s.buffers.depth.setMask(!1),s.buffers.color.setLocked(!0),s.buffers.depth.setLocked(!0);let o,a;this.inverse?(o=0,a=1):(o=1,a=0),s.buffers.stencil.setTest(!0),s.buffers.stencil.setOp(r.REPLACE,r.REPLACE,r.REPLACE),s.buffers.stencil.setFunc(r.ALWAYS,o,4294967295),s.buffers.stencil.setClear(a),s.buffers.stencil.setLocked(!0),e.setRenderTarget(n),this.clear&&e.clear(),e.render(this.scene,this.camera),e.setRenderTarget(t),this.clear&&e.clear(),e.render(this.scene,this.camera),s.buffers.color.setLocked(!1),s.buffers.depth.setLocked(!1),s.buffers.color.setMask(!0),s.buffers.depth.setMask(!0),s.buffers.stencil.setLocked(!1),s.buffers.stencil.setFunc(r.EQUAL,1,4294967295),s.buffers.stencil.setOp(r.KEEP,r.KEEP,r.KEEP),s.buffers.stencil.setLocked(!0)}}class w2 extends ll{constructor(){super(),this.needsSwap=!1}render(e){e.state.buffers.stencil.setLocked(!1),e.state.buffers.stencil.setTest(!1)}}class C2{constructor(e,t){if(this.renderer=e,this._pixelRatio=e.getPixelRatio(),t===void 0){const n=e.getSize(new tt);this._width=n.width,this._height=n.height,t=new Bi(this._width*this._pixelRatio,this._height*this._pixelRatio,{type:Tr}),t.texture.name="EffectComposer.rt1"}else this._width=t.width,this._height=t.height;this.renderTarget1=t,this.renderTarget2=t.clone(),this.renderTarget2.texture.name="EffectComposer.rt2",this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2,this.renderToScreen=!0,this.passes=[],this.copyPass=new A2(Fv),this.copyPass.material.blending=yr,this.clock=new cC}swapBuffers(){const e=this.readBuffer;this.readBuffer=this.writeBuffer,this.writeBuffer=e}addPass(e){this.passes.push(e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}insertPass(e,t){this.passes.splice(t,0,e),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}removePass(e){const t=this.passes.indexOf(e);t!==-1&&this.passes.splice(t,1)}isLastEnabledPass(e){for(let t=e+1;t<this.passes.length;t++)if(this.passes[t].enabled)return!1;return!0}render(e){e===void 0&&(e=this.clock.getDelta());const t=this.renderer.getRenderTarget();let n=!1;for(let r=0,s=this.passes.length;r<s;r++){const o=this.passes[r];if(o.enabled!==!1){if(o.renderToScreen=this.renderToScreen&&this.isLastEnabledPass(r),o.render(this.renderer,this.writeBuffer,this.readBuffer,e,n),o.needsSwap){if(n){const a=this.renderer.getContext(),l=this.renderer.state.buffers.stencil;l.setFunc(a.NOTEQUAL,1,4294967295),this.copyPass.render(this.renderer,this.writeBuffer,this.readBuffer,e),l.setFunc(a.EQUAL,1,4294967295)}this.swapBuffers()}B0!==void 0&&(o instanceof B0?n=!0:o instanceof w2&&(n=!1))}}this.renderer.setRenderTarget(t)}reset(e){if(e===void 0){const t=this.renderer.getSize(new tt);this._pixelRatio=this.renderer.getPixelRatio(),this._width=t.width,this._height=t.height,e=this.renderTarget1.clone(),e.setSize(this._width*this._pixelRatio,this._height*this._pixelRatio)}this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.renderTarget1=e,this.renderTarget2=e.clone(),this.writeBuffer=this.renderTarget1,this.readBuffer=this.renderTarget2}setSize(e,t){this._width=e,this._height=t;const n=this._width*this._pixelRatio,r=this._height*this._pixelRatio;this.renderTarget1.setSize(n,r),this.renderTarget2.setSize(n,r);for(let s=0;s<this.passes.length;s++)this.passes[s].setSize(n,r)}setPixelRatio(e){this._pixelRatio=e,this.setSize(this._width,this._height)}dispose(){this.renderTarget1.dispose(),this.renderTarget2.dispose(),this.copyPass.dispose()}}class R2 extends ll{constructor(e,t,n=null,r=null,s=null){super(),this.scene=e,this.camera=t,this.overrideMaterial=n,this.clearColor=r,this.clearAlpha=s,this.clear=!0,this.clearDepth=!1,this.needsSwap=!1,this._oldClearColor=new pt}render(e,t,n){const r=e.autoClear;e.autoClear=!1;let s,o;this.overrideMaterial!==null&&(o=this.scene.overrideMaterial,this.scene.overrideMaterial=this.overrideMaterial),this.clearColor!==null&&(e.getClearColor(this._oldClearColor),e.setClearColor(this.clearColor,e.getClearAlpha())),this.clearAlpha!==null&&(s=e.getClearAlpha(),e.setClearAlpha(this.clearAlpha)),this.clearDepth==!0&&e.clearDepth(),e.setRenderTarget(this.renderToScreen?null:n),this.clear===!0&&e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil),e.render(this.scene,this.camera),this.clearColor!==null&&e.setClearColor(this._oldClearColor),this.clearAlpha!==null&&e.setClearAlpha(s),this.overrideMaterial!==null&&(this.scene.overrideMaterial=o),e.autoClear=r}}const L2={uniforms:{tDiffuse:{value:null},luminosityThreshold:{value:1},smoothWidth:{value:1},defaultColor:{value:new pt(0)},defaultOpacity:{value:0}},vertexShader:`

		varying vec2 vUv;

		void main() {

			vUv = uv;

			gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );

		}`,fragmentShader:`

		uniform sampler2D tDiffuse;
		uniform vec3 defaultColor;
		uniform float defaultOpacity;
		uniform float luminosityThreshold;
		uniform float smoothWidth;

		varying vec2 vUv;

		void main() {

			vec4 texel = texture2D( tDiffuse, vUv );

			float v = luminance( texel.xyz );

			vec4 outputColor = vec4( defaultColor.rgb, defaultOpacity );

			float alpha = smoothstep( luminosityThreshold, luminosityThreshold + smoothWidth, v );

			gl_FragColor = mix( outputColor, texel, alpha );

		}`};class Za extends ll{constructor(e,t,n,r){super(),this.strength=t!==void 0?t:1,this.radius=n,this.threshold=r,this.resolution=e!==void 0?new tt(e.x,e.y):new tt(256,256),this.clearColor=new pt(0,0,0),this.renderTargetsHorizontal=[],this.renderTargetsVertical=[],this.nMips=5;let s=Math.round(this.resolution.x/2),o=Math.round(this.resolution.y/2);this.renderTargetBright=new Bi(s,o,{type:Tr}),this.renderTargetBright.texture.name="UnrealBloomPass.bright",this.renderTargetBright.texture.generateMipmaps=!1;for(let d=0;d<this.nMips;d++){const p=new Bi(s,o,{type:Tr});p.texture.name="UnrealBloomPass.h"+d,p.texture.generateMipmaps=!1,this.renderTargetsHorizontal.push(p);const f=new Bi(s,o,{type:Tr});f.texture.name="UnrealBloomPass.v"+d,f.texture.generateMipmaps=!1,this.renderTargetsVertical.push(f),s=Math.round(s/2),o=Math.round(o/2)}const a=L2;this.highPassUniforms=Ec.clone(a.uniforms),this.highPassUniforms.luminosityThreshold.value=r,this.highPassUniforms.smoothWidth.value=.01,this.materialHighPassFilter=new Zn({uniforms:this.highPassUniforms,vertexShader:a.vertexShader,fragmentShader:a.fragmentShader}),this.separableBlurMaterials=[];const l=[3,5,7,9,11];s=Math.round(this.resolution.x/2),o=Math.round(this.resolution.y/2);for(let d=0;d<this.nMips;d++)this.separableBlurMaterials.push(this.getSeperableBlurMaterial(l[d])),this.separableBlurMaterials[d].uniforms.invSize.value=new tt(1/s,1/o),s=Math.round(s/2),o=Math.round(o/2);this.compositeMaterial=this.getCompositeMaterial(this.nMips),this.compositeMaterial.uniforms.blurTexture1.value=this.renderTargetsVertical[0].texture,this.compositeMaterial.uniforms.blurTexture2.value=this.renderTargetsVertical[1].texture,this.compositeMaterial.uniforms.blurTexture3.value=this.renderTargetsVertical[2].texture,this.compositeMaterial.uniforms.blurTexture4.value=this.renderTargetsVertical[3].texture,this.compositeMaterial.uniforms.blurTexture5.value=this.renderTargetsVertical[4].texture,this.compositeMaterial.uniforms.bloomStrength.value=t,this.compositeMaterial.uniforms.bloomRadius.value=.1;const u=[1,.8,.6,.4,.2];this.compositeMaterial.uniforms.bloomFactors.value=u,this.bloomTintColors=[new H(1,1,1),new H(1,1,1),new H(1,1,1),new H(1,1,1),new H(1,1,1)],this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors;const c=Fv;this.copyUniforms=Ec.clone(c.uniforms),this.blendMaterial=new Zn({uniforms:this.copyUniforms,vertexShader:c.vertexShader,fragmentShader:c.fragmentShader,blending:Hs,depthTest:!1,depthWrite:!1,transparent:!0}),this.enabled=!0,this.needsSwap=!1,this._oldClearColor=new pt,this.oldClearAlpha=1,this.basic=new xi,this.fsQuad=new Bv(null)}dispose(){for(let e=0;e<this.renderTargetsHorizontal.length;e++)this.renderTargetsHorizontal[e].dispose();for(let e=0;e<this.renderTargetsVertical.length;e++)this.renderTargetsVertical[e].dispose();this.renderTargetBright.dispose();for(let e=0;e<this.separableBlurMaterials.length;e++)this.separableBlurMaterials[e].dispose();this.compositeMaterial.dispose(),this.blendMaterial.dispose(),this.basic.dispose(),this.fsQuad.dispose()}setSize(e,t){let n=Math.round(e/2),r=Math.round(t/2);this.renderTargetBright.setSize(n,r);for(let s=0;s<this.nMips;s++)this.renderTargetsHorizontal[s].setSize(n,r),this.renderTargetsVertical[s].setSize(n,r),this.separableBlurMaterials[s].uniforms.invSize.value=new tt(1/n,1/r),n=Math.round(n/2),r=Math.round(r/2)}render(e,t,n,r,s){e.getClearColor(this._oldClearColor),this.oldClearAlpha=e.getClearAlpha();const o=e.autoClear;e.autoClear=!1,e.setClearColor(this.clearColor,0),s&&e.state.buffers.stencil.setTest(!1),this.renderToScreen&&(this.fsQuad.material=this.basic,this.basic.map=n.texture,e.setRenderTarget(null),e.clear(),this.fsQuad.render(e)),this.highPassUniforms.tDiffuse.value=n.texture,this.highPassUniforms.luminosityThreshold.value=this.threshold,this.fsQuad.material=this.materialHighPassFilter,e.setRenderTarget(this.renderTargetBright),e.clear(),this.fsQuad.render(e);let a=this.renderTargetBright;for(let l=0;l<this.nMips;l++)this.fsQuad.material=this.separableBlurMaterials[l],this.separableBlurMaterials[l].uniforms.colorTexture.value=a.texture,this.separableBlurMaterials[l].uniforms.direction.value=Za.BlurDirectionX,e.setRenderTarget(this.renderTargetsHorizontal[l]),e.clear(),this.fsQuad.render(e),this.separableBlurMaterials[l].uniforms.colorTexture.value=this.renderTargetsHorizontal[l].texture,this.separableBlurMaterials[l].uniforms.direction.value=Za.BlurDirectionY,e.setRenderTarget(this.renderTargetsVertical[l]),e.clear(),this.fsQuad.render(e),a=this.renderTargetsVertical[l];this.fsQuad.material=this.compositeMaterial,this.compositeMaterial.uniforms.bloomStrength.value=this.strength,this.compositeMaterial.uniforms.bloomRadius.value=this.radius,this.compositeMaterial.uniforms.bloomTintColors.value=this.bloomTintColors,e.setRenderTarget(this.renderTargetsHorizontal[0]),e.clear(),this.fsQuad.render(e),this.fsQuad.material=this.blendMaterial,this.copyUniforms.tDiffuse.value=this.renderTargetsHorizontal[0].texture,s&&e.state.buffers.stencil.setTest(!0),this.renderToScreen?(e.setRenderTarget(null),this.fsQuad.render(e)):(e.setRenderTarget(n),this.fsQuad.render(e)),e.setClearColor(this._oldClearColor,this.oldClearAlpha),e.autoClear=o}getSeperableBlurMaterial(e){const t=[];for(let n=0;n<e;n++)t.push(.39894*Math.exp(-.5*n*n/(e*e))/e);return new Zn({defines:{KERNEL_RADIUS:e},uniforms:{colorTexture:{value:null},invSize:{value:new tt(.5,.5)},direction:{value:new tt(.5,.5)},gaussianCoefficients:{value:t}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`#include <common>
				varying vec2 vUv;
				uniform sampler2D colorTexture;
				uniform vec2 invSize;
				uniform vec2 direction;
				uniform float gaussianCoefficients[KERNEL_RADIUS];

				void main() {
					float weightSum = gaussianCoefficients[0];
					vec3 diffuseSum = texture2D( colorTexture, vUv ).rgb * weightSum;
					for( int i = 1; i < KERNEL_RADIUS; i ++ ) {
						float x = float(i);
						float w = gaussianCoefficients[i];
						vec2 uvOffset = direction * invSize * x;
						vec3 sample1 = texture2D( colorTexture, vUv + uvOffset ).rgb;
						vec3 sample2 = texture2D( colorTexture, vUv - uvOffset ).rgb;
						diffuseSum += (sample1 + sample2) * w;
						weightSum += 2.0 * w;
					}
					gl_FragColor = vec4(diffuseSum/weightSum, 1.0);
				}`})}getCompositeMaterial(e){return new Zn({defines:{NUM_MIPS:e},uniforms:{blurTexture1:{value:null},blurTexture2:{value:null},blurTexture3:{value:null},blurTexture4:{value:null},blurTexture5:{value:null},bloomStrength:{value:1},bloomFactors:{value:null},bloomTintColors:{value:null},bloomRadius:{value:0}},vertexShader:`varying vec2 vUv;
				void main() {
					vUv = uv;
					gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
				}`,fragmentShader:`varying vec2 vUv;
				uniform sampler2D blurTexture1;
				uniform sampler2D blurTexture2;
				uniform sampler2D blurTexture3;
				uniform sampler2D blurTexture4;
				uniform sampler2D blurTexture5;
				uniform float bloomStrength;
				uniform float bloomRadius;
				uniform float bloomFactors[NUM_MIPS];
				uniform vec3 bloomTintColors[NUM_MIPS];

				float lerpBloomFactor(const in float factor) {
					float mirrorFactor = 1.2 - factor;
					return mix(factor, mirrorFactor, bloomRadius);
				}

				void main() {
					gl_FragColor = bloomStrength * ( lerpBloomFactor(bloomFactors[0]) * vec4(bloomTintColors[0], 1.0) * texture2D(blurTexture1, vUv) +
						lerpBloomFactor(bloomFactors[1]) * vec4(bloomTintColors[1], 1.0) * texture2D(blurTexture2, vUv) +
						lerpBloomFactor(bloomFactors[2]) * vec4(bloomTintColors[2], 1.0) * texture2D(blurTexture3, vUv) +
						lerpBloomFactor(bloomFactors[3]) * vec4(bloomTintColors[3], 1.0) * texture2D(blurTexture4, vUv) +
						lerpBloomFactor(bloomFactors[4]) * vec4(bloomTintColors[4], 1.0) * texture2D(blurTexture5, vUv) );
				}`})}}Za.BlurDirectionX=new tt(1,0);Za.BlurDirectionY=new tt(0,1);function P2(i){return new C2(i)}function I2(i,e){return new R2(i,e)}function D2(i,e,t,n){return new Za(i,e,t,n)}const N2=window.location.pathname.indexOf("/play/")>=0?"../":"./",U2=new bh(()=>{const i=new z_().load(N2+"ships.png");return i.colorSpace=ni,i.repeat.set(Hf[0]/Pc[0],Hf[1]/Pc[1]),i}),F2=new bh(()=>Mt(new Hi(64,54).rotateZ(-3.141592653589793/2))),O0=K_*6;function B2(){let i;const e=new sn;e.setAttribute("position",new At(new Float64Array(O0*3),3)),e.setAttribute("color",new At(new Float64Array(O0*3),3)),e.setDrawRange(0,0);const t=new je(e,new xi((i=Qi|0,{blending:Hs,depthWrite:!1,opacity:.9,side:i,transparent:!0,vertexColors:!0})));return t.frustumCulled=!1,t}function O2(i,e){const t=w(e,cu)|0,n=new Dn,r=new je(F2.Value,new xi({depthWrite:!1,map:U2.Value.clone(),transparent:!0}));r.position.y=1;const s=new je(Mt(new Gs(7,12)).translate(-16,3,0),xt(t,.9));n.add(r),n.add(s);const o=new Dn,a=mt([-7,7]);try{for(;a["System.Collections.IEnumerator.MoveNext"]();){const h=a["System.Collections.Generic.IEnumerator`1.get_Current"]();o.add(new je(Mt(new Gs(2.5,8)).translate(15,3,h),xt(t,.9)))}}finally{yt(a)}n.add(o);const l=new je(Mt(new Zt(9,13,24)).translate(30,3,0),xt(16777215,1));l.visible=!1,n.add(l);const u=new je(Mt(new Hi(400,1.2)).translate(218,2,0),xt(t,.3));u.visible=!1,n.add(u);const c=new je(Mt(new Zt(.985,1,64)),xt(t,.2));c.position.y=2,c.visible=!1,n.add(c);const d=new je(Mt(new Zt(It+5,It+9,6)),xt(3902719,.9));d.visible=!1,n.add(d);const p=new je(Mt(new Zt(It+3,It+6,X_)),xt(16777215,.9));p.position.y=3,p.visible=!1,i.add(p);const f=new je(Mt(new Zt(It+15,It+19,20,1,-.65,1.3)),xt(16726876,.8));f.position.y=3,f.visible=!1,i.add(f);const _=new je(Mt(new Zt(30,38,20,1,-.9,1.8)),xt(t,.9));_.position.y=3,_.visible=!1,i.add(_);const m=B2(),g=new je(Mt(new Hi(1,4)),xt(t,.7));return g.visible=!1,i.add(g),i.add(n),i.add(m),new TC(d,p,n,r,s,o,l,u,g,c,f,_,m,[],[])}function k2(i){switch(i.Kind|0){case 1:return 3932062;case 2:return 3902719;default:return 16774236}}function H2(i,e){let t;const n=e.Kind|0;t=n===1?[go-12,40]:n===2?[go*.42,6]:[go-5,40];const r=new je(Mt(new Zt(t[0],go,t[1])),xt(k2(e),1));return r.position.set(e.Pos.X,.5,e.Pos.Y),i.add(r),r}function V2(i){const e=new lu(ug,0),t=new Dn;return t.add(new je(e,new xi({color:1180424}))),t.add(new Rc(new Lc(e),Jr(16722765,1))),t.visible=!1,i.add(t),t}function G2(i){const e=Kl*1.35,t=new ss(e,e,e),n=new Dn;n.add(new je(t,new xi({color:657950}))),n.add(new Rc(new Lc(t),Jr(16774236,1)));for(let r=0;r<=2;r++){const s=new Rc(new Lc(new ss(e*1.02,e*.26,e*1.02)),Jr(16774236,.6));s.rotation.set(r===1?3.141592653589793/2:0,0,r===2?3.141592653589793/2:0),n.add(s)}return n.add(new je(Mt(new Zt(Kl+8,Kl+11,32)),xt(16774236,.7))),i.add(n),n}function Ov(i,e,t,n){const r=new lu(n.Radius,1),s=new Dn;return s.add(new je(r,new xi({color:e}))),s.add(new Rc(new Lc(r),Jr(t,.8))),s.position.set(n.Pos.X,0,n.Pos.Y),s.rotation.set(n.Pos.X*.01,n.Pos.Y*.01,0),i.add(s),s}function z2(i,e){const t=e%2===1,n=t?Ta()*.55:Ta(),r=new je(Mt(new Zt(n-4,n,t?6:40)),xt(Ca,.9));return r.position.y=2,r.visible=!1,i.add(r),r}function W2(i){const e=new je(Mt(new Hi(_h(),Wl()*2)),xt(3898367,.75));return e.position.y=3,e.visible=!1,i.add(e),e}function K2(i){const e=new Dn,t=new je(Mt(new Zt(0,Zi,6)),new xi({color:657950}));t.position.y=1,e.add(t);const n=new je(Mt(new Zt(Zi-3,Zi,6)),xt(16777215,1));n.position.y=2,e.add(n);const r=new je(new ss(Zi*1.7,4,5),xt(16777215,1));r.position.set(Zi*.85,4,0),e.add(r);const s=new je(Mt(new Zt(Zi+5,Zi+8,24)),xt(16777215,.8));return s.position.y=1,e.add(s),e.visible=!1,i.add(e),[e,n,s]}function X2(i){const e=new Dn,t=new je(Mt(new Gs(Co(),48)),xt(9099519,.12));t.position.y=1,e.add(t);const n=new je(Mt(new Zt(Co()-5,Co(),48)),xt(9099519,.7));return n.position.y=2,e.add(n),e.visible=!1,i.add(e),[e,t,n]}function q2(i){const e=new Dn,t=new je(Mt(new Gs(Kr()*3,48)),new xi({color:0}));t.position.y=1,e.add(t);const n=new je(Mt(new Zt(Kr()*3,Kr()*3+6,48)),xt(Yo,1));n.position.y=2,e.add(n);const r=new je(Mt(new Zt(Kr()*9,Kr()*9+3,6)),xt(Yo,.2));return r.position.y=2,e.add(r),e.visible=!1,i.add(e),[e,n,r]}function Y2(i){const e=new je(Mt(new Hi(16,3)),xt(16777215,1));return e.visible=!1,i.add(e),e}function $2(i){const e=Ge()*i,t=(Ws()-Ge())*i;return ki(We(()=>gn(n=>[n[0],0,n[1]],[[e,t],[t,e],[-t,e],[-e,t],[-e,-t],[-t,-e],[t,-e],[e,-t]])))}function Pd(i,e,t,n,r){const s=new sn;s.setAttribute("position",new At($2(e),3));const o=new V_(s,Jr(t,n));return o.position.y=r,i.add(o),o}function kv(i){const e=new Dn,t=new Dn;Pd(t,1,63231,1,0),Pd(t,.985,16722902,.35,0),e.add(t),Pd(e,.62,1386829,.7,-.5);const n=Ws()-Ge(),r=mt([1,-1]);try{for(;r["System.Collections.IEnumerator.MoveNext"]();){const a=r["System.Collections.Generic.IEnumerator`1.get_Current"](),l=mt([1,-1]);try{for(;l["System.Collections.IEnumerator.MoveNext"]();){const u=l["System.Collections.Generic.IEnumerator`1.get_Current"](),c=new sn;c.setAttribute("position",new At(new Float64Array([a*Ge(),0,u*n,a*Ge(),0,u*Ge(),a*n,0,u*Ge()]),3));const d=new je(c,new xi({color:0}));d.position.y=-.9,e.add(d)}}finally{yt(l)}}}finally{yt(r)}const s=new Dn;s.add(new je(Mt(new Zt(96,100,6)),xt(16774236,.8))),s.add(new je(Mt(new Zt(150,152,48)),xt(63231,.35))),s.position.y=-.5,e.add(s);const o=Sn(4,a=>{const l=n_(a),u=new je(Mt(new Zt(120,124,8)),xt(w(w(a,Hn),cu),.5));return u.position.set(l.X,-.5,l.Y),u.rotation.z=3.141592653589793/8,e.add(u),u});return i.add(e),[t,o,e]}function Z2(i){const e=kv(i),t=new sn;return t.setAttribute("position",new At(Sn(1500*3,n=>n%3===1?-80-Kt.NextDouble()*400:(Kt.NextDouble()-.5)*7e3,Float64Array),3)),i.add(new G_(t,new ou({color:10466303,opacity:.7,size:3,transparent:!0}))),[e[0],e[1],e[2]]}function j2(i){const e=kn(),t=e.length|0,n=dh()/2,r=new Dn,s=mt([[1,63231,.55],[-1,16722902,.55]]);try{for(;s["System.Collections.IEnumerator.MoveNext"]();){const d=s["System.Collections.Generic.IEnumerator`1.get_Current"](),p=new sn;p.setAttribute("position",new At(ki(We(()=>gn(f=>{const _=Xt(ae(w((f+1)%t,e),w((f+t-1)%t,e))),m=Ae(w(f,e),re(V(-_.Y,_.X),d[0]*n));return[m.X,-.5,m.Y]},kt(0,1,t-1)))),3)),r.add(new V_(p,Jr(d[1],d[2])))}}finally{yt(s)}const o=Xt(ae(w(1,e),w(0,e))),a=Ae(w(0,e),re(V(-o.Y,o.X),n)),l=ae(w(0,e),re(V(-o.Y,o.X),n)),u=a,c=new sn;c.setAttribute("position",new At(new Float64Array([u.X,-.4,u.Y,l.X,-.4,l.Y]),3)),r.add(new Cc(c,Jr(16774236,1)));for(let d=1;d<=t-1;d++){const p=Xt(ae(w((d+1)%t,e),w(d-1,e))),f=Ae(w(d,e),re(V(-p.Y,p.X),n*.25)),_=ae(w(d,e),re(V(-p.Y,p.X),n*.25)),m=f,g=new sn;g.setAttribute("position",new At(new Float64Array([m.X,-.5,m.Y,_.X,-.5,_.Y]),3)),r.add(new Cc(g,Jr(10466303,.25)))}return i.add(r),r}function J2(i,e,t){const n=new je(Mt(new Zt(Ud()-6,Ud(),48)),xt(e===0?16774236:Ca,.2));return n.position.set(t.X,1.5,t.Y),i.add(n),n}function Hv(i){if(i.Layout!==is()){if(i.Layout=is()|0,i.Size!==Ge()){i.Size=Ge(),i.Scene.remove(i.Frame);const s=kv(i.Scene);i.Border=s[0],i.Spawns=s[1],i.Frame=s[2]}const e=i.Road;if(e!=null){const s=e;i.Scene.remove(s)}i.Road=kn().length>1?j2(i.Scene):void 0;const t=i.Marks;for(let s=0;s<=t.length-1;s++){const o=w(s,t);i.Scene.remove(o)}i.Marks=ls((s,o)=>J2(i.Scene,s,o),yn());const n=i.Rocks;for(let s=0;s<=n.length-1;s++){const o=w(s,n);i.Scene.remove(o)}const r=i.Pads;for(let s=0;s<=r.length-1;s++){const o=w(s,r);i.Scene.remove(o)}i.Rocks=gt(s=>Ov(i.Scene,329231,6978815,s),oi()),i.Pads=gt(s=>H2(i.Scene,s),on().Pads)}}function Q2(i,e){let t,n;const r=document.createElement("div");return r.className=ie(te("panel p%d off"))(e),r.innerHTML=(t=w(w(e,Hn),cu)|0,n=e+1|0,ie(te('<div class="p-header"><span class="name" style="color:#%06x">P%d</span><div class="stocks"></div></div><div class="p-body"><div class="bar-label">HP</div><div class="bar hp"><i></i></div><div class="bar-label">SHIELD</div><div class="bar shield"><i></i></div><div class="bar-label">HEAT</div><div class="bar heat"><i></i></div><div class="bar-label">BOOST</div><div class="bar boost"><i></i></div></div><div class="p-footer"><div class="wep"></div><div class="medals"></div></div>'))(t)(n)),i.appendChild(r),r}function eL(i,e){const t=document.createElement("div");return t.className="tag",t.textContent=k.Player(e),t.hidden=!0,i.appendChild(t),t}function Vv(i,e,t,n,r,s,o,a,l){const u=new sn;u.setAttribute("position",new At(Sn(n*3,p=>{const f=p%3|0;return f===0?e.X:f===1?4:e.Y},Float64Array),3));const c=new Float64Array(n*2);for(let p=0;p<=n-1;p++){const f=s+(Kt.NextDouble()-.5)*2*o,_=r*(.3+Kt.NextDouble());ve(c,p*2,Math.cos(f)*_),ve(c,p*2+1,Math.sin(f)*_)}const d=new G_(u,t);i.Scene.add(d),i.Bursts=bn(new bC(d,c,l,a),i.Bursts)}function Pi(i,e,t,n,r,s,o,a){Vv(i,e,new ou({blending:Hs,color:t,opacity:1,size:a,transparent:!0}),n,r,s,o,1,1.4)}const tL=new bh(()=>new z_().load("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='64' height='64'><radialGradient id='g'><stop offset='0' stop-color='white'/><stop offset='0.55' stop-color='white' stop-opacity='0.45'/><stop offset='1' stop-color='white' stop-opacity='0'/></radialGradient><circle cx='32' cy='32' r='32' fill='url(%23g)'/></svg>"));function Io(i,e,t,n,r){const s=new ou({color:5790822,depthWrite:!1,map:tL.Value,opacity:.45,size:r,transparent:!0});for(let o=1;o<=t;o++)Vv(i,Ae(e,re(jt(Kt.NextDouble()*3.141592653589793*2),Kt.NextDouble()*r*.8)),s,1,n,0,3.141592653589793,.45,.24)}function Pn(i,e,t,n,r){Pi(i,e,t,n,r,0,3.141592653589793,7)}function du(i,e,t,n){i.Scene.add(e),i.Flashes=bn(new AC(e,t,n,n),i.Flashes)}function nL(i,e,t,n,r,s){for(let o=1;o<=6;o++){const a=n+(Kt.NextDouble()-.5)*2*r,l=s*(.45+.55*Kt.NextDouble()),u=jt(a),c=jt(a+3.141592653589793/2);let d=e;for(let p=1;p<=6;p++){const f=p/6,_=(Kt.NextDouble()-.5)*l*(p===6?.12:.25),m=Ae(Ae(e,re(u,l*f)),re(c,_)),g=ae(m,d),h=new je(Mt(new Hi(ke(g),2.5)),xt(t,1)),v=re(Ae(d,m),.5);h.position.set(v.X,5,v.Y),h.rotation.y=-Math.atan2(g.Y,g.X),du(i,h,0,.1+Kt.NextDouble()*.12),d=m}}}function Un(i,e,t,n,r,s){const o=new je(Mt(new Zt(n*.86,n,44)),xt(t,1));o.position.set(e.X,3,e.Y),du(i,o,r,s)}function iL(i,e,t,n){for(let r=1;r<=n;r++){const s=1.1+Kt.NextDouble()*.9,o=new je(Mt(new Gs(4+Kt.NextDouble()*5,3)),xt(r%2===0?t:16742942,1));o.position.set(e.X,4,e.Y),i.Scene.add(o),i.Shards=bn(new EC(o,(Kt.NextDouble()-.5)*16,s,e,re(jt(Kt.NextDouble()*3.141592653589793*2),160+Kt.NextDouble()*320),0,s),i.Shards)}}function rL(i,e,t,n,r){if(!Ka()){const s=new je(Mt(new Zt(0,n,32)),xt(t,1));s.position.set(e.X,3,e.Y),du(i,s,1.5,r)}}function sL(i,e){const t=(s,o)=>Math.abs(o)<1e-6?1e9:fe((Ge()-s)/o,(-Ge()-s)/o);let n;const r=Dt(We(()=>gn(s=>gn(o=>{const a=s*e.X+o*e.Y;return a>1e-6?_t((Ws()-(s*i.X+o*i.Y))/a):_r()},[1,-1]),[1,-1])));return n=Da(r)?1e9:px(r,{Compare:(s,o)=>fn(s,o)|0}),fe(0,$e($e(t(i.X,e.X),t(i.Y,e.Y)),n))}function aL(i,e,t,n){const r=Xt(ae(t,e)),s=Ae(e,re(r,sL(e,r))),o=re(Ae(e,s),.5),a=new je(Mt(new Hi(ke(ae(s,e)),9)),xt(n,1));a.position.set(o.X,5,o.Y),a.rotation.y=-Math.atan2(r.Y,r.X),du(i,a,0,.32)}function oL(i,e){i.Bursts=Xs(t=>{if(t.Life=t.Life-e*t.Decay,t.Life<=0)return i.Scene.remove(t.Points),!1;{const n=t.Points.geometry.getAttribute("position"),r=n.array;for(let s=0;s<=~~(t.Vel.length/2)-1;s++)ve(r,s*3,w(s*3,r)+w(s*2,t.Vel)*e),ve(r,s*3+2,w(s*3+2,r)+w(s*2+1,t.Vel)*e);return n.needsUpdate=!0,t.Points.material.opacity=t.Life,!0}},i.Bursts)}function lL(i,e){i.Flashes=Xs(t=>{if(t.Life=t.Life-e,t.Life<=0)return i.Scene.remove(t.Obj),!1;{const n=1-t.Life/t.Span,r=1+t.Grow*n;return t.Obj.scale.set(r,1,r),t.Obj.material.opacity=1-n,!0}},i.Flashes)}function cL(i,e){i.Shards=Xs(t=>(t.Life=t.Life-e,t.Life<=0?(i.Scene.remove(t.Obj),!1):(t.Vel=re(t.Vel,fe(0,1-1.5*e)),t.Pos=Ae(t.Pos,re(t.Vel,e)),t.Obj.position.set(t.Pos.X,4,t.Pos.Y),t.Obj.rotation.y=t.Obj.rotation.y+t.Spin*e,t.Obj.material.opacity=$e(1,2*t.Life/t.Span),t.Puff=t.Puff-e,t.Puff<=0&&(t.Puff=.1,Pi(i,t.Pos,16747051,2,26,0,3.141592653589793,6),Io(i,t.Pos,1,16,30)),!0)),i.Shards)}function jf(i,e){const t=e?"M8 32 L48 32 M34 18 L48 32 L34 46":i.tag===1?"M4 32 L60 32 M46 24 L46 40":i.tag===2?"M32 14 L32 50 M14 32 L50 32 M19 19 L45 45 M45 19 L19 45 M32 32 m-9 0 a9 9 0 1 0 18 0 a9 9 0 1 0 -18 0":i.tag===3?"M10 40 L40 22 M40 22 L30 22 M40 22 L40 32 M22 46 L52 28":i.tag===4?"M24 16 a20 20 0 0 1 0 32 M36 10 a28 28 0 0 1 0 44 M10 32 L18 32":i.tag===5?"M8 32 L20 20 L28 40 L38 22 L46 42 L56 30":i.tag===6?"M8 32 L36 32 M36 32 m-10 0 a10 10 0 1 0 20 0 a10 10 0 1 0 -20 0 M56 20 L56 44":i.tag===7?"M32 8 L36 26 L54 22 L40 34 L52 50 L34 42 L28 58 L26 40 L8 44 L22 32 L12 16 L28 24 Z":i.tag===8?"M20 12 L44 10 L56 28 L50 50 L26 54 L10 38 Z M26 30 L36 26 L40 36":i.tag===9?"M32 32 m-22 0 a22 22 0 1 0 44 0 a22 22 0 1 0 -44 0 M32 32 m-9 0 a9 9 0 1 0 18 0 a9 9 0 1 0 -18 0 M10 32 L4 32 M54 32 L60 32":i.tag===10?"M14 20 L50 20 M14 20 L14 44 M50 20 L50 44 M14 44 L50 44 M32 20 L32 44 M20 52 L26 58 M38 58 L44 52":i.tag===11?"M32 12 L48 21 L48 39 L32 48 L16 39 L16 21 Z M32 30 L58 30 M32 30 m-5 0 a5 5 0 1 0 10 0 a5 5 0 1 0 -10 0":i.tag===12?"M32 32 m-22 0 a22 22 0 1 0 44 0 a22 22 0 1 0 -44 0 M32 18 L32 32 L42 38 M32 4 L32 10 M32 54 L32 60":"M10 32 L38 32 M42 32 L54 32";return ie(te('<svg viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"><path d="%s"/></svg>'))(t)}function $t(i){const e=i%4*100/3,t=~~(i/4)*100/3;return ie(te('<i class="mi" style="background-position:%.4f%% %.4f%%"></i>'))(e)(t)}function uL(i,e,t,n,r,s){const o=(u,c)=>{const d=Wt(w(u,e.Ships))|0,p=w(u,i.Names);return ie(te('<b class="%s" style="color:#%06x">%s</b>'))(c)(d)(p)},a=(u,c)=>{const d=c?k.RingOut:Ng(r),p=Wt(w(u,e.Ships))|0,f=jf(r,c);return ie(te('<span style="color:#%06x">%s<em>%s</em></span>'))(p)(f)(d)},l=document.createElement("div");if(l.innerHTML=n>=0&&n!==t?o(n,"")+a(n,s)+o(t,"dead"):a(t,s?!0:!it(r,Ie.Singularity))+o(t,"dead"),i.Feed.prepend(l),n>=0&&n!==t){const u=w(n,i.Panels);u.style.animation="none",u.offsetWidth,u.style.animation="score .7s ease-out"}for(;i.Feed.children.length>4;)i.Feed.lastElementChild.remove();window.setTimeout(()=>{l.remove()},5e3)}function k0(i){const e=Ng(i);return ie(te('<span class="wname">%s</span>'))(e)}function dL(i){let e;if(Ko(i)){const t=i.Ghosting?Ie.Mines:Ie.Rock,n=i.LaunchCd<=0?"ready":"wait",r=jf(t,!1),s=k0(t),o=k.SwapMode(Ag(mx.Swap));return ie(te('<span class="%s">%s</span>%s<span class="ammo">%s</span>'))(n)(r)(s)(o)}else{if(ot()&&it(i.Weapon,Ie.Blaster))return"";{const t=(Mh(i.Weapon)>0?i.Ammo:0)|0;return jf(i.Weapon,!1)+k0(i.Weapon)+(e=Th(t,"●"),ie(te('<span class="ammo">%s</span>'))(e))}}}function fL(i,e,t){Ja((n,r)=>{let s,o,a,l,u,c,d,p,f,_,m,g,h,v,M,S,P,E,A,L,y,x,C,N;const D=w(n,i.Panels);r.Alive&&r.Hp<w(n,i.Hp)&&(i.Shake[n]=$e(1,w(n,i.Shake)+(w(n,i.Hp)-r.Hp)/40)),i.Hp[n]=r.Alive?r.Hp:Cr,i.Shake[n]=$o()?fe(0,w(n,i.Shake)-t*3.4):0;const I=w(n,i.Shake),J=I*9;D.style.transform=(s=(Kt.NextDouble()-.5)*J,o=(Kt.NextDouble()-.5)*J,a=1+I*.09,ie(te("translate(%.1fpx,%.1fpx) scale(%.3f)"))(s)(o)(a)),D.className=(l=n%2===1?" r":"",u=r.Active?"":" off",c=i_(r)?" hurt":"",d=r.Locked>0?" cooked":"",ie(te("panel p%d%s%s%s%s"))(n)(l)(u)(c)(d)),D.style.color=(p=Wt(r)|0,ie(te("#%06x"))(p)),D.querySelector(".name").textContent=w(n,i.Names),D.querySelector(".name").style.color=(f=Wt(r)|0,ie(te("#%06x"))(f)),D.querySelector(".hp i").style.width=(_=fe(0,r.Hp)/Cr*100,ie(te("%.0f%%"))(_)),D.querySelector(".shield i").style.width=(m=r.Shield/Kc()*100,ie(te("%.0f%%"))(m)),D.querySelector(".boost i").style.width=(g=r.Boost/Ns*100,ie(te("%.0f%%"))(g)),D.querySelector(".heat i").style.width=(h=r.Heat/dc*100,ie(te("%.0f%%"))(h));const q=D.querySelector(".stocks");let oe;if(ot()){const nt=k.Lap(w(ny(e.Ships,n)-1,k.Places),$e(~~lc(),r.Laps+1),~~lc());oe=ie(te("<span>%s</span>"))(nt)}else{const nt='<svg class="stock-icon" viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="4.5" stroke-linejoin="round"><path d="M24 4 L41 40 L24 32 L7 40 Z"/></svg>';oe=cn("",Dt(We(()=>gn(Z=>_t(nt),kt(1,1,fe(0,r.Stocks))))))}q.dataset.html!==oe&&(q.dataset.html=oe,q.innerHTML=oe),q.style.color=(v=Wt(r)|0,ie(te("#%06x"))(v));const X=D.querySelector(".wep"),he=dL(r);X.dataset.html!==he&&(X.dataset.html=he,X.innerHTML=he);const pe=D.querySelector(".medals");let Se;const Ne=[];r.FirstBloodMedal>0&&Ne.push((M=$t(0),ie(te('<span class="medal fb" title="%s">%s</span>'))(k.FirstBlood)(M))),r.DoubleKillMedals>0&&Ne.push((S=$t(1),ie(te('<span class="medal dk" title="%s">%s</span>'))(k.DoubleKill)(S))),r.TripleKillMedals>0&&Ne.push((P=$t(2),ie(te('<span class="medal tk" title="%s">%s</span>'))(k.TripleKill)(P))),r.RailKillMedals>0&&Ne.push((E=$t(3),ie(te('<span class="medal rk" title="%s">%s</span>'))(k.RailKillMedal)(E))),r.RamKillMedals>0&&Ne.push((A=$t(4),ie(te('<span class="medal rm" title="%s">%s</span>'))(k.RamKillMedal)(A))),r.OnFireMedals>0&&Ne.push((L=$t(5),ie(te('<span class="medal of" title="%s">%s</span>'))(k.OnFireMedal)(L))),r.VoidMedals>0&&Ne.push((y=$t(6),ie(te('<span class="medal vd" title="%s">%s</span>'))(k.VoidMedal)(y))),r.HoleMedals>0&&Ne.push((x=$t(7),ie(te('<span class="medal eh" title="%s">%s</span>'))(k.HoleMedal)(x))),r.AbductMedals>0&&Ne.push((C=$t(8),ie(te('<span class="medal ab" title="%s">%s</span>'))(k.AbductMedal)(C))),r.GraveMedals>0&&Ne.push((N=$t(9),ie(te('<span class="medal gr" title="%s">%s</span>'))(k.GraveMedal)(N))),Se=cn("",Ne),pe.dataset.html!==Se&&(pe.dataset.html=Se,pe.innerHTML=Se)},e.Ships)}function hL(i,e){let t;i.KillCd=fe(0,i.KillCd-e),i.Tint=Ka()?0:fe(0,i.Tint-e*vC),i.Vignette.style.opacity=i.Tint.toString(),i.Tint>0&&(i.Vignette.style.boxShadow=(t=i.TintHex,ie(te("inset 0 0 %.1fvmin 0 %s"))(MC)(t)))}function pL(i,e){i.Spike=Ka()?0:fe(0,i.Spike-e*2.6),i.Bloom.strength=1.3+i.Spike*1.7}function mL(i,e){Ja((t,n)=>{let r,s,o;const a=w(t,i.Tags),l=new H(n.Pos.X,0,n.Pos.Y).project(i.Camera),u=i.Intro<=0&&l.z<1&&(n.Alive&&n.Invuln>0?!0:Ko(n));if(a.hidden=!u,u){a.textContent=w(t,i.Names);const c=(l.x+1)/2*window.innerWidth,d=(1-l.y)/2*window.innerHeight-44;a.style.left=(r=fe(40,$e(window.innerWidth-40,c)),ie(te("%.0fpx"))(r)),a.style.top=(s=fe(40,$e(window.innerHeight-40,d)),ie(te("%.0fpx"))(s)),a.style.opacity=Ko(n)?"0.55":"1",a.style.color=(o=Wt(n)|0,ie(te("#%06x"))(o))}},e.Ships)}function gL(i,e){Ja((t,n)=>{const r=e.Ships.some(s=>s.Active&&s.Alive?s.Next===t:!1);n.material.opacity=r?.6+.3*Math.sin(e.Time*6):.18},i.Marks)}function _L(i,e){ba((t,n)=>{t.visible=n.Active&&!ot(),t.material.color.setHex(Wt(n))},i.Spawns,e.Ships)}function vL(i,e,t,n){let r;const s=n.Tow;let o,a,l;switch(s.tag){case 1:{n.Alive?(o=0,a=s.fields[0]):o=2;break}case 2:{n.Alive?(o=1,l=s.fields[0]):o=2;break}default:o=2}switch(o){case 0:{r=w(a,e.Ships).Pos;break}case 1:{r=w(l,oi()).Pos;break}default:r=void 0}if(t.Tether.visible=r!=null,r!=null){const u=r,c=ae(u,n.Pos),d=re(Ae(n.Pos,u),.5);t.Tether.position.set(d.X,4,d.Y),t.Tether.rotation.y=-Math.atan2(c.Y,c.X),t.Tether.scale.set(ke(c),1,1),t.Tether.material.opacity=.5+.3*Math.sin(i*25),t.Tether.material.color.setHex(Wt(n))}}function ML(i,e,t,n,r){const s=Ko(r),o=s&&r.Ghosting;if(n.Root.visible=r.Alive?!0:o,n.Mark.visible=s&&!o,n.Vent.visible=r.Alive&&r.Heat>.001,n.Vent.visible){const v=$e(1,r.Heat/dc),M=43+~~(212*v)|0;if(n.Vent.position.set(r.Pos.X,3,r.Pos.Y),n.Vent.geometry.setDrawRange(0,~~(X_*v)*6),n.Vent.material.color.setHex(16711680|M<<8|M),n.Vent.material.opacity=r.Locked>0?.7+.3*Math.sin(i*16):.3,r.Locked>0&&Kt.NextDouble()<.35){const S=jt(r.Angle+(Kt.NextDouble()<.5?1:-1)*3.141592653589793/2);Pi(t,Ae(r.Pos,re(S,It+2)),16760992,1,70,Math.atan2(S.Y,S.X),.35,6)}}if(o)n.Root.position.set(r.Pos.X,0,r.Pos.Y),n.Root.rotation.y=-r.Angle,n.Flame.visible=!1,n.Retro.visible=!1,n.Coil.visible=!1,n.Laser.visible=!1,n.Bubble.visible=!1,n.Shield.visible=!1,n.Body.material.opacity=r.LaunchCd<=0?.3+.1*Math.sin(i*6):.18,dl(n.History);else if(s){const v=2.5*t.CamH/Ra();n.Mark.position.set(r.Pos.X,3,r.Pos.Y),n.Mark.scale.set(v,1,v),n.Mark.rotation.y=-r.Angle,n.Mark.material.color.setHex(Wt(r)),n.Mark.material.opacity=r.LaunchCd<=0?.6+.4*Math.sin(i*6):.25,dl(n.History)}else if(r.Alive){n.Root.position.set(r.Pos.X,0,r.Pos.Y),n.Root.rotation.y=-r.Angle,n.Flame.visible=r.Thrusting>0;const v=r.Thrusting*(.8+.3*Math.sin(i*40));n.Flame.scale.set(v,1,v*.7),n.Retro.visible=r.Reversing;const M=.8+.3*Math.sin(i*50);if(n.Retro.scale.set(M,1,M),r.Reversing){const A=n.Retro.children;for(let L=0;L<=A.length-1;L++)w(L,A).material.color.setHex(16777215-Wt(r))}const S=it(r.Weapon,Ie.Rail)&&r.Charge>0;if(n.Coil.visible=S,n.Laser.visible=S,n.Bubble.visible=it(r.Weapon,Ie.Tractor)&&r.Charge>0,n.Bubble.visible&&(n.Bubble.scale.set(Ho(),1,Ho()),n.Bubble.material.opacity=.06+.14*$e(1,r.Charge/ns()),n.Bubble.material.color.setHex(Wt(r))),S){const A=$e(1,r.Charge/ns());n.Laser.material.color.setHex(Wt(r)),n.Laser.material.opacity=.15+.35*A,n.Coil.scale.set(.3+A,1,.3+A),n.Coil.material.opacity=.4+.6*A}n.Shield.visible=r.Shield>0,r.Shield>0&&(n.Shield.material.opacity=.35+.45*(r.Shield/Kc())+.2*Math.sin(i*8),n.Shield.rotation.z=i*.9),n.Body.material.opacity=r.Invuln>0?.4+.4*Math.sin(i*30):1,n.Body.material.color.setHex(r.Team>0?w(r.Team,W_):16777215);const P=xC(r)|0,E=w(P,SC);if(n.Body.rotation.y=P===3?3.141592653589793:0,n.Body.material.map.offset.set(E[0]/Pc[0],1-(E[1]+Hf[1])/Pc[1]),n.Flame.material.color.setHex(Wt(r)),n.History.splice(0,0,r.Pos),n.History.length>2&&n.History.splice(n.History.length-1,1),r.Thrusting>0){const A=r.Thrusting>1.5,L=gx()*(A?vp():1),y=Math.cos(r.Angle),x=Math.sin(r.Angle),C=Mp()*y-Sp()*x,N=Mp()*x+Sp()*y,D=r.Angle+3.141592653589793+(Kt.NextDouble()-.5)*.5;n.Particles.push(new yC(r.Pos.X+C,r.Pos.Y+N,Math.cos(D)*L,Math.sin(D)*L,0,fe(.05,_x()))),n.Particles.length>K_&&n.Particles.splice(0,1)}}else dl(n.History),dl(n.Particles);let a=mt(n.Particles);try{for(;a["System.Collections.IEnumerator.MoveNext"]();){const v=a["System.Collections.Generic.IEnumerator`1.get_Current"]();v.Age=v.Age+e,v.PX=v.PX+v.VX*e,v.PZ=v.PZ+v.VZ*e}}finally{yt(a)}vx(v=>v.Age>=v.MaxAge,n.Particles);const l=r.Alive&&r.Thrusting>1.5?vp():1,u=Mx()*Math.sin(i*Sx());n.Trail.material.opacity=$e(1,fe(0,(xx()+yx()*r.Streak+u)*l)),n.Trail.material.color.setHex(Wt(r));const c=n.Trail.geometry.getAttribute("position"),d=n.Trail.geometry.getAttribute("color"),p=c.array,f=d.array,_=fe(.05,.5*Tx()*l);let m=0;const g=(v,M,S)=>{ve(p,m*3,v),ve(p,m*3+1,2),ve(p,m*3+2,M),ve(f,m*3,S),ve(f,m*3+1,S),ve(f,m*3+2,S),m=m+1|0};let h=mt(n.Particles);try{for(;h["System.Collections.IEnumerator.MoveNext"]();){const v=h["System.Collections.Generic.IEnumerator`1.get_Current"]();let M;const S=1-v.Age/v.MaxAge;M=Math.pow(S,bx());const P=_*M;g(v.PX-P,v.PZ-P,M),g(v.PX+P,v.PZ-P,M),g(v.PX+P,v.PZ+P,M),g(v.PX-P,v.PZ-P,M),g(v.PX+P,v.PZ+P,M),g(v.PX-P,v.PZ+P,M)}}finally{yt(h)}n.Trail.geometry.setDrawRange(0,m),c.needsUpdate=!0,d.needsUpdate=!0}function SL(i,e){let t,n;const r=a=>Zd(w(a,i.Ships))!==Zd(e),s=(a,l)=>{const u=ae(a,e.Pos);return[Math.atan2(u.Y,u.X),l]},o=Ye(En(a=>{const l=ae(e.Pos,a.Pos),u=Xt(a.Vel),c=tn(l,u);if(r(a.Owner)&&c>0&&c<620&&ke(ae(l,re(u,c)))<60)return s(a.Pos,1-c/620)},i.Bullets),Ye(En(a=>{const l=ae(e.Pos,a.Pos),u=Xt(a.Vel),c=tn(l,u);if(c>0&&c<700&&ke(ae(l,re(u,c)))<a.Radius+2*It)return s(a.Pos,1-c/700)},i.Rocks),Ye(En(a=>{const l=ke(ae(a.Pos,e.Pos));if(r(a.Owner)&&a.Fuse>=0&&l<hc()*2.5)return s(a.Pos,1-l/(hc()*2.5))},i.Mines),Ye(En(a=>{const l=ae(e.Pos,a.Pos),u=ke(l),c=it(a.Weapon,Ie.Rail)?4*Ge():Ho()*1.2,d=Math.atan2(l.Y,l.X)-a.Angle;if(a.Alive&&a.Charge>0&&r(a.Id)&&u<c&&Math.abs(Math.atan2(Math.sin(d),Math.cos(d)))<.35)return s(a.Pos,.5+.5*$e(1,a.Charge/ns()))},Ke(i.Ships)),(t=i.Hole,t!=null?ke(ae(t.Pos,e.Pos))<Ia()*12?(n=t,en(s(n.Pos,1-ke(ae(n.Pos,e.Pos))/(Ia()*12)))):Re():Re())))));return Da(o)?ot()?[s(w(e.Next,yn()),.5),!0]:void 0:[Ax(a=>a[1],o,{Compare:(a,l)=>fn(a,l)|0}),!1]}function xL(i,e,t,n){const r=n.Alive?SL(e,n):void 0;if(t.Warn.visible=r!=null,r!=null){const s=r[1],o=r[0][1],a=r[0][0];t.Warn.position.set(n.Pos.X,3,n.Pos.Y),t.Warn.rotation.y=-a,t.Warn.material.color.setHex(s?Ca:16726876),t.Warn.material.opacity=s?.7:(.25+.75*o)*(.7+.3*Math.sin(i*18))}}function yL(i,e,t){Ja((n,r)=>{i_(r)?(i.Smoke[n]=w(n,i.Smoke)+t,w(n,i.Smoke)>.07&&(i.Smoke[n]=0,Io(i,r.Pos,2,26,22))):i.Smoke[n]=0},e.Ships)}function TL(i,e){let t,n;const r=r_(e.Time);i.Border.scale.set(r,1,r);const s=Zr(e)&&r>Q0;w(0,i.Border.children).material.color.setHex(s?16726876:63231);const o=ot()?e.Time:fe(0,Bo()-e.Time);i.Clock.className=Zr(e)?"sudden":"",i.Clock.textContent=Zr(e)?k.SuddenDeath:(t=~~(~~o/60)|0,n=~~o%60|0,ie(te("%d:%02d"))(t)(n))}function bL(i,e){const t=Zr(e);ba((n,r)=>{const s=r.RespawnIn<=0&&!(t&&r.Kind===1);n.material.opacity=s?.75+.25*Math.sin(e.Time*4):.12;let o;const a=r.Kind|0;o=a===1?Sg:a===2?Mg:xg;const l=s?1:1-r.RespawnIn/o;n.scale.set(l,1,l)},i.Pads,e.Pads)}function EL(i,e){ba((t,n)=>{const r=n.RespawnIn<=0;t.visible=r,r&&(t.position.set(n.Pos.X,0,n.Pos.Y),t.rotation.set(e.Time*.7,e.Time*1.3,0))},i.Crates,e.Crates)}function AL(i,e,t){const n=i.Puff+t>.05;let r=0;const s=mt(e.Rocks);try{for(;s["System.Collections.IEnumerator.MoveNext"]();){const o=s["System.Collections.Generic.IEnumerator`1.get_Current"]();if(n&&Pi(i,o.Pos,16750933,4,70,Math.atan2(-o.Vel.Y,-o.Vel.X),.7,18),r<i.Boulders.length){const a=w(r,i.Boulders);a.visible=!0,a.position.set(o.Pos.X,0,o.Pos.Y),a.rotation.set(o.Life*1.7,o.Life*1.1,0),r=r+1|0}}}finally{yt(s)}for(let o=r;o<=i.Boulders.length-1;o++)w(o,i.Boulders).visible=!1}function wL(i,e){let t=0;const n=mt(e.Portals);try{for(;n["System.Collections.IEnumerator.MoveNext"]();){const r=n["System.Collections.Generic.IEnumerator`1.get_Current"](),s=mt([r.A,r.B]);try{for(;s["System.Collections.IEnumerator.MoveNext"]();){const o=s["System.Collections.Generic.IEnumerator`1.get_Current"](),a=mt([!1,!0]);try{for(;a["System.Collections.IEnumerator.MoveNext"]();){const l=a["System.Collections.Generic.IEnumerator`1.get_Current"]();if(t<i.Gates.length){const u=w(t,i.Gates);u.visible=!0,u.position.set(o.X,2,o.Y),u.rotation.z=(l?-2.4:.8)*e.Time;const c=$e(1,r.Life/1.5)*$e(1,(dg()-r.Life)*3);u.material.opacity=c*(l?.9:.55+.25*Math.sin(e.Time*5)),t=t+1|0}}}finally{yt(a)}}}finally{yt(s)}}}finally{yt(n)}for(let r=t;r<=i.Gates.length-1;r++)w(r,i.Gates).visible=!1}function CL(i,e){let t=0,n=0,r=0;const s=mt(e.Deploys);try{for(;s["System.Collections.IEnumerator.MoveNext"]();){const o=s["System.Collections.Generic.IEnumerator`1.get_Current"](),a=Wt(w(o.Owner,e.Ships))|0;if(o.Kind===ko&&t<i.Walls.length){const l=w(t,i.Walls);l.visible=!0,l.position.set(o.Pos.X,3,o.Pos.Y),l.rotation.y=-(o.Angle+3.141592653589793/2),l.material.color.setHex(3898367),l.material.opacity=$e(1,o.Life)*(.55+.25*Math.sin(e.Time*6)),t=t+1|0}else if(o.Kind===Ls&&n<i.Turrets.length){const l=w(n,i.Turrets),u=l[0],c=l[2],d=l[1];u.visible=!0,u.position.set(o.Pos.X,0,o.Pos.Y),u.rotation.y=-o.Angle,d.material.color.setHex(a),d.material.opacity=$e(1,o.Life),c.material.color.setHex(a),c.material.opacity=.15+.65*fe(0,o.Hp/rg()),n=n+1|0}else if(o.Kind===Yc&&r<i.Bubbles.length){const l=w(r,i.Bubbles),u=l[0],c=l[2];u.visible=!0,u.position.set(o.Pos.X,0,o.Pos.Y),u.rotation.y=e.Time*.5;const d=$e(1,o.Life/.6);l[1].material.opacity=d*.12,c.material.color.setHex(a),c.material.opacity=d*(.5+.3*Math.sin(e.Time*4)),r=r+1|0}}}finally{yt(s)}for(let o=t;o<=i.Walls.length-1;o++)w(o,i.Walls).visible=!1;for(let o=n;o<=i.Turrets.length-1;o++){const a=w(o,i.Turrets);a[0].visible=!1}for(let o=r;o<=i.Bubbles.length-1;o++){const a=w(o,i.Bubbles);a[0].visible=!1}}function RL(i,e,t){const n=e.Hole;if(n==null)i.Hole.visible=!1;else{const r=n,s=Ia();i.Hole.visible=!0,i.Hole.position.set(r.Pos.X,0,r.Pos.Y),i.Hole.scale.set(s/Kr(),1,s/Kr());const o=Ex(r.Life)?1:$e(1,r.Life/1.5)*$e(1,(hg()-r.Life)*2);if(i.Horizon.material.opacity=o*(.85+.15*Math.sin(e.Time*7)),i.Horizon.rotation.y=e.Time*1.5,i.Halo.material.opacity=o*.2,i.Halo.rotation.y=-e.Time*.4,i.Puff+t>.05){const a=Kt.NextDouble()*3.141592653589793*2;Pi(i,Ae(r.Pos,re(jt(a),Ia()*8)),Yo,3,260,a+3.141592653589793+.5,.25,14)}}}function LL(i,e){let t=0;const n=mt(e.Mines);try{for(;n["System.Collections.IEnumerator.MoveNext"]();){const r=n["System.Collections.Generic.IEnumerator`1.get_Current"]();if(t<i.Mines.length){const s=w(t,i.Mines);s.visible=!0,s.position.set(r.Pos.X,3,r.Pos.Y);const o=r.Fuse>=0?1.2+.4*Math.sin(e.Time*34):1;s.scale.set(o,o,o),s.rotation.set(e.Time*1.1,e.Time*.8,0),t=t+1|0}}}finally{yt(n)}for(let r=t;r<=i.Mines.length-1;r++)w(r,i.Mines).visible=!1}function PL(i,e,t){i.Puff=i.Puff+t;const n=i.Puff>.05;n&&(i.Puff=0);let r=0;const s=mt(e.Bullets);try{for(;s["System.Collections.IEnumerator.MoveNext"]();){const o=s["System.Collections.Generic.IEnumerator`1.get_Current"]();if(n&&o.Kind===2&&Pi(i,o.Pos,14211288,4,70,Math.atan2(-o.Vel.Y,-o.Vel.X),.7,18),r<i.Bullets.length){const a=w(r,i.Bullets);a.visible=!0,a.position.set(o.Pos.X,4,o.Pos.Y),a.rotation.y=-Math.atan2(o.Vel.Y,o.Vel.X);const l=ke(o.Vel)/qc();a.scale.set(fe(.6,l*2.2),1,o.Kind===2?1.6:1),a.material.color.setHex(o.Kind===2?16747069:Wt(w(o.Owner,e.Ships))),r=r+1|0}}}finally{yt(s)}for(let o=r;o<=i.Bullets.length-1;o++)w(o,i.Bullets).visible=!1}function IL(){const i=new sC,e=window.innerWidth,t=window.innerHeight,n=new pi(40,Uv(),1,1e4),r=new rC({antialias:!0,preserveDrawingBuffer:!0});r.setPixelRatio($e(window.devicePixelRatio,2)),r.setSize(e,t),document.body.appendChild(r.domElement);const s=P2(r),o=D2(new tt(e,t),1.3,.5,.12);s.addPass(I2(i,n)),s.addPass(o);const a=Z2(i),l=q2(i),u=document.getElementById("hud"),c=new wC(i,n,r,s,o,Sn(4,d=>O2(i,d)),[],[],void 0,[],-1,Sn(uC,d=>Y2(i)),Sn(dC,d=>V2(i)),Sn(fC,d=>Ov(i,16742942,16769200,new Tg(zn,ph()))),Sn(hC*4,d=>z2(i,d)),Sn(rd,d=>W2(i)),Sn(rd,d=>K2(i)),Sn(rd,d=>X2(i)),l[0],l[1],l[2],Sn(4,d=>G2(i)),Sn(4,d=>Q2(u,d)),Sn(4,d=>eL(u,d)),Sn(4,k.Player),a[1],0,a[0],a[2],Ge(),document.getElementById("clock"),document.getElementById("feed"),document.getElementById("banner"),document.getElementById("vignette"),Re(),Re(),Re(),Nn(new Float64Array(4),0,4,Cr),new Float64Array(4),new Float64Array(4),0,0,0,0,"#ffffff",0,zn,Ra());return Hv(c),window.addEventListener("resize",d=>{y2(c)}),c}const Qh=i=>{Hv(i)};function To(i,e,t,n){const r=mt(t);try{for(;r["System.Collections.IEnumerator.MoveNext"]();){let s;const o=r["System.Collections.Generic.IEnumerator`1.get_Current"]();switch(o.tag){case 3:break;case 5:{Pn(i,o.fields[0],16777215,16,200);break}case 6:{Pn(i,o.fields[0],16750933,8,130);break}case 7:{const a=o.fields[0];Pn(i,a,16777215,18,220),Un(i,a,16777215,It+8,2.2,.35);break}case 8:{Pn(i,o.fields[0],3407820,o.fields[1]?26:14,150);break}case 9:{const a=o.fields[0];Pn(i,a,16731549,20,140),Un(i,a,16731549,30,1.8,.5);break}case 10:{const a=o.fields[0];Pn(i,a,16774236,26,190),Un(i,a,16774236,34,2.4,.45);break}case 11:{Un(i,o.fields[0],16777215,40,-.7,$e(.9,ns()));break}case 12:{const a=o.fields[0];aL(i,a,o.fields[1],Wt(w(o.fields[2],e.Ships))),Pn(i,a,16777215,22,260),i.Spike=fe(i.Spike,.7);break}case 13:{Pn(i,o.fields[0],16722765,8,90);break}case 14:{Un(i,o.fields[0],16722765,hc(),.2,.35);break}case 15:{const a=o.fields[0];Pn(i,a,16738859,40,300),Io(i,a,10,50,30),Un(i,a,16738859,Gd(),1.3,.45),i.Spike=fe(i.Spike,.8);break}case 16:{const a=o.fields[0];Pi(i,a,Wt(w(o.fields[2],e.Ships)),34,og(),o.fields[1],lg(),7),Un(i,a,12576511,120,2.2,.4);break}case 17:{const a=o.fields[0];Io(i,a,6,34,16),Un(i,a,16777215,It+6,1.5,.35);break}case 18:{const a=o.fields[0],l=o.fields[1];nL(i,a,10351615,l,Vd()*1.3,Hd()*1.3),Pi(i,a,12580607,48,Hd()*2.6,l,Vd()*1.2,11),i.Spike=fe(i.Spike,.4);break}case 19:{Un(i,o.fields[0],Wt(w(o.fields[1],e.Ships)),30,3,.3);break}case 20:{const a=o.fields[0];Pn(i,a,16750933,18,200),Un(i,a,16750933,ph(),2.5,.4);break}case 21:{const a=mt([o.fields[0],o.fields[1]]);try{for(;a["System.Collections.IEnumerator.MoveNext"]();){const l=a["System.Collections.Generic.IEnumerator`1.get_Current"]();Un(i,l,Ca,Ta(),3,.6),Pn(i,l,Ca,20,160)}}finally{yt(a)}break}case 22:{Pn(i,o.fields[0],Ca,12,140);break}case 24:{const a=o.fields[0],l=Wt(w(a.Owner,e.Ships))|0;Un(i,a.Pos,l,a.Kind===Yc?Co():a.Kind===ko?_h()/2:Zi+8,2.4,.4),Pn(i,a.Pos,l,18,150);break}case 23:{const a=o.fields[0];Un(i,a,Yo,Kr()*9,-.8,.9),Pn(i,a,Yo,40,240),i.Spike=fe(i.Spike,.9);break}case 1:{const a=o.fields[0],l=o.fields[1]|0,u=Wt(w(l,e.Ships))|0,c=w(l,i.Ships);let d;if(c.History.length>1){const f=ae(w(0,c.History),w(1,c.History));d=Math.atan2(f.Y,f.X)}else d=Kt.NextDouble()*3.141592653589793*2;rL(i,a,16752717,16,.1),iL(i,a,u,9),Pi(i,a,16738836,52,320,d,3.141592653589793,10),Pi(i,a,16761405,22,150,d,3.141592653589793,12),Pi(i,a,u,40,380,d,.8,7),Io(i,a,12,60,42),Un(i,a,16747051,44,2.6,.34),Un(i,a,u,34,2.4,.46);const p=i.KillCd>0?_C:1;i.KillCd=gC,i.Spike=fe(i.Spike,mC*p),i.Jolt=1,i.Tint=fe(i.Tint,pC*p),i.TintHex=(s=(o.fields[2]?4021503:u)|0,ie(te("#%06x"))(s));break}case 2:{uL(i,e,o.fields[0],o.fields[1],o.fields[2],o.fields[3]);break}case 25:{const a=o.fields[0]|0;Pn(i,w(a,e.Ships).Pos,Wt(w(a,e.Ships)),40,260);break}case 4:break;default:Pn(i,o.fields[0],16777215,10,160)}}}finally{yt(r)}yL(i,e,n),ba((s,o)=>{ML(e.Time,n,i,s,o)},i.Ships,e.Ships),ba((s,o)=>{vL(e.Time,e,s,o)},i.Ships,e.Ships),ba((s,o)=>{xL(e.Time,e,s,o)},i.Ships,e.Ships),TL(i,e),bL(i,e),EL(i,e),LL(i,e),AL(i,e,n),wL(i,e),CL(i,e),RL(i,e,n),PL(i,e,n),oL(i,n),cL(i,n),lL(i,n),x2(i,e,n),mL(i,e),_L(i,e),gL(i,e),fL(i,e,n),hL(i,n),pL(i,n),i.Composer.render()}Zx();Nx();mR();eR();const Gv="nda-tut",Jf=document.getElementById("tut");let Qf=Tt(!1);function DL(){let i;if(window.localStorage.getItem(Gv)===an()){const e=cn("",ln(t=>{let n;const r=cn("",ln((n=ie(te("<i>%s</i>")),n),t[0]));return ie(te('<div class="row"><div class="keys">%s</div><div class="lbl">%s</div></div>'))(r)(t[1])},Rx()));Jf.innerHTML=(i=Cv("kb"),ie(te('<div class="tp"><div class="lt">%s<b>%s</b></div><div class="rows">%s</div></div><div class="skip">%s</div>'))(i)(k.TutTitle)(e)(k.TutSkip)),Jf.className="",Qf(!0)}}function zv(){Qf()&&(window.localStorage.setItem(Gv,"1"),Jf.className="hidden",Qf(!1))}Hh(Bn.Delay(()=>Bn.Bind(kh(Ux(i=>{BC(i)})),()=>(kx(),Fx(),GR(),Bn.Combine((Hx()||DL(),Bn.Zero()),Bn.Delay(()=>(Vx(i=>{i!==""&&(window.sessionStorage.setItem("nda-room",i),window.location.reload())}),Bn.Zero())))))));const In=IL(),Di=document.getElementById("banner");Gx();document.getElementById("loader").className="done";let eh=!1;function NL(i){eh=!0,jc();const e=()=>{eh=!1,Zm(!1),i()};Cx("midgame",()=>{Zm(!0)},e,t=>{e()})}let z=Tt(on()),Id=Tt(0),H0=Tt(0),V0=Tt(0),Vr=Tt(0),Gr=Tt(0),bo=Tt(0),Eo=Tt(0),Ao=Tt(0),th=Tt(!1),nh=!1,$r=Tt(0),ih=Tt(""),UL=Tt(!1),rh=Tt(!1);const sh=Nn(new Array(4),0,4,!1),sc=Nn(new Array(4),0,4,!1);let Gl=Tt(""),G0=Tt("");function Hc(){return ls((i,e)=>Gi(i)?as()?Pt:i===ai()?new ha(Pt.Turn,Pt.Aim,Pt.Absolute,Pt.Steer,Pt.Strafe,Pt.Thrust,Pt.Reverse,Pt.Boost,Pt.Fire,Pt.Special,Pt.Start,Pt.Back,Pt.Swap,!0):iy(z(),i):ut.has(i)?e:Pt,Dx())}function ah(i){Gr(i?yc:3),In.Intro=i?yc:0,Qh(In),i&&z(Ah(Lo,Hc(),z())),Vr(0),bo(0),Eo(0),Ao(0),th(!1),nh=!1,$r(0),UL(!1),rh(!1),Nn(sh,0,4,!1),Nn(sc,0,4,!1),Yh(""),zx()}function z0(i){Ua(zR()),ot(WR()),Ua()?((ai()<0||!Gi(ai()))&&ai(e2()),z(i),ah(!1),z(a_(Ah(Lo,Hc(),z()))),Gr(1)):(ai(-1),z(i),ah(!0))}function Yt(i){return w(i,_i)===""?k.Player(i):w(i,_i)}function FL(i){const e=i.Phase;let t,n;switch(e.tag===1&&e.fields[0]!=null?(t=0,n=e.fields[0]):t=1,t){case 0:{const r=w(n,i.Ships);return k.Wins(r.Team>0?w(r.Team,["",k.Blue,k.Red]):Yt(n))}default:return k.Draw}}function Do(i){return i.Shots===0?0:~~(100*i.Hits/i.Shots)|0}function BL(i,e,t){let n,r,s,o,a,l,u,c,d,p,f,_,m,g;if(ot()){let L;if(t.Finish>0){const y=~~(~~t.Finish/60)|0,x=~~t.Finish%60|0,C=~~(t.Finish*10)%10|0;L=ie(te("%d:%02d.%d"))(y)(x)(C)}else L=k.Dnf;g=ie(te("<b>%s</b>"))(L)}else g=cn("",Dt(We(()=>xn(L=>L<=t.Stocks?"<i></i>":'<i class="gone"></i>',kt(1,1,ac)))));let h;const v=[];if(t.FirstBloodMedal>0&&v.push((n=$t(0),ie(te('<span class="medal fb" title="%s">%s FB x%d</span>'))(k.FirstBlood)(n)(t.FirstBloodMedal))),t.DoubleKillMedals>0&&v.push((r=$t(1),ie(te('<span class="medal dk" title="%s">%s DK x%d</span>'))(k.DoubleKill)(r)(t.DoubleKillMedals))),t.TripleKillMedals>0&&v.push((s=$t(2),ie(te('<span class="medal tk" title="%s">%s TK x%d</span>'))(k.TripleKill)(s)(t.TripleKillMedals))),t.RailKillMedals>0&&v.push((o=$t(3),ie(te('<span class="medal rk" title="%s">%s RD x%d</span>'))(k.RailKillMedal)(o)(t.RailKillMedals))),t.RamKillMedals>0&&v.push((a=$t(4),ie(te('<span class="medal rm" title="%s">%s RM x%d</span>'))(k.RamKillMedal)(a)(t.RamKillMedals))),t.OnFireMedals>0&&v.push((l=$t(5),ie(te('<span class="medal of" title="%s">%s OF x%d</span>'))(k.OnFireMedal)(l)(t.OnFireMedals))),t.VoidMedals>0&&v.push((u=$t(6),ie(te('<span class="medal vd" title="%s">%s VD x%d</span>'))(k.VoidMedal)(u)(t.VoidMedals))),t.HoleMedals>0&&v.push((c=$t(7),ie(te('<span class="medal eh" title="%s">%s EH x%d</span>'))(k.HoleMedal)(c)(t.HoleMedals))),t.AbductMedals>0&&v.push((d=$t(8),ie(te('<span class="medal ab" title="%s">%s AB x%d</span>'))(k.AbductMedal)(d)(t.AbductMedals))),t.GraveMedals>0&&v.push((p=$t(9),ie(te('<span class="medal gr" title="%s">%s GR x%d</span>'))(k.GraveMedal)(p)(t.GraveMedals))),t.Shots>=10&&Do(t)>=60&&v.push((f=$t(10),ie(te('<span class="medal de" title="%s">%s DE</span>'))(k.Deadeye)(f))),t.Id===i&&t.Stocks===ac&&v.push((_=$t(11),ie(te('<span class="medal fl" title="%s">%s FL</span>'))(k.Flawless)(_))),t.Grabs>=5&&v.push((m=$t(12),ie(te('<span class="medal sc" title="%s">%s SC</span>'))(k.Scavenger)(m))),v.length>0){const L=cn("",v);h=ie(te('<div class="medals">%s</div>'))(L)}else h="";const M=t.Id===i?" lead":t.Stocks===0?" out":"",S=Wt(t)|0,P=Yt(t.Id),E=Do(t)|0,A=Do(t)|0;return ie(te('<div class="line%s" style="color:#%06x"><div class="pos">%d</div><div class="who"><svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"><path d="M24 4 41 40 24 32 7 40Z"/></svg><b>%s</b>%s</div><div class="num big">%d</div><div class="acc"><div class="bar"><i style="width:%d%%"></i></div><span>%d%%</span></div><div class="num">%d</div><div class="num">%d</div><div class="stocks">%s</div></div>'))(M)(S)(e)(P)(h)(t.Kills)(E)(A)(t.Grabs)(t.Rings)(g)}function zl(i,e,t){const n=Wt(i)|0;return ie(te('<div class="award" style="color:#%06x"><b>%s</b><span>%s</span></div>'))(n)(e)(t)}function OL(i){const e=i.Ships.filter(M=>M.Active);let t;const n=i.Phase;let r,s;switch(n.tag===1&&n.fields[0]!=null?(r=0,s=n.fields[0]):r=1,r){case 0:{t=s;break}default:t=-1}const o=cn("",ls((M,S)=>BL(t,M+1,S),ot()?gt(M=>w(M,i.Ships),ty(e)):_o(M=>[M.Id===t,M.Stocks,M.Kills],e,{Compare:(M,S)=>tg(M,S)|0}))),a=[],l=wo(_o(M=>M.Kills|0,e,{Compare:(M,S)=>fn(M,S)|0}));let u,c;switch(l!=null&&l.Kills>0?(u=0,c=l):u=1,u){case 0:{a.push(zl(c,k.AwardKills,k.MostKills(Yt(c.Id),c.Kills)));break}}const d=wo(_o(M=>Do(M)|0,e.filter(M=>M.Shots>=5),{Compare:(M,S)=>fn(M,S)|0}));if(d!=null){const M=d;a.push(zl(M,k.AwardAim,k.BestAim(Yt(M.Id),Do(M))))}const p=wo(_o(M=>M.Rings|0,e,{Compare:(M,S)=>fn(M,S)|0}));let f,_;switch(p!=null&&p.Rings>0?(f=0,_=p):f=1,f){case 0:{a.push(zl(_,k.AwardRings,k.MostRings(Yt(_.Id),_.Rings)));break}}const m=Zc(M=>M.Grabs===0,e);if(m!=null){const M=m;a.push(zl(M,k.AwardCrates,k.NoCrates(Yt(M.Id))))}let g;const h=ot()?k.ColTime:k.ColStocks;g=ie(te('<div class="hdr"><span></span><span></span><span>%s</span><span>%s</span><span>%s</span><span>%s</span><span>%s</span></div>'))(k.ColKills)(k.ColAccuracy)(k.ColCrates)(k.ColRings)(h);const v=cn("",a);return ie(te('<div class="table">%s%s</div><div class="awards">%s</div>'))(g)(o)(v)}function oh(i){Di.className="",Di.offsetWidth,Di.className=i}function Tn(i){ih(i),$r(1.4),oh("shout"),tv(jo.Alert)}function kL(i,e){const t=En(s=>{if(s.tag===1)return[s.fields[1],s.fields[2]]},e),n=En(s=>{if(s.tag===25)return[s.fields[0],s.fields[1]]},e),r=mt(e);try{for(;r["System.Collections.IEnumerator.MoveNext"]();){let s,o,a,l,u,c,d,p,f;const _=r["System.Collections.Generic.IEnumerator`1.get_Current"]();let m,g,h,v,M,S,P,E,A,L,y,x;switch(_.tag){case 3:{switch(_.fields[1]){case"firstblood":{m=0,g=_.fields[0];break}case"doublekill":{m=1,h=_.fields[0];break}case"triplekill":{m=2,v=_.fields[0];break}case"railkill":{m=3,M=_.fields[0];break}case"ramkill":{m=4,S=_.fields[0];break}case"voidkill":{m=5,P=_.fields[0];break}case"holekill":{m=6,E=_.fields[0];break}case"abductkill":{m=7,A=_.fields[0];break}case"gravekill":{m=8,L=_.fields[0];break}default:m=10}break}case 7:{m=9,y=_.fields[1],x=_.fields[2];break}default:m=10}switch(m){case 0:{Tn((s=Yt(g),ie(te("%s: FIRST BLOOD!"))(s)));break}case 1:{Tn((o=Yt(h),ie(te("%s: DOUBLE KILL!"))(o)));break}case 2:{Tn((a=Yt(v),ie(te("%s: TRIPLE KILL, ACE!"))(a)));break}case 3:{Tn((l=Yt(M),ie(te("%s: RAILED DOWN!"))(l)));break}case 4:{Tn((u=Yt(S),ie(te("%s: %s"))(u)(k.RamKill)));break}case 5:{Tn((c=Yt(P),ie(te("%s: %s"))(c)(k.VoidKill)));break}case 6:{Tn((d=Yt(E),ie(te("%s: %s"))(d)(k.HoleKill)));break}case 7:{Tn((p=Yt(A),ie(te("%s: %s"))(p)(k.AbductKill)));break}case 8:{Tn((f=Yt(L),ie(te("%s: %s"))(f)(k.GraveKill)));break}case 9:{Tn(k.Parry(Yt(y),Yt(x)));break}}}}finally{yt(r)}if(Zr(i)&&!rh())rh(!0),Tn(k.SuddenDeath);else if(Da(n))Da(t)||yp(t)[1]&&Tn(k.RingOut);else{const s=yp(n);Tn(k.Finish(Yt(s[0]),w(s[1]-1,k.Places)))}i.Ships.forEach(s=>{s.Active&&s.Stocks===1&&!w(s.Id,sh)&&(ve(sh,s.Id,!0),$r()<=0&&Tn(k.LastStock(Yt(s.Id)))),s.Streak===0?ve(sc,s.Id,!1):s.Streak>=3&&!w(s.Id,sc)&&(ve(sc,s.Id,!0),$r()<=0&&Tn(k.OnFire(Yt(s.Id))))})}function HL(i){if(Ds(i))return an();{const e=w(i.slot,z().Ships);return{hp:e.Hp/Cr,sh:e.Shield/Cr,boost:e.Boost/Ns,stocks:e.Stocks,kills:e.Kills}}}function VL(){const i=Dt(We(()=>gn(e=>e.Key.startsWith("ph:")?_t([Fg(e.Key,3),a2(e.Key)]):_r(),li())));Da(i)||ch("nda:host",{phase:s2(),pads:xp(Dt(We(()=>gn(e=>_t([e[0],e[1]]),i)))),stats:xp(Dt(We(()=>gn(e=>_t([e[0],HL(e[1])]),i))))})}const No=document.getElementById("menu");let Jo=Re(),W0="",K0=0,fu=an(),hu=0,Dd=!1,Uo=0,Nd=!1,X0=!0;Bx("nda:state",i=>{fu=i,hu=Date.now()});function Vc(){return Ds(fu)?!1:Date.now()-hu<1e3}function GL(){const i=No.innerHTML,e=Date.now(),t=i===W0&&e-K0<1e3?an():i;Ds(t)||(K0=e),W0=i;const n={world:new jn(z().Ships,z().Bullets,z().Mines,z().Rocks,z().Portals,z().PortalIn,z().Hole,z().HoleIn,z().Deploys,z().RaceEnd,z().Pads,z().Crates,z().Rng,z().Phase,z().Time,Re()),events:Es(Jo),layout:is(),race:ot(),colors:Hn,intro:In.Intro,banner:Di.textContent,bannerClass:Di.className,menuClass:No.className,menu:t},r=JSON.stringify(n).length|0;r>6e4&&Ba("payload",1e4)&&Qc("the world snapshot is big enough to stall the relay",{bytes:r,menuHtml:!Ds(t)}),ch("nda:state",n),Jo=Re()}function lh(i){switch(i){case"Rail":return Ie.Rail;case"Mines":return Ie.Mines;case"Swarm":return Ie.Swarm;case"Pulse":return Ie.Pulse;case"Scatter":return Ie.Scatter;case"Tractor":return Ie.Tractor;case"Collision":return Ie.Collision;case"Rock":return Ie.Rock;case"Singularity":return Ie.Singularity;case"Barrier":return Ie.Barrier;case"Sentry":return Ie.Sentry;case"Bubble":return Ie.Bubble;default:return Ie.Blaster}}function zL(i){return Array.isArray(i)?Ci(i[0])==="TowShip"?new Ni(1,[i[1]]):new Ni(2,[i[1]]):Ni.NoTether}function WL(i){const e=n=>i[n];switch(Ci(i[0])){case"Hit":return new _e(0,[e(1),e(2),e(3),e(4)]);case"Explode":return new _e(1,[e(1),e(2),e(3)]);case"Downed":return new _e(2,[e(1),e(2),lh(e(3)),e(4)]);case"Medal":return new _e(3,[e(1),e(2)]);case"Shot":return new _e(4,[e(1)]);case"Ram":return new _e(5,[e(1)]);case"Bump":return new _e(6,[e(1)]);case"Parried":return new _e(7,[e(1),e(2),e(3)]);case"Pickup":return new _e(8,[e(1),e(2)]);case"Mend":return new _e(9,[e(1)]);case"Grab":return new _e(10,[e(1)]);case"Charging":return new _e(11,[e(1)]);case"Beam":return new _e(12,[e(1),e(2),e(3)]);case"MineSet":return new _e(13,[e(1)]);case"MineLive":return new _e(14,[e(1)]);case"Blast":return new _e(15,[e(1)]);case"Wave":return new _e(16,[e(1),e(2),e(3)]);case"Cooked":return new _e(17,[e(1)]);case"Zap":return new _e(18,[e(1),e(2),e(3)]);case"Latch":return new _e(19,[e(1),e(2)]);case"Launch":return new _e(20,[e(1)]);case"PortalOpen":return new _e(21,[e(1),e(2)]);case"Warp":return new _e(22,[e(1)]);case"Deployed":return new _e(24,[e(1)]);case"Finished":return new _e(25,[e(1),e(2)]);default:return new _e(23,[e(1)])}}function KL(i){return new jn(gt(e=>{const t=e,n=lh(e.Weapon),r=lh(e.LastWeapon);return new we(t.Id,t.Team,t.Archetype,t.Pos,t.Vel,t.Angle,t.Hp,t.Shield,t.Boost,t.Stocks,t.Alive,t.Active,t.Thrusting,t.Reversing,t.RespawnIn,t.Invuln,t.Cooldown,t.Stun,t.Spin,t.Heat,t.Locked,n,t.Ammo,t.Charge,t.Held,zL(e.Tow),t.TowLeft,t.LastHit,r,t.LaunchCd,t.LaunchAngle,t.Ghosting,t.WarpCd,t.Next,t.Laps,t.Finish,t.Streak,t.Shots,t.Hits,t.Grabs,t.Rings,t.Kills,t.FirstBloodMedal,t.DoubleKillMedals,t.TripleKillMedals,t.RailKillMedals,t.RamKillMedals,t.OnFireMedals,t.VoidMedals,t.HoleMedals,t.AbductMedals,t.GraveMedals,t.LastKillTime,t.MultiKillCount)},i.Ships),Ke(i.Bullets),Ke(i.Mines),Ke(i.Rocks),Ke(i.Portals),i.PortalIn,i.Hole,i.HoleIn,Ke(i.Deploys),i.RaceEnd,i.Pads,i.Crates,i.Rng,Array.isArray(i.Phase)?new Yr(1,[i.Phase[1]]):Yr.Playing,i.Time,Re())}function XL(i){let e;const t=as()&&m2();t||Lx();const n=Zc(u=>u.Key==="kb",li());let r;switch(n!=null?(e=n,!t&&zt("local","back",e.Input.Back)?r=0:r=1):r=1,r){case 0:{g2();break}}const s=Date.now()-hu;s>400&&Ba("mirror",5e3)&&Qc("the mirrored world arrived late from the host",{ageMs:Math.round(s),expectedMs:Ug});const o=fu,a=o.layout|0;if(ot(o.race),is()!==a&&el(a),Px(o.colors,0,Hn,0,4),Qh(In),In.Intro=o.intro,Di.textContent=o.banner,Di.className=o.bannerClass,t)Dv([]);else{No.className=o.menuClass;const u=o.menu;Ds(u)||(No.innerHTML=u,qR(),o.menu=an())}const l=Ke(gt(WL,o.events));o.events=[],z(KL(o.world)),Q_(No.className!=="hidden"?!0:t),nv(l),iv(z()),To(In,z(),l,i)}function qL(){if(Os()!==""){const i=as()&&it(nn(),dn.Lobby)&&ut.size<4;i!==X0&&(X0=i,Ix(Xd(),i))}}function YL(i,e){let t,n,r,s;if(qL(),i-H0()>100&&(H0(i),VL()),Q_(as()),eh)To(In,z(),Re(),e);else if(as()){QC();const o=Dv(Hc());let a;if(o!=null)switch(o.tag){case 1:{it(nn(),dn.Lobby)?a=0:a=1;break}case 2:{a=1;break}case 0:{a=2;break}case 4:{a=3;break}case 3:{a=4;break}default:a=5}else a=5;switch(a){case 0:{s0(),z0(Au(hn,(t=on(),new jn(t.Ships,t.Bullets,t.Mines,t.Rocks,t.Portals,t.PortalIn,t.Hole,t.HoleIn,t.Deploys,t.RaceEnd,t.Pads,t.Crates,Jc().Next1(1000003),t.Phase,t.Time,t.Events))));break}case 1:{it(nn(),dn.Pause)||s0(),z0(Au(hn,o_(l=>ut.has(l),z())));break}case 2:{ah(!1);break}case 4:{z(on()),ai(-1),Sv(),Os()!==""&&Bg();break}}In.Layout!==is()&&z(on()),Qh(In),To(In,z(),Re(),e)}else if(Gr()>0){const o=~~Math.ceil(Gr())|0;Gr(Gr()-e);const a=~~Math.ceil(Gr())|0;a!==o&&(tv(a===0?jo.Go:jo.Tick),a===0?(ih(k.Go),$r(.7),In.Tint=.9,In.TintHex="#ffffff",In.Spike=1.2,oh("shout go")):oh("count")),Gr()>0&&(Di.textContent=Ps(a)),To(In,z(),Re(),e)}else{bo(fe(0,bo()-e)),Eo(fe(0,Eo()-e));const o=Eo()>0?0:bo()>0?.28:1;Vr(Vr()+e*o);const a=Hc();let l=Re(),u=0;const c=performance.now();for(;Vr()>=Lo&&u<8;)z(Ah(Lo,a,z())),l=Ye(z().Events,l),Vr(Vr()-Lo),u=u+1|0;Uo=performance.now()-c,u===8&&(Ba("physics",5e3)&&Qc("physics fell behind and dropped time",{physicsMs:Math.round(Uo),backlogMs:Math.round(Vr()*1e3),ships:z().Ships.length}),Vr(0)),Jo=Ye(Jo,l);const d=QR();if(d!=null){const _=d[0]|0;d[1]&&z(new jn(gt(m=>m.Id===_?new we(m.Id,m.Team,m.Archetype,m.Pos,m.Vel,m.Angle,m.Hp,m.Shield,m.Boost,m.Stocks,!1,!1,m.Thrusting,m.Reversing,m.RespawnIn,m.Invuln,m.Cooldown,m.Stun,m.Spin,m.Heat,m.Locked,m.Weapon,m.Ammo,m.Charge,m.Held,m.Tow,m.TowLeft,m.LastHit,m.LastWeapon,m.LaunchCd,m.LaunchAngle,m.Ghosting,m.WarpCd,m.Next,m.Laps,m.Finish,m.Streak,m.Shots,m.Hits,m.Grabs,m.Rings,m.Kills,m.FirstBloodMedal,m.DoubleKillMedals,m.TripleKillMedals,m.RailKillMedals,m.RamKillMedals,m.OnFireMedals,m.VoidMedals,m.HoleMedals,m.AbductMedals,m.GraveMedals,m.LastKillTime,m.MultiKillCount):m,z().Ships),z().Bullets,z().Mines,z().Rocks,z().Portals,z().PortalIn,z().Hole,z().HoleIn,z().Deploys,z().RaceEnd,z().Pads,z().Crates,z().Rng,z().Phase,z().Time,z().Events)),z(Au(hn,z())),Tn(k.Joins(Yt(_)))}let p=!1;if(Ja((_,m)=>{zt(ie(te("s%d"))(_),"start",m.Start)&&(p=!0),zt(ie(te("s%d"))(_),"swap",m.Swap)&&Ko(w(_,z().Ships))&&z(new jn(ls((g,h)=>g===_?new we(h.Id,h.Team,h.Archetype,h.Pos,h.Vel,h.Angle,h.Hp,h.Shield,h.Boost,h.Stocks,h.Alive,h.Active,h.Thrusting,h.Reversing,h.RespawnIn,h.Invuln,h.Cooldown,h.Stun,h.Spin,h.Heat,h.Locked,h.Weapon,h.Ammo,h.Charge,h.Held,h.Tow,h.TowLeft,h.LastHit,h.LastWeapon,h.LaunchCd,h.LaunchAngle,!h.Ghosting,h.WarpCd,h.Next,h.Laps,h.Finish,h.Streak,h.Shots,h.Hits,h.Grabs,h.Rings,h.Kills,h.FirstBloodMedal,h.DoubleKillMedals,h.TripleKillMedals,h.RailKillMedals,h.RamKillMedals,h.OnFireMedals,h.VoidMedals,h.HoleMedals,h.AbductMedals,h.GraveMedals,h.LastKillTime,h.MultiKillCount):h,z().Ships),z().Bullets,z().Mines,z().Rocks,z().Portals,z().PortalIn,z().Hole,z().HoleIn,z().Deploys,z().RaceEnd,z().Pads,z().Crates,z().Rng,z().Phase,z().Time,z().Events))},a),mh(_=>_.tag===1,l)&&Eo(.09),kL(z(),l),$r(fe(0,$r()-e)),$r()>0?Di.textContent=ih():Di.className="hidden",nv(l),iv(z()),z().Phase.tag===0)p&&xv();else if(th()){if(Ao(Ao()-e),Ao()<=0&&!nh){nh=!0,Di.className="hidden",Yh(G0());const _=w(0,z().Ships);_.Active&&d2((r=z().Phase,r.tag===1&&r.fields[0]!=null&&(s=r.fields[0]|0,s===0?!0:_.Team>0&&w(s,z().Ships).Team===_.Team)),_.Kills,ac-_.Stocks,_.Finish),Uc()?NL(()=>{U0(Gl())}):(VR(),U0(Gl()))}}else{th(!0),Ao(Ox),bo(.6),Gl(FL(z())),G0(OL(z()));const _=z().Phase;let m,g;switch(_.tag===1&&_.fields[0]!=null?(n=_.fields[0]|0,u2(n,w(n,z().Ships).Team)?(m=0,g=_.fields[0]):m=1):m=1,m){case 0:{Gl(k.SeriesWin(w(g,z().Ships).Team>0?w(w(g,z().Ships).Team,["",k.Blue,k.Red]):Yt(g)));break}}}To(In,z(),l,e)}}function Wv(i){const e=performance.now();Uo=0;const t=Id()===0?0:$e(.1,fe(0,(i-Id())/1e3));Id(i);for(let r=0;r<=3;r++)In.Names[r]=Yt(r);Vc()?(Dd=!0,Nd=!1,XL(t)):(Dd&&(Dd=!1,z(on()),ai(-1),Sv()),!Nd&&!Ds(fu)&&Date.now()-hu>4e3&&(Nd=!0,Tn(k.HostLeft)),YL(i,t),wx()?Jo=Re():i-V0()>Ug&&(V0(i),GL()));const n=performance.now()-e;n>33&&Ba("frame",5e3)&&Qc("a frame took longer than 30 fps allows",{frameMs:Math.round(n),physicsMs:Math.round(Uo),renderMs:Math.round(n-Uo),mirrored:Vc(),menu:as()}),window.requestAnimationFrame(r=>{Wv(r)})}window.addEventListener("keydown",i=>{zv()});window.addEventListener("pointerdown",i=>{zv()});window.addEventListener("visibilitychange",i=>{document.hidden&&!Vc()&&!as()&&it(z().Phase,Yr.Playing)&&xv()});window.addEventListener("pagehide",i=>{Os()!==""&&Bg()});window.requestAnimationFrame(i=>{Wv(i)});window.addEventListener("keydown",i=>{if(Ua()&&!Vc()&&!as()){const e=i.code;switch(e){case"KeyK":{z(new jn(gt(t=>t.Id===ai()?new we(t.Id,t.Team,t.Archetype,t.Pos,t.Vel,t.Angle,0,t.Shield,t.Boost,t.Stocks,t.Alive,t.Active,t.Thrusting,t.Reversing,t.RespawnIn,0,t.Cooldown,t.Stun,t.Spin,t.Heat,t.Locked,t.Weapon,t.Ammo,t.Charge,t.Held,t.Tow,t.TowLeft,t.LastHit,t.LastWeapon,t.LaunchCd,t.LaunchAngle,t.Ghosting,t.WarpCd,t.Next,t.Laps,t.Finish,t.Streak,t.Shots,t.Hits,t.Grabs,t.Rings,t.Kills,t.FirstBloodMedal,t.DoubleKillMedals,t.TripleKillMedals,t.RailKillMedals,t.RamKillMedals,t.OnFireMedals,t.VoidMedals,t.HoleMedals,t.AbductMedals,t.GraveMedals,t.LastKillTime,t.MultiKillCount):t,z().Ships),z().Bullets,z().Mines,z().Rocks,z().Portals,z().PortalIn,z().Hole,z().HoleIn,z().Deploys,z().RaceEnd,z().Pads,z().Crates,z().Rng,z().Phase,z().Time,z().Events));break}case"KeyT":{z(new jn(z().Ships,z().Bullets,z().Mines,z().Rocks,z().Portals,z().PortalIn,z().Hole,z().HoleIn,z().Deploys,z().RaceEnd,z().Pads,z().Crates,z().Rng,z().Phase,Bo(),z().Events));break}case"KeyG":{z(new jn(gt(t=>t.Id===er()?new we(t.Id,t.Team,t.Archetype,t.Pos,t.Vel,t.Angle,t.Hp,t.Shield,t.Boost,0,!1,t.Active,t.Thrusting,t.Reversing,t.RespawnIn,t.Invuln,t.Cooldown,t.Stun,t.Spin,t.Heat,t.Locked,t.Weapon,t.Ammo,t.Charge,t.Held,t.Tow,t.TowLeft,t.LastHit,t.LastWeapon,t.LaunchCd,t.LaunchAngle,t.Ghosting,t.WarpCd,t.Next,t.Laps,t.Finish,t.Streak,t.Shots,t.Hits,t.Grabs,t.Rings,t.Kills,t.FirstBloodMedal,t.DoubleKillMedals,t.TripleKillMedals,t.RailKillMedals,t.RamKillMedals,t.OnFireMedals,t.VoidMedals,t.HoleMedals,t.AbductMedals,t.GraveMedals,t.LastKillTime,t.MultiKillCount):t,z().Ships),z().Bullets,z().Mines,z().Rocks,z().Portals,z().PortalIn,z().Hole,z().HoleIn,z().Deploys,z().RaceEnd,z().Pads,z().Crates,z().Rng,z().Phase,z().Time,z().Events));break}case"KeyR":{z(a_(z()));break}default:if(e.startsWith("Digit")&&er()>=0){const t=yh(Fg(e,5),511,!1,32)-1|0;t===-1?z(Wp(er(),Ie.Blaster,z())):t>=0&&t<mc.length&&z(Wp(er(),w(t,mc),z()))}}}});export{Vr as acc,Di as banner,UL as bled,Gr as countdown,G0 as endNote,Gl as endTitle,th as ending,Ao as finish,Wv as frame,zv as hideTutorial,Eo as hitstop,Id as last,H0 as lastHost,V0 as lastSend,NL as requestMidgameAd,$r as shout,ih as shoutText,DL as showTutorial,bo as slowmo,rh as suddenSaid,Jf as tutEl,Gv as tutKey,Qf as tutShown,In as view,z as world};
